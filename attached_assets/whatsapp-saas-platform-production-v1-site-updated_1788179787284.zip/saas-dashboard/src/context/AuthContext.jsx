import React, { createContext, useContext, useEffect, useState } from 'react';
import { api } from '../api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('token'));
  const [tenant, setTenant] = useState(null);
  const [loading, setLoading] = useState(true);

  async function refreshTenant() {
    if (!token) {
      setTenant(null);
      setLoading(false);
      return;
    }
    try {
      const data = await api.getMe();
      setTenant(data);
    } catch {
      // الرمز غير صالح أو منتهي
      logout();
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refreshTenant();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  function login(newToken) {
    localStorage.setItem('token', newToken);
    setToken(newToken);
  }

  function logout() {
    localStorage.removeItem('token');
    setToken(null);
    setTenant(null);
  }

  return (
    <AuthContext.Provider value={{ token, tenant, loading, login, logout, refreshTenant }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
