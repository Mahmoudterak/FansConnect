import React from 'react';

export default class ErrorBoundary extends React.Component {
  state = { hasError: false };
  static getDerivedStateFromError() { return { hasError: true }; }
  render() {
    if (this.state.hasError) return <div className="card" style={{ margin: 32 }}><h2>حدث خطأ غير متوقع</h2><p className="muted">أعد تحميل الصفحة، وإذا تكرر الخطأ استخدم رقم الطلب الظاهر في استجابة API.</p><button className="btn" onClick={() => window.location.reload()}>إعادة التحميل</button></div>;
    return this.props.children;
  }
}