import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

const links = [
  { to: '/app', label: 'الرئيسية', end: true },
  { to: '/app/inbox', label: 'صندوق المحادثات' },
  { to: '/app/contacts', label: 'جهات الاتصال' },
  { to: '/app/leads', label: 'العملاء المحتملون' },
  { to: '/app/appointments', label: 'المواعيد' },
  { to: '/app/catalog', label: 'الخدمات والمنتجات' },
  { to: '/app/faq', label: 'الأسئلة الشائعة' },
  { to: '/app/auto-replies', label: 'الردود التلقائية' },
  { to: '/app/flows', label: 'التدفقات' },
  { to: '/app/training', label: 'أمثلة التدريب' },
  { to: '/app/analytics', label: 'التحليلات' },
  { to: '/app/bot-settings', label: 'إعدادات AI' },
  { to: '/app/business-settings', label: 'معلومات النشاط' },
  { to: '/app/whatsapp-settings', label: 'ربط واتساب' },
  { to: '/app/billing', label: 'الاشتراك والفوترة' },
];

export default function Layout() {
  const { tenant, logout } = useAuth();

  return (
    <div className="app-layout">
      <aside className="sidebar">
        <div className="brand">{tenant?.name || 'لوحة التحكم'}</div>
        <nav>
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.end}
              className={({ isActive }) => (isActive ? 'active' : '')}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
        <div className="logout" onClick={logout}>
          تسجيل الخروج
        </div>
      </aside>
      <main className="main-content">
        <Outlet />
      </main>
    </div>
  );
}
