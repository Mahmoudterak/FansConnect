import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import Layout from './components/Layout.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Dashboard from './pages/Dashboard.jsx';
import BusinessSettings from './pages/BusinessSettings.jsx';
import WhatsAppSettings from './pages/WhatsAppSettings.jsx';
import Billing from './pages/Billing.jsx';
import Leads from './pages/Leads.jsx';
import Appointments from './pages/Appointments.jsx';
import BotSettings from './pages/BotSettings.jsx';
import Inbox from './pages/Inbox.jsx';
import Contacts from './pages/Contacts.jsx';
import Analytics from './pages/Analytics.jsx';
import WorkspaceManager from './pages/WorkspaceManager.jsx';
import FlowBuilder from './pages/FlowBuilder.jsx';
import MarketingPage from './pages/MarketingPage.jsx';
import ForgotPassword from './pages/ForgotPassword.jsx';
import VerifyEmail from './pages/VerifyEmail.jsx';
import ResetPassword from './pages/ResetPassword.jsx';
import Onboarding from './pages/Onboarding.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';

export default function App() {
  return <Routes>
    <Route path="/" element={<MarketingPage />} />
    <Route path="/features" element={<MarketingPage section="features" />} />
    <Route path="/pricing" element={<MarketingPage section="pricing" />} />
    <Route path="/faq" element={<MarketingPage section="faq" />} />
    <Route path="/contact" element={<MarketingPage section="contact" />} />
    <Route path="/login" element={<Login />} />
    <Route path="/register" element={<Register />} />
    <Route path="/forgot-password" element={<ForgotPassword />} />
    <Route path="/verify-email" element={<VerifyEmail />} />
    <Route path="/reset-password" element={<ResetPassword />} />
    <Route path="/app" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
      <Route index element={<Dashboard />} />
      <Route path="onboarding" element={<Onboarding />} />
      <Route path="inbox" element={<Inbox />} />
      <Route path="contacts" element={<Contacts />} />
      <Route path="leads" element={<Leads />} />
      <Route path="appointments" element={<Appointments />} />
      <Route path="catalog" element={<WorkspaceManager type="catalog" />} />
      <Route path="bot-settings" element={<BotSettings />} />
      <Route path="faq" element={<WorkspaceManager type="faq" />} />
      <Route path="auto-replies" element={<WorkspaceManager type="auto-replies" />} />
      <Route path="flows" element={<FlowBuilder />} />
      <Route path="training" element={<WorkspaceManager type="training" />} />
      <Route path="analytics" element={<Analytics />} />
      <Route path="business-settings" element={<BusinessSettings />} />
      <Route path="whatsapp-settings" element={<WhatsAppSettings />} />
      <Route path="billing" element={<Billing />} />
    </Route>
    <Route path="/admin" element={<ProtectedRoute><AdminDashboard /></ProtectedRoute>} />
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes>;
}