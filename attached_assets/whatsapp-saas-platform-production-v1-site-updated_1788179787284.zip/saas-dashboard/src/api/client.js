const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:4000';

/**
 * طلب عام للـ API، يرفق رمز الدخول (Token) تلقائياً لو موجود بالتخزين المحلي
 */
async function request(path, { method = 'GET', body, token } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const authToken = token || localStorage.getItem('token');
  if (authToken) headers.Authorization = `Bearer ${authToken}`;

  const res = await fetch(`${API_BASE_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const isJson = res.headers.get('content-type')?.includes('application/json');
  const data = isJson ? await res.json() : null;

  if (!res.ok) {
    throw new Error(data?.error || `خطأ غير متوقع (${res.status})`);
  }

  return data;
}

export const api = {
  register: (payload) => request('/api/auth/register', { method: 'POST', body: payload }),
  login: (payload) => request('/api/auth/login', { method: 'POST', body: payload }),

  getMe: () => request('/api/tenants/me'),
  updateBusinessInfo: (businessInfo) =>
    request('/api/tenants/me/business-info', { method: 'PUT', body: { businessInfo } }),
  updateWhatsAppConfig: (payload) =>
    request('/api/tenants/me/whatsapp-config', { method: 'PUT', body: payload }),
  testWhatsApp: (payload) => request('/api/tenants/me/whatsapp-test', { method: 'POST', body: payload }),

  getPlans: () => request('/api/plans'),
  getSubscription: () => request('/api/billing/subscription'),
  subscribe: (planId) => request('/api/billing/subscribe', { method: 'POST', body: { planId } }),
  getPendingInvoice: () => request('/api/billing/pending-invoice'),

  getLeads: () => request('/api/leads'),
  getAppointments: () => request('/api/appointments'),
  getProfiles: () => request('/api/activity-profiles'),
  getConversations: (params = '') => request(`/api/workspace/conversations${params}`),
  getConversationMessages: (id) => request(`/api/workspace/conversations/${id}/messages`),
  replyToConversation: (id, text) => request(`/api/workspace/conversations/${id}/reply`, { method: 'POST', body: { text } }),
  updateConversation: (id, data) => request(`/api/workspace/conversations/${id}`, { method: 'PATCH', body: data }),
  getContacts: (search = '') => request(`/api/workspace/contacts${search ? `?search=${encodeURIComponent(search)}` : ''}`),
  createContact: (data) => request('/api/workspace/contacts', { method: 'POST', body: data }),
  updateContact: (id, data) => request(`/api/workspace/contacts/${id}`, { method: 'PATCH', body: data }),
  getCatalog: () => request('/api/workspace/catalog'),
  createCatalogItem: (data) => request('/api/workspace/catalog', { method: 'POST', body: data }),
  deleteCatalogItem: (id) => request(`/api/workspace/catalog/${id}`, { method: 'DELETE' }),
  getAnalytics: () => request('/api/workspace/analytics/summary'),
  forgotPassword: (email) => request('/api/auth/forgot-password', { method: 'POST', body: { email } }),
  verifyEmail: (token) => request('/api/auth/verify-email', { method: 'POST', body: { token } }),
  resetPassword: (payload) => request('/api/auth/reset-password', { method: 'POST', body: payload }),
};

api.getBotConfig = () => request('/api/bot-config/me');
api.updateBotConfig = (data) => request('/api/bot-config/me',{method:'PUT',body:data});
api.getFaqs = () => request('/api/bot-config/me/faqs');
api.createFaq = (data) => request('/api/bot-config/me/faqs', { method: 'POST', body: data });
api.updateFaq = (id, data) => request(`/api/bot-config/me/faqs/${id}`, { method: 'PATCH', body: data });
api.deleteFaq = (id) => request(`/api/bot-config/me/faqs/${id}`, { method: 'DELETE' });
api.getAutoReplies = () => request('/api/bot-config/me/auto-replies');
api.createAutoReply = (data) => request('/api/bot-config/me/auto-replies', { method: 'POST', body: data });
api.deleteAutoReply = (id) => request(`/api/bot-config/me/auto-replies/${id}`, { method: 'DELETE' });
api.getFlows = () => request('/api/bot-config/me/flows');
api.createFlow = (data) => request('/api/bot-config/me/flows', { method: 'POST', body: data });
api.updateFlow = (id, data) => request(`/api/bot-config/me/flows/${id}`, { method: 'PUT', body: data });
api.getExamples = () => request('/api/bot-config/me/examples');
api.createExample = (data) => request('/api/bot-config/me/examples', { method: 'POST', body: data });
