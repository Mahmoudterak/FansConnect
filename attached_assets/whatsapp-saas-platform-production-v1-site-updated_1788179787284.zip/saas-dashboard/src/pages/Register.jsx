import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext.jsx';

export default function Register() {
  const [businessName, setBusinessName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [activityType, setActivityType] = useState('GENERAL');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { token } = await api.register({ businessName, email, password, activityType });
      login(token);
      navigate('/app/billing');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-page">
      <form className="auth-card" onSubmit={handleSubmit}>
        <h1>إنشاء حساب جديد</h1>
        <div className="field">
          <label>نوع النشاط</label>
          <select value={activityType} onChange={(e) => setActivityType(e.target.value)}>
            <option value="GENERAL">نشاط عام</option><option value="DENTAL">عيادة أسنان</option><option value="CLINIC">عيادة طبية</option><option value="SALON">صالون تجميل</option><option value="RESTAURANT">مطعم</option><option value="RETAIL">متجر إلكتروني</option><option value="REAL_ESTATE">عقارات</option><option value="HOTEL">فندق</option><option value="EDUCATION">تعليم وتدريب</option><option value="AUTOMOTIVE">سيارات</option><option value="PROFESSIONAL_SERVICES">خدمات مهنية</option><option value="OTHER">أخرى</option>
          </select>
        </div>
        <div className="field">
          <label>الاسم التجاري لنشاطك</label>
          <input value={businessName} onChange={(e) => setBusinessName(e.target.value)} required />
        </div>
        <div className="field">
          <label>البريد الإلكتروني</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div className="field">
          <label>كلمة المرور</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            minLength={8}
            required
          />
        </div>
        {error && <div className="error-text">{error}</div>}
        <button className="btn" type="submit" disabled={loading} style={{ width: '100%' }}>
          {loading ? 'جاري الإنشاء...' : 'إنشاء الحساب'}
        </button>
        <p style={{ marginTop: 16, fontSize: 14 }}>
          عندك حساب؟ <Link to="/login">سجّل الدخول</Link>
        </p>
      </form>
    </div>
  );
}
