import React, { useEffect, useState } from 'react';
import { api } from '../api/client';

export default function Inbox() {
  const [conversations, setConversations] = useState([]);
  const [selected, setSelected] = useState(null);
  const [thread, setThread] = useState(null);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  async function load() { setLoading(true); try { setConversations(await api.getConversations()); } finally { setLoading(false); } }
  useEffect(() => { load(); }, []);
  async function openConversation(conversation) { setSelected(conversation); setThread(await api.getConversationMessages(conversation.id)); }
  async function send(event) { event.preventDefault(); if (!text.trim()) return; await api.replyToConversation(selected.id, text); setText(''); await openConversation(selected); await load(); }
  return <div><div className="page-header"><h1>صندوق المحادثات</h1><p>WhatsApp وInstagram في مساحة عمل واحدة</p></div><div className="inbox-grid card">
    <div className="conversation-list"><div className="list-heading">المحادثات ({conversations.length})</div>{loading ? <div className="empty-state">جاري التحميل…</div> : conversations.map((c) => <button className={`conversation-row ${selected?.id === c.id ? 'selected' : ''}`} onClick={() => openConversation(c)} key={c.id}><strong>{c.contact?.name || c.contact?.phone || c.waChatId}</strong><small>{c.messages?.[0]?.content || 'لا توجد رسائل'}</small><span className={`status-dot ${c.handedOff ? 'warning' : 'active'}`}>{c.handedOff ? 'موظف' : 'AI'}</span></button>)}</div>
    <div className="thread">{!thread ? <div className="empty-state">اختر محادثة للبدء</div> : <><div className="thread-head"><strong>{thread.conversation.contact?.name || thread.conversation.waChatId}</strong><button className="btn secondary" onClick={() => api.updateConversation(selected.id, { action: selected.handedOff ? 'resume' : 'pause' }).then(() => openConversation(selected))}>{selected.handedOff ? 'استئناف AI' : 'إيقاف AI'}</button></div><div className="messages">{thread.messages.map((m) => <div className={`bubble ${m.direction === 'OUTBOUND' ? 'outbound' : ''}`} key={m.id}>{m.content}<small>{m.route || 'رسالة'}</small></div>)}</div><form className="reply-box" onSubmit={send}><input value={text} onChange={(e) => setText(e.target.value)} placeholder="اكتب رد الموظف…" /><button className="btn">إرسال</button></form></>}</div>
  </div></div>;
}