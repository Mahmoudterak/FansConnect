import React, { useEffect, useState } from 'react';
import { api } from '../api/client';
export default function Contacts() {
  const [contacts, setContacts] = useState([]); const [search, setSearch] = useState('');
  async function load() { setContacts(await api.getContacts(search)); }
  useEffect(() => { load(); }, []);
  return <div><div className="page-header"><h1>جهات الاتصال</h1><p>قاعدة العملاء الموحدة الخاصة بنشاطك</p></div><div className="card toolbar"><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث بالاسم أو الهاتف" /><button className="btn" onClick={load}>بحث</button></div><div className="card">{!contacts.length ? <div className="empty-state">لا توجد جهات اتصال بعد</div> : <table><thead><tr><th>الاسم</th><th>الهاتف</th><th>المصدر</th><th>الحالة</th><th>آخر تفاعل</th></tr></thead><tbody>{contacts.map((c) => <tr key={c.id}><td>{c.name || '—'}</td><td dir="ltr">{c.phone}</td><td>{c.source || '—'}</td><td><span className="badge active">{c.status}</span></td><td>{c.lastInteraction ? new Date(c.lastInteraction).toLocaleDateString('ar-AE') : '—'}</td></tr>)}</tbody></table>}</div></div>;
}