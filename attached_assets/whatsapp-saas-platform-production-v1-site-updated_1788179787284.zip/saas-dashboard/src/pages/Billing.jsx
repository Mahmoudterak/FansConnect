import React, { useEffect, useState } from 'react';
import { api } from '../api/client';
import { useNavigate } from 'react-router-dom';

export default function Billing() {
  const navigate = useNavigate();
  const [plans, setPlans] = useState([]);
  const [subscription, setSubscription] = useState(null);
  const [pendingInvoice, setPendingInvoice] = useState(null);
  const [loading, setLoading] = useState(true);
  const [subscribing, setSubscribing] = useState(null);
  const [error, setError] = useState('');

  async function loadAll() {
    const [plansData, subData, pendingData] = await Promise.all([
      api.getPlans(),
      api.getSubscription().catch(() => null),
      api.getPendingInvoice().catch(() => null),
    ]);
    setPlans(plansData);
    setSubscription(subData);
    setPendingInvoice(pendingData);
    setLoading(false);
  }

  useEffect(() => {
    loadAll();
  }, []);

  async function handleSubscribe(planId) {
    setError('');
    setSubscribing(planId);
    try {
      const { paymentUrl } = await api.subscribe(planId);
      // نفتح رابط الدفع مباشرة بصفحة Ziina المستضافة
      window.location.href = paymentUrl;
    } catch (err) {
      setError(err.message);
      setSubscribing(null);
    }
  }

  if (loading) return <div className="empty-state">جاري التحميل...</div>;

  return (
    <div>
      <div className="page-header">
        <h1>الاشتراك والفوترة</h1>
        <p>إدارة باقتك والفواتير عبر Ziina</p>
      </div>

      {pendingInvoice && (
        <div className="card" style={{ borderColor: 'var(--warning)' }}>
          <h2>⚠️ فاتورة بانتظار الدفع</h2>
          <p>
            المبلغ: <strong>{pendingInvoice.amount} {pendingInvoice.currency}</strong>
          </p>
          <a className="btn" href={pendingInvoice.paymentUrl} target="_blank" rel="noreferrer">
            أكمل الدفع الآن
          </a>
        </div>
      )}

      {subscription && (
        <div className="card">
          <h2>باقتك الحالية</h2>
          <p>
            <strong>{subscription.plan?.name}</strong> —{' '}
            <span className={`badge ${subscription.status?.toLowerCase()}`}>{subscription.status}</span>
          </p>
          {subscription.currentPeriodEnd && (
            <p style={{ fontSize: 13, color: 'var(--muted)' }}>
              التجديد القادم: {new Date(subscription.currentPeriodEnd).toLocaleDateString('ar-AE')}
            </p>
          )}
          {['ACTIVE', 'TRIAL'].includes(subscription.status) && <button className="btn" onClick={() => navigate('/app/onboarding')}>متابعة إعداد مساحة العمل →</button>}
        </div>
      )}

      <div className="card">
        <h2>الباقات المتاحة</h2>
        {error && <div className="error-text">{error}</div>}
        <div className="plans-grid">
          {plans.map((plan) => (
            <div className="plan-card" key={plan.id}>
              <h3>{plan.name}</h3>
              <div className="price">
                {plan.priceMonthly} {plan.currency}
                <span style={{ fontSize: 12, color: 'var(--muted)' }}> /شهرياً</span>
              </div>
              <ul>
                {(plan.features || []).map((f, i) => (
                  <li key={i}>✓ {f}</li>
                ))}
              </ul>
              <button
                className="btn"
                disabled={subscribing === plan.id || subscription?.plan?.id === plan.id}
                onClick={() => handleSubscribe(plan.id)}
                style={{ width: '100%' }}
              >
                {subscription?.plan?.id === plan.id
                  ? 'باقتك الحالية'
                  : subscribing === plan.id
                  ? 'جاري التحويل...'
                  : 'اشترك الآن'}
              </button>
            </div>
          ))}
        </div>
      </div>

      {subscription?.invoices?.length > 0 && (
        <div className="card">
          <h2>سجل الفواتير</h2>
          <table>
            <thead>
              <tr>
                <th>التاريخ</th>
                <th>المبلغ</th>
                <th>الحالة</th>
              </tr>
            </thead>
            <tbody>
              {subscription.invoices.map((inv) => (
                <tr key={inv.id}>
                  <td>{new Date(inv.issuedAt).toLocaleDateString('ar-AE')}</td>
                  <td>
                    {inv.amount} {inv.currency}
                  </td>
                  <td>
                    <span className={`badge ${inv.status?.toLowerCase()}`}>{inv.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
