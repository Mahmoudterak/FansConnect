import React, { useEffect, useState } from 'react';
import { api } from '../api/client';

const config = {
  faq: { title: 'الأسئلة الشائعة', subtitle: 'أجوبة فورية بلا استهلاك AI', load: api.getFaqs, create: api.createFaq, remove: api.deleteFaq, fields: ['question', 'answer', 'keywords', 'category'], labels: ['السؤال', 'الإجابة', 'الكلمات المفتاحية (افصل بينها بفاصلة)', 'التصنيف'] },
  'auto-replies': { title: 'الردود التلقائية', subtitle: 'قواعد أولوية تعمل قبل نموذج الذكاء الاصطناعي', load: api.getAutoReplies, create: api.createAutoReply, remove: api.deleteAutoReply, fields: ['name', 'keywords', 'reply'], labels: ['اسم القاعدة', 'الكلمات المطلوبة (افصل بينها بفاصلة)', 'الرد'] },
  training: { title: 'أمثلة التدريب', subtitle: 'وجّه أسلوب الرد دون تجاوز قواعد السلامة', load: api.getExamples, create: api.createExample, fields: ['customerMessage', 'ownerReply', 'note'], labels: ['رسالة العميل', 'الرد المثالي', 'ملاحظة'] },
  flows: { title: 'التدفقات', subtitle: 'ابنِ رحلة محادثة قابلة للتشغيل قبل AI', load: api.getFlows, create: api.createFlow, fields: ['name', 'triggerKeywords'], labels: ['اسم التدفق', 'كلمات التشغيل (افصل بينها بفاصلة)'] },
  catalog: { title: 'الخدمات والمنتجات', subtitle: 'مصدر الأسعار والمعلومات المعتمدة للبوت', load: api.getCatalog, create: api.createCatalogItem, remove: api.deleteCatalogItem, fields: ['name', 'description', 'price', 'type'], labels: ['الاسم', 'الوصف', 'السعر', 'النوع'] },
};

export default function WorkspaceManager({ type }) {
  const current = config[type];
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  async function load() { setLoading(true); try { setItems(await current.load()); } catch (e) { setError(e.message); } finally { setLoading(false); } }
  useEffect(() => { load(); }, [type]);
  function update(field, value) { setForm((old) => ({ ...old, [field]: value })); }
  async function submit(event) {
    event.preventDefault(); setError(''); setSaving(true);
    try {
      const payload = { ...form };
      if (payload.keywords) payload.keywords = payload.keywords.split(',').map((x) => x.trim()).filter(Boolean);
      if (type === 'flows') payload.definition = { nodes: [{ id: 'start', type: 'START', label: 'بداية' }, { id: 'message', type: 'MESSAGE', label: 'رسالة', config: { text: 'مرحباً بك! كيف يمكننا مساعدتك؟' } }, { id: 'end', type: 'END', label: 'نهاية' }] };
      await current.create(payload); setForm({}); await load();
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  }
  async function remove(id) { if (!window.confirm('حذف هذا العنصر؟')) return; await current.remove(id); await load(); }

  if (!current) return null;
  return <div>
    <div className="page-header"><h1>{current.title}</h1><p>{current.subtitle}</p></div>
    <div className="split-grid">
      <form className="card" onSubmit={submit}><h2>إضافة جديد</h2>
        {current.fields.map((field, index) => <div className="field" key={field}><label>{current.labels[index]}</label>
          {['answer', 'reply', 'note', 'description', 'ownerReply'].includes(field) ? <textarea rows={field === 'note' ? 2 : 4} value={form[field] || ''} onChange={(e) => update(field, e.target.value)} required={field !== 'note'} /> : <input value={form[field] || ''} onChange={(e) => update(field, e.target.value)} required={field !== 'price'} type={field === 'price' ? 'number' : 'text'} />}
        </div>)}
        {error && <div className="error-text">{error}</div>}<button className="btn" disabled={saving}>{saving ? 'جاري الحفظ…' : 'حفظ'}</button>
      </form>
      <div className="card"><h2>المحفوظ ({items.length})</h2>{loading ? <div className="empty-state">جاري التحميل…</div> : !items.length ? <div className="empty-state">لا توجد عناصر بعد</div> : <div className="stack-list">{items.map((item) => <div className="list-item" key={item.id}><div><strong>{item.name || item.question || item.customerMessage}</strong><small>{item.reply || item.answer || item.ownerReply || item.description || (item.triggerKeywords || []).join('، ')}</small></div>{current.remove && <button className="icon-btn" onClick={() => remove(item.id)} aria-label="حذف">×</button>}</div>)}</div>}</div>
    </div>
  </div>;
}