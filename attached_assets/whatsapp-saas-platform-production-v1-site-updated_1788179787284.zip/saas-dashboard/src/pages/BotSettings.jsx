import React,{useEffect,useState} from 'react';
import {api} from '../api/client';

const types=[['GENERAL','نشاط عام'],['RETAIL','متجر'],['RESTAURANT','مطعم / كافيه'],['CLINIC','عيادة / مركز طبي'],['DENTAL','عيادة أسنان'],['SALON','صالون / سبا'],['REAL_ESTATE','عقارات'],['AUTOMOTIVE','سيارات'],['EDUCATION','تعليم / تدريب'],['HOTEL','فندق / ضيافة'],['HOME_SERVICES','خدمات منزلية']];
export default function BotSettings(){
 const [data,setData]=useState({activityType:'GENERAL',botSettings:{personality:'ودود ومحترف',dialect:'عربية خليجية',responseLength:'مختصر'},knowledgeBase:[]});
 const [saved,setSaved]=useState(false); const [error,setError]=useState('');
 useEffect(()=>api.getBotConfig?.().then(setData).catch(()=>{}),[]);
 const update=(k,v)=>setData(d=>({...d,botSettings:{...d.botSettings,[k]:v}}));
 async function save(){setError('');try{await api.updateBotConfig(data);setSaved(true)}catch(e){setError(e.message)}}
 return <div><div className="page-header"><h1>إعدادات البوت 🤖</h1><p>خصص البوت حسب نوع نشاطك وطريقة تواصلك مع العملاء.</p></div><div className="card">
 <div className="field"><label>نوع النشاط</label><select value={data.activityType} onChange={e=>setData({...data,activityType:e.target.value})}>{types.map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></div>
 <div className="field"><label>الشخصية</label><input value={data.botSettings?.personality||''} onChange={e=>update('personality',e.target.value)}/></div>
 <div className="field"><label>اللهجة</label><input value={data.botSettings?.dialect||''} onChange={e=>update('dialect',e.target.value)}/></div>
 <div className="field"><label>طول الرد</label><select value={data.botSettings?.responseLength||'مختصر'} onChange={e=>update('responseLength',e.target.value)}><option>مختصر</option><option>متوسط</option><option>مفصل</option></select></div>
 <div className="field"><label>تعليمات إضافية</label><textarea rows="7" value={data.botSettings?.extraInstructions||''} onChange={e=>update('extraInstructions',e.target.value)} placeholder="قواعد خاصة بنشاطك..."/></div>
 {error&&<div className="error-text">{error}</div>}{saved&&<div className="success-text">تم الحفظ بنجاح ✅</div>}<button className="btn" onClick={save}>حفظ الإعدادات</button>
 </div></div>
}
