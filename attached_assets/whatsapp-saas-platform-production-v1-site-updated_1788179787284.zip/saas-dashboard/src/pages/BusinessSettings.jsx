import React, { useEffect, useState } from 'react';
import { api } from '../api/client';

const emptyInfo = { name: '', workingHours: '', services: [], contactPhone: '', notes: '' };

export default function BusinessSettings() {
  const [info, setInfo] = useState(emptyInfo);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .getMe()
      .then((tenant) => setInfo({ ...emptyInfo, ...tenant.businessInfo }))
      .finally(() => setLoading(false));
  }, []);

  function updateField(field, value) {
    setInfo((prev) => ({ ...prev, [field]: value }));
    setSaved(false);
  }

  function updateService(index, field, value) {
    const services = [...info.services];
    services[index] = { ...services[index], [field]: value };
    updateField('services', services);
  }

  function addService() {
    updateField('services', [...info.services, { name: '', price: '' }]);
  }

  function removeService(index) {
    updateField(
      'services',
      info.services.filter((_, i) => i !== index)
    );
  }

  async function handleSave(e) {
    e.preventDefault();
    setError('');
    try {
      await api.updateBusinessInfo(info);
      setSaved(true);
    } catch (err) {
      setError(err.message);
    }
  }

  if (loading) return <div className="empty-state">جاري التحميل...</div>;

  return (
    <div>
      <div className="page-header">
        <h1>معلومات النشاط التجاري</h1>
        <p>هذي المعلومات يعتمد عليها البوت ليرد على عملائك بدقة، بدون ما يخترع معلومات غلط</p>
      </div>

      <form className="card" onSubmit={handleSave}>
        <div className="field">
          <label>اسم النشاط</label>
          <input value={info.name} onChange={(e) => updateField('name', e.target.value)} required />
        </div>

        <div className="field">
          <label>ساعات العمل</label>
          <input
            value={info.workingHours}
            onChange={(e) => updateField('workingHours', e.target.value)}
            placeholder="مثال: من السبت إلى الخميس، 9 صباحاً حتى 9 مساءً"
          />
        </div>

        <div className="field">
          <label>رقم تواصل بديل</label>
          <input value={info.contactPhone} onChange={(e) => updateField('contactPhone', e.target.value)} />
        </div>

        <div className="field">
          <label>الخدمات والأسعار</label>
          {info.services.map((service, i) => (
            <div className="service-row" key={i}>
              <input
                placeholder="اسم الخدمة"
                value={service.name}
                onChange={(e) => updateService(i, 'name', e.target.value)}
              />
              <input
                placeholder="السعر"
                value={service.price}
                onChange={(e) => updateService(i, 'price', e.target.value)}
              />
              <button type="button" className="btn secondary" onClick={() => removeService(i)}>
                حذف
              </button>
            </div>
          ))}
          <button type="button" className="btn secondary" onClick={addService}>
            + إضافة خدمة
          </button>
        </div>

        <div className="field">
          <label>ملاحظات إضافية (العنوان، سياسة الإلغاء، إلخ)</label>
          <textarea rows={4} value={info.notes} onChange={(e) => updateField('notes', e.target.value)} />
        </div>

        {error && <div className="error-text">{error}</div>}
        {saved && <div className="success-text">تم الحفظ بنجاح ✅</div>}

        <button className="btn" type="submit" style={{ marginTop: 12 }}>
          حفظ التغييرات
        </button>
      </form>
    </div>
  );
}
