import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext.jsx';

const statusLabels = {
  TRIAL: 'تجريبي',
  ACTIVE: 'فعّال',
  SUSPENDED: 'موقوف',
  CANCELED: 'ملغى',
};

export default function Dashboard() {
  const { tenant } = useAuth();
  const [subscription, setSubscription] = useState(null);
  const [leadsCount, setLeadsCount] = useState(null);
  const [appointmentsCount, setAppointmentsCount] = useState(null);

  useEffect(() => {
    api.getSubscription().then(setSubscription).catch(() => {});
    api.getLeads().then((l) => setLeadsCount(l.length)).catch(() => {});
    api.getAppointments().then((a) => setAppointmentsCount(a.length)).catch(() => {});
  }, []);

  return (
    <div>
      <div className="page-header">
        <h1>مرحباً، {tenant?.name}</h1>
        <p>نظرة سريعة على حالة حسابك</p>
      </div>

      <div className="card">
        <h2>حالة الحساب</h2>
        <p>
          الحالة: <span className={`badge ${tenant?.status?.toLowerCase()}`}>
            {statusLabels[tenant?.status] || tenant?.status}
          </span>
        </p>
        <p>
          ربط واتساب:{' '}
          {tenant?.whatsappConnected ? (
            <span className="badge active">مربوط ✅</span>
          ) : (
            <span className="badge past_due">غير مربوط بعد</span>
          )}
        </p>
        {!tenant?.whatsappConnected && (
          <p style={{ fontSize: 14 }}>
            <Link to="/app/whatsapp-settings">اربط رقم واتساب الآن ←</Link>
          </p>
        )}
      </div>

      <div className="card">
        <h2>الاشتراك</h2>
        {subscription ? (
          <p>
            الباقة: <strong>{subscription.plan?.name}</strong> —{' '}
            <span className={`badge ${subscription.status?.toLowerCase()}`}>{subscription.status}</span>
          </p>
        ) : (
          <p>ما عندك اشتراك فعّال بعد. <Link to="/app/billing">اختر باقة ←</Link></p>
        )}
      </div>

      <div className="card">
        <h2>نشاط البوت</h2>
        <p>عدد العملاء المحتملين المسجَّلين: <strong>{leadsCount ?? '...'}</strong></p>
        <p>عدد المواعيد المحجوزة: <strong>{appointmentsCount ?? '...'}</strong></p>
      </div>
    </div>
  );
}
