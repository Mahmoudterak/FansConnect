import React, { useEffect, useState } from 'react';
import { api } from '../api/client';

export default function Appointments() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getAppointments().then(setAppointments).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="page-header">
        <h1>المواعيد المحجوزة</h1>
        <p>كل المواعيد اللي حجزها البوت مباشرة عبر محادثات واتساب</p>
      </div>

      <div className="card">
        {loading ? (
          <div className="empty-state">جاري التحميل...</div>
        ) : appointments.length === 0 ? (
          <div className="empty-state">ما فيه مواعيد محجوزة بعد</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>الاسم</th>
                <th>الرقم</th>
                <th>الخدمة</th>
                <th>التاريخ</th>
                <th>الوقت</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map((a) => (
                <tr key={a.id}>
                  <td>{a.name || '—'}</td>
                  <td>{a.phone || '—'}</td>
                  <td>{a.service || '—'}</td>
                  <td>{a.date || '—'}</td>
                  <td>{a.time || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
