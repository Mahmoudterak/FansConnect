import React, { useState } from 'react';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext.jsx';

export default function WhatsAppSettings() {
  const { tenant, refreshTenant } = useAuth();
  const [phoneNumberId, setPhoneNumberId] = useState('');
  const [accessToken, setAccessToken] = useState('');
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  const [testTo, setTestTo] = useState('');
  const [testMessage, setTestMessage] = useState('مرحباً، هذه رسالة تجريبية ✅');
  const [testResult, setTestResult] = useState('');

  async function handleSave(e) {
    e.preventDefault();
    setError('');
    try {
      await api.updateWhatsAppConfig({
        whatsappPhoneNumberId: phoneNumberId,
        whatsappAccessToken: accessToken,
      });
      setSaved(true);
      refreshTenant();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleTest(e) {
    e.preventDefault();
    setTestResult('');
    try {
      await api.testWhatsApp({ to: testTo, message: testMessage });
      setTestResult('✅ تم إرسال الرسالة بنجاح، تحقق من واتسابك');
    } catch (err) {
      setTestResult(`❌ ${err.message}`);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h1>ربط واتساب</h1>
        <p>اربط رقم WhatsApp Business API الرسمي الخاص بنشاطك</p>
      </div>

      <div className="card">
        <h2>
          الحالة الحالية:{' '}
          {tenant?.whatsappConnected ? (
            <span className="badge active">مربوط ✅</span>
          ) : (
            <span className="badge past_due">غير مربوط</span>
          )}
        </h2>
      </div>

      <form className="card" onSubmit={handleSave}>
        <h2>بيانات الربط</h2>
        <p style={{ fontSize: 13, color: 'var(--muted)' }}>
          تجدها بصفحة WhatsApp &gt; API Setup داخل حسابك على Meta for Developers.
        </p>
        <div className="field">
          <label>Phone Number ID</label>
          <input value={phoneNumberId} onChange={(e) => setPhoneNumberId(e.target.value)} required />
        </div>
        <div className="field">
          <label>Access Token</label>
          <input
            type="password"
            value={accessToken}
            onChange={(e) => setAccessToken(e.target.value)}
            required
          />
        </div>
        {error && <div className="error-text">{error}</div>}
        {saved && <div className="success-text">تم حفظ بيانات الربط ✅</div>}
        <button className="btn" type="submit">
          حفظ الربط
        </button>
      </form>

      <form className="card" onSubmit={handleTest}>
        <h2>اختبار سريع</h2>
        <div className="field">
          <label>رقم واتساب للاختبار (بصيغة دولية بدون +)</label>
          <input value={testTo} onChange={(e) => setTestTo(e.target.value)} placeholder="9715xxxxxxxx" required />
        </div>
        <div className="field">
          <label>نص الرسالة</label>
          <input value={testMessage} onChange={(e) => setTestMessage(e.target.value)} />
        </div>
        {testResult && <div style={{ marginBottom: 12, fontSize: 14 }}>{testResult}</div>}
        <button className="btn secondary" type="submit">
          إرسال رسالة تجريبية
        </button>
      </form>
    </div>
  );
}
