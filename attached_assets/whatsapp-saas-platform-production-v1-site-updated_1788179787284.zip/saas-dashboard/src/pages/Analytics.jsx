import React, { useEffect, useState } from 'react';
import { api } from '../api/client';
export default function Analytics() {
  const [data, setData] = useState(null);
  useEffect(() => { api.getAnalytics().then(setData); }, []);
  const cards = [['messages', 'الرسائل'], ['conversations', 'المحادثات'], ['leads', 'العملاء المحتملون'], ['appointments', 'المواعيد'], ['aiRequests', 'طلبات AI'], ['handoffs', 'تحويلات الموظفين']];
  return <div><div className="page-header"><h1>التحليلات</h1><p>صورة تشغيلية لاستخدام المنصة وجودة الأتمتة</p></div>{!data ? <div className="empty-state">جاري التحميل…</div> : <><div className="metrics-grid">{cards.map(([key, label]) => <div className="metric-card" key={key}><small>{label}</small><strong>{Number(data[key] || 0).toLocaleString('ar-AE')}</strong></div>)}</div><div className="card"><h2>استهلاك الذكاء الاصطناعي</h2><p>Input tokens: <strong>{data.inputTokens}</strong> · Output tokens: <strong>{data.outputTokens}</strong></p><p className="muted">التكلفة التقديرية: {String(data.estimatedCost || 0)}</p></div></>}</div>;
}