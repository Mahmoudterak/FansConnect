import React, { useEffect, useState } from 'react';
import { api } from '../api/client';

export default function Leads() {
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getLeads().then(setLeads).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="page-header">
        <h1>العملاء المحتملون</h1>
        <p>كل من جمع البوت بياناتهم تلقائياً من محادثات واتساب</p>
      </div>

      <div className="card">
        {loading ? (
          <div className="empty-state">جاري التحميل...</div>
        ) : leads.length === 0 ? (
          <div className="empty-state">ما فيه عملاء محتملون بعد</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>التاريخ</th>
                <th>الاسم</th>
                <th>الرقم</th>
                <th>الاهتمام</th>
              </tr>
            </thead>
            <tbody>
              {leads.map((lead) => (
                <tr key={lead.id}>
                  <td>{new Date(lead.createdAt).toLocaleDateString('ar-AE')}</td>
                  <td>{lead.name || '—'}</td>
                  <td>{lead.phone || '—'}</td>
                  <td>{lead.interest || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
