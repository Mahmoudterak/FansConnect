# SaaS V2 — Multi-Activity AI Engine

تم توسيع الأساس ليكون عاماً لمختلف الأنشطة.

## Activity Types
GENERAL, RETAIL, RESTAURANT, CLINIC, DENTAL, SALON, REAL_ESTATE, AUTOMOTIVE, EDUCATION, HOTEL, HOME_SERVICES, PROFESSIONAL_SERVICES, OTHER.

## New tenant data
- activityType
- botSettings
- knowledgeBase

## New modules
FAQ, AutoReplyRule, ConversationFlow, FlowNode, CatalogItem, BusinessHour, PaymentMethod, TrainingExample, Contact, Message, Handoff, AIUsage, AuditLog, WebhookEvent, Order, Campaign.

## Token-saving strategy
The Conversation Engine now evaluates FAQ, Auto Reply, and active Flow message nodes before OpenAI. لذلك الأسئلة المتكررة والردود والقواعد يمكن أن تعمل بدون استدعاء AI.

## Production hardening included
- Tenant-scoped queries for all dashboard data routes.
- Composite tenant constraints, webhook idempotency, and message history.
- Encrypted WhatsApp access tokens at rest (`SECRETS_ENCRYPTION_KEY`).
- Request IDs, security headers, JSON size limits, and a lightweight rate limiter.
- Dynamic activity-aware prompts with configurable safety and handoff behavior.
- Messaging provider abstraction for WhatsApp Cloud and Sends Bot with retry on transient errors.
- Node tests for FAQ, Auto Reply, Flow routing, and dental safety context.

## Important
بعد تحديث schema يجب تشغيل `npm run prisma:generate` ثم migration على قاعدة البيانات.
هذا الإصدار لا يزعم توفر موعد فعلي ما لم تتم إضافة تكامل مع نظام مواعيد حقيقي.
