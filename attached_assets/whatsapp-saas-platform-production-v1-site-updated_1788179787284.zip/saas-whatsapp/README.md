# SahaAI — منصة SaaS عامة متعددة الأنشطة لـ WhatsApp وInstagram

هذا التسليم يحتوي على تطبيق الويب الكامل: موقع تسويقي عام، تسجيل وإنشاء مساحة عمل واختيار نشاط
وفوترة وتهيئة، ثم لوحة عميل متعددة المستأجرين، مع API واحد ومصادقة مشتركة بين الموقع والتطبيق.
الواجهة العربية RTL والإنجليزية LTR، والبيانات معزولة لكل Tenant.

## خارطة الطريق الكاملة

| المرحلة | الحالة | المحتوى |
|---|---|---|
| **1. الأساس** | ✅ جاهزة | قاعدة بيانات، تسجيل حسابات، تسجيل دخول، إدارة باقات |
| **2. ربط واتساب** | ✅ جاهزة | ربط WhatsApp Business API الرسمي بشكل مستقل لكل عميل + رد آلي فعلي |
| **3. الفوترة** | ✅ جاهزة بهذا التسليم | اشتراكات وفوترة عبر Ziina (روابط دفع) |
| **4. منصة الويب العامة ولوحة العميل** | ✅ جاهزة | Landing، Features، Pricing، FAQ، Contact، Auth، Onboarding وDashboard |
| **5. التشغيل المؤسسي** | ✅ الأساس جاهز | Super Admin API/UI، limits، audit، readiness، Docker وVPS deployment |

---

## المرحلة 3: الاشتراكات والفوترة عبر Ziina (تفاصيل)

### ⚠️ فرق جوهري لازم تعرفه
Ziina (بعكس Moyasar/Stripe) **ما يوفر تحصيل تلقائي صامت** من بطاقة محفوظة. الـ API عندهم مبني على
**Payment Intent**: تنشئ طلب دفع، يرجع لك رابط (صفحة دفع مستضافة عند Ziina)، والعميل يفتحه ويدفع
بنفسه (بطاقة/Apple Pay/Google Pay). فبدل "خصم شهري تلقائي بدون تدخل"، النظام الآن يشتغل بمبدأ
**"فاتورة + رابط دفع"**:

- أول اشتراك: يفتح العميل رابط الدفع ويدفع بنفسه، يتفعّل اشتراكه فوراً بعد التأكيد.
- كل شهر: تنشئ المهمة المجدولة **فاتورة جديدة برابط دفع جديد** تلقائياً، وتحوّل حالة الاشتراك
  مؤقتاً لـ `PAST_DUE` لحين ما يدفع العميل (يرجع تلقائياً `ACTIVE` فور تأكيد الدفع).
- بالمرحلة 4 (لوحة التحكم) بنعرض للعميل زر "أكمل الدفع" واضح كل ما توجد فاتورة معلّقة.

### تدفق العملية بالكامل

**1) الحصول على مفاتيح Ziina:**
من لوحة تحكم Ziina Business > API/Developers، ولّد **Access Token** بصلاحية
`write_payment_intents` (و `write_webhooks` لإعداد الويب هوك). ضعه بـ `ZIINA_API_KEY`.

**2) بدء اشتراك جديد:**
```bash
curl -X POST http://localhost:4000/api/billing/subscribe \
  -H "Authorization: Bearer التوكن_تبع_تسجيل_دخول_العميل" \
  -H "Content-Type: application/json" \
  -d '{"planId": "معرف_الباقة"}'
```
يرجع لك:
```json
{ "paymentUrl": "https://pay.ziina.com/...", "invoiceId": "..." }
```
حوّل العميل (أو افتح له) لـ `paymentUrl` عشان يكمل الدفع.

**3) إعداد الويب هوك بلوحة Ziina:**
سجّل الويب هوك مرة وحدة (عبر API أو لوحة التحكم لو متوفرة):
```bash
curl -X POST https://api-v2.ziina.com/api/webhook \
  -H "Authorization: Bearer $ZIINA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://yourdomain.com/webhook/ziina", "secret": "نفس_قيمة_ZIINA_WEBHOOK_SECRET"}'
```
> للتجربة المحلية استخدم [ngrok](https://ngrok.com) للحصول على رابط `https` مؤقت.

**4) التجديد الشهري:**
مهمة `src/jobs/renewSubscriptions.js` تشتغل تلقائياً يومياً الساعة 3 فجراً، تنشئ فاتورة ورابط دفع
جديد لكل اشتراك مستحق. حالياً الرابط يُطبع بالطرفية (Terminal) ويُخزَّن بجدول `Invoice` — بالمرحلة 4
رح نعرضه مباشرة بلوحة تحكم العميل (أو نضيف إشعار بريد إلكتروني لاحقاً).

**5) التحقق من فاتورة معلّقة (تُستخدم بلوحة التحكم لاحقاً):**
```bash
curl http://localhost:4000/api/billing/pending-invoice \
  -H "Authorization: Bearer التوكن"
```

### حالات الاشتراك
| الحالة | المعنى |
|---|---|
| `TRIALING` | حساب جديد، لسا ما دفع أول فاتورة |
| `ACTIVE` | آخر فاتورة مدفوعة، الخدمة شغّالة |
| `PAST_DUE` | فيه فاتورة معلّقة (أول اشتراك أو تجديد) بانتظار الدفع |
| `CANCELED` | ألغى العميل اشتراكه |

### ملاحظة مهمة
جدول `Plan` فيه أسعار تجريبية بعملة SAR بملف `prisma/seed.js` — بما إنك بالإمارات، حدّث `currency`
لـ `AED` والأسعار لما يناسبك قبل الإطلاق. وابدأ بـ `ZIINA_TEST_MODE="true"` للتجربة الكاملة (بيانات
بطاقات وهمية، بدون تحصيل فعلي) قبل التحويل للوضع الحقيقي.

---

## المرحلة 2: ربط واتساب (تفاصيل)

### الفكرة المعمارية
- رابط ويب هوك **واحد فقط** لكل المنصة (`/webhook/whatsapp`)، تسجّله مرة وحدة بلوحة تحكم تطبيقك بـ Meta for Developers.
- كل رسالة واردة تجي مع `phone_number_id` يحدد لأي رقم أُرسلت، ونستخدمه لمعرفة أي مستأجر يخصه تلقائياً.
- كل مستأجر يخزّن `whatsappPhoneNumberId` و `whatsappAccessToken` الخاصين به بجدول `Tenant`.
- مفتاح **OpenAI واحد على مستوى المنصة** (تدفعه أنت كمزوّد خدمة، وتحمّل تكلفته ضمن سعر الاشتراك)، والذكاء الاصطناعي يقرأ `businessInfo` الخاص بكل مستأجر من قاعدة البيانات ليرد بسياق نشاطه هو فقط.

### خطوات الربط الفعلي

**1) إعداد الويب هوك بلوحة Meta:**
اذهب لتطبيقك بـ [Meta for Developers](https://developers.facebook.com) > WhatsApp > Configuration، وحط:
- **Callback URL:** رابط سيرفرك + `/webhook/whatsapp` (مثال: `https://yourdomain.com/webhook/whatsapp`)
  - للتجربة المحلية استخدم [ngrok](https://ngrok.com): `ngrok http 4000` وخذ الرابط اللي يعطيك.
- **Verify Token:** نفس القيمة الموجودة بـ `WHATSAPP_WEBHOOK_VERIFY_TOKEN` بملف `.env`

اشترك (Subscribe) بحقل `messages` عشان يوصلك إشعار كل رسالة واردة.

**2) ربط رقم كل عميل مشترك:**
بعد ما يسجّل العميل حساب (`/api/auth/register`) ويسوّي دخول، من لوحة تحكمه (أو مؤقتاً عبر API مباشرة)
يدخل بيانات رقمه من صفحة **WhatsApp > API Setup** بحسابه على Meta:

```bash
curl -X PUT http://localhost:4000/api/tenants/me/whatsapp-config \
  -H "Authorization: Bearer التوكن_تبع_تسجيل_دخوله" \
  -H "Content-Type: application/json" \
  -d '{
    "whatsappPhoneNumberId": "1234567890",
    "whatsappAccessToken": "EAAxxxxxxxxxxxxxxxxx"
  }'
```

> ⚠️ التوكن المؤقت اللي يعطيك إياه Meta بصفحة الاختبار صلاحيته 24 ساعة فقط. للإنتاج، سوّي
> **System User** بإعدادات Business Manager وولّد له **توكن دائم** بصلاحية `whatsapp_business_messaging`.

**3) اختبار الربط:**
```bash
curl -X POST http://localhost:4000/api/tenants/me/whatsapp-test \
  -H "Authorization: Bearer التوكن" \
  -H "Content-Type: application/json" \
  -d '{"to": "9665xxxxxxx", "message": "مرحباً، هذه رسالة تجريبية"}'
```

**4) التجربة الفعلية:**
أرسل رسالة واتساب حقيقية لرقم العميل المربوط، وراقب الطرفية (Terminal) — بتشوف الرسالة الواردة
ورد الذكاء الاصطناعي تلقائياً بنفس اللهجة.

### ملاحظة مهمة للتوسّع مستقبلاً (Scale)
هذا التصميم يفترض إن كل مستأجر يربط رقمه بشكل يدوي بتوكن خاص فيه (مناسب تماماً للبداية وحتى عشرات
العملاء). لو حبيت لاحقاً تسهّل العملية بحيث "يربط رقمه بضغطة زر" بدون ما يدخل تفاصيل تقنية، هذا
يحتاج التسجيل ببرنامج **Meta Tech Provider / Embedded Signup** وهي عملية اعتماد إضافية من Meta،
نقدر نناقشها لاحقاً لو المشروع كبر.

---

## ما تم بناؤه بهذه المرحلة

- **عزل كامل بين العملاء (Multi-tenancy):** كل نشاط تجاري مسجّل = `Tenant` مستقل، ببياناته
  (عملاء محتملين، مواعيد، محادثات) منفصلة تمامًا عن أي مستأجر آخر.
- **تسجيل الحسابات وتسجيل الدخول:** `POST /api/auth/register` و `POST /api/auth/login` مع تشفير
  كلمات المرور (bcrypt) وجلسات آمنة عبر JWT.
- **إدارة الباقات:** جدول `Plan` قابل للتعديل من قاعدة البيانات مباشرة أو عبر سكربت `prisma/seed.js`.
- **هيكل جاهز للفوترة والويب هوك:** ملفات `billing.js` و `whatsapp.js` فيها المسارات والتعليقات
  اللي توضح بالضبط وين رح يُبنى التكامل الفعلي بالمراحل القادمة.

---

## التشغيل المحلي

### 1) تثبيت المتطلبات
تحتاج **PostgreSQL** مثبت (محلي أو خدمة سحابية مثل Supabase/Railway/Neon).

```bash
npm install
```

### 2) إعداد `.env`
```bash
cp .env.example .env
```
عبّي `DATABASE_URL` برابط قاعدة بياناتك، و`JWT_SECRET` بقيمة عشوائية طويلة.

### 3) إنشاء الجداول
```bash
npx prisma migrate dev --name init
```

### 4) تعبئة الباقات الافتراضية (اختياري، تقدر تعدلها بملف `prisma/seed.js` أولاً)
```bash
node prisma/seed.js
```

### 5) تشغيل السيرفر
```bash
npm run dev
```
السيرفر بيشتغل على `http://localhost:4000`

---

## اختبار سريع للـ API

**تسجيل حساب جديد (عميل جديد يشترك بالخدمة):**
```bash
curl -X POST http://localhost:4000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"businessName":"محل تجريبي","email":"owner@example.com","password":"123456"}'
```
بيرجع لك `token` استخدمه بباقي الطلبات:
```bash
curl http://localhost:4000/api/tenants/me \
  -H "Authorization: Bearer التوكن_هنا"
```

**عرض الباقات:**
```bash
curl http://localhost:4000/api/plans
```

---

## نموذج قاعدة البيانات (`prisma/schema.prisma`)
- `Tenant` — النشاط التجاري المشترك (المستأجر)
- `User` — مستخدمو لوحة التحكم لكل مستأجر
- `Plan` — الباقات المعروضة للبيع
- `Subscription` — اشتراك كل مستأجر وحالته
- `Invoice` — الفواتير
- `Lead`, `Appointment`, `Conversation` — بيانات البوت لكل مستأجر (بديل ملفات JSON وGoogle Sheets
  من النسخة السابقة، الآن كل شي بقاعدة بيانات مركزية ومعزولة بالمستأجر)

---

## الخطوة القادمة
جاهزين ننتقل للمرحلة 2: ربط WhatsApp Business API الرسمي بحيث كل مستأجر يوصل رقمه الخاص من
لوحة تحكمه، ويستقبل ويرد على رسائله عبر نفس محرك الذكاء الاصطناعي (OpenAI) اللي بنيناه بالنسخة السابقة،
لكن هذي المرة يقرأ `businessInfo` الخاص بكل مستأجر من قاعدة البيانات بدل ملف ثابت.

---

## الإصدار production-v1 في هذا التسليم

تم تطوير الأساس السابق بدلاً من إعادة بنائه:

- **Conversation Engine مركزي:** يمرر الرسالة عبر FAQ ثم Auto Reply ثم Flow ثم AI، ولا يستهلك AI عندما توجد إجابة محلية.
- **عزل المستأجرين:** كل route جديد يستخدم `tenantId` المأخوذ من JWT، مع unique/index مركبة على الكيانات التشغيلية.
- **Inbox وCRM:** محادثات ورسائل وجهات اتصال، إسناد وإيقاف/استئناف AI والرد البشري من لوحة التحكم.
- **Activity Profiles:** ملفات مستقلة للعيادات والمتاجر والمطاعم والعقارات وغيرها، تشمل tone/modules/safety/suggested FAQs.
- **أمان:** تشفير access tokens، request IDs، security headers، حد لحجم JSON، rate limiting، audit logs ومنع تكرار webhook.
- **Providers:** طبقة `MessagingProvider` تدعم WhatsApp Cloud وSends Bot مع retry للأخطاء المؤقتة.
- **قياس الاستخدام:** `AIUsage` يسجل النموذج وinput/output tokens والتكلفة التقديرية لكل tenant.

### التشغيل

```bash
cd saas-whatsapp
npm install
cp .env.example .env
npm run prisma:generate
npm run prisma:migrate:deploy
node prisma/seed.js
npm test
npm start
```

للتطوير على قاعدة جديدة يمكن استخدام `npm run prisma:migrate` بدلاً من `prisma:migrate:deploy`.

شغّل لوحة التحكم في terminal آخر:

```bash
cd saas-dashboard
npm install
npm run dev
```

المتغيرات الحساسة لا تُحفظ في Git: `DATABASE_URL`, `JWT_SECRET`, `SECRETS_ENCRYPTION_KEY`, `OPENAI_API_KEY`, `WHATSAPP_WEBHOOK_VERIFY_TOKEN`, `ZIINA_API_KEY`, و`SENDSBOT_API_KEY` عند استخدام Sends Bot.

### Webhooks

- WhatsApp Cloud: `GET/POST /webhook/whatsapp`
- Sends Bot: `POST /webhook/sendsbot`
- Ziina: `POST /webhook/ziina`

اربط كل tenant برقم WhatsApp من `/api/tenants/me/whatsapp-config`. يتم تشفير access token قبل التخزين ولا يظهر في استجابات API. لإضافة Sends Bot، مرّر `channelProvider: "SENDS_BOT"` و`sendsBotDeviceId`، وضع مفتاح API في متغير البيئة.

### ملاحظة نطاق

هذا التسليم يجهز النواة التشغيلية والواجهات الأساسية، لكنه لا يدّعي اكتمال تكامل Instagram/Google Calendar أو جدولة حملات WhatsApp production أو Super Admin متعدد المستأجرين؛ تلك تحتاج provider credentials وسياسات تشغيلية وتكاملات خارجية فعلية.
