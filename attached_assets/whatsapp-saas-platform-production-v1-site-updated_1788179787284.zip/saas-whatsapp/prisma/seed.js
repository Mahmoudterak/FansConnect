// سكربت لتعبئة الباقات الأولية بقاعدة البيانات
// تشغيل: node prisma/seed.js
const prisma = require('../src/config/db');

async function main() {
  const plans = [
    {
      name: 'أساسية',
      priceMonthly: 149,
      currency: 'AED',
      messageLimit: 1000,
      features: ['رد آلي ذكي', 'جمع عملاء محتملين'],
      limits: { messages: 1000, aiTokens: 10000, contacts: 500, flows: 2, campaigns: 0, users: 2, storageMb: 100 },
    },
    {
      name: 'احترافية',
      priceMonthly: 349,
      currency: 'AED',
      messageLimit: 5000,
      features: ['كل ميزات الأساسية', 'حجز مواعيد', 'تحويل لموظف', 'دعم أولوية'],
      limits: { messages: 5000, aiTokens: 75000, contacts: 5000, flows: 10, campaigns: 5, users: 5, storageMb: 1000 },
    },
    {
      name: 'أعمال',
      priceMonthly: 699,
      currency: 'AED',
      messageLimit: 20000,
      features: ['كل ميزات الاحترافية', 'عدة أرقام واتساب', 'تقارير متقدمة'],
      limits: { messages: 20000, aiTokens: 300000, contacts: 25000, flows: 50, campaigns: 50, users: 20, storageMb: 5000 },
    },
  ];

  for (const plan of plans) {
    await prisma.plan.upsert({
      where: { name: plan.name },
      update: plan,
      create: plan,
    });
  }

  console.log('✅ تم إدخال الباقات بنجاح');
}

main()
  .catch((e) => console.error(e))
  .finally(() => prisma.$disconnect());
