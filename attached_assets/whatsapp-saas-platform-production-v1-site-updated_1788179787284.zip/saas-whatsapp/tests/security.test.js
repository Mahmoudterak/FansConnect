const test = require('node:test');
const assert = require('node:assert/strict');
process.env.SECRETS_ENCRYPTION_KEY = 'test-key';
const { encrypt, decrypt } = require('../src/utils/crypto');

test('channel secrets are encrypted at rest and round-trip safely', () => {
  const secret = 'EAA-real-looking-token';
  const stored = encrypt(secret);
  assert.notEqual(stored, secret);
  assert.match(stored, /^enc:v1:/);
  assert.equal(decrypt(stored), secret);
});

test('legacy plaintext values remain readable during migration', () => {
  assert.equal(decrypt('legacy-token'), 'legacy-token');
});