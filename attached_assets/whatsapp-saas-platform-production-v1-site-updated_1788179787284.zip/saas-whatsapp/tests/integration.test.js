const test = require('node:test');
const assert = require('node:assert/strict');

if (!process.env.DATABASE_URL) {
  test('PostgreSQL integration suite (set DATABASE_URL to run)', { skip: true }, () => {});
} else {
  const prisma = require('../src/config/db');
  const { processIncomingMessage } = require('../src/services/conversationEngine');
  const suffix = Date.now().toString();
  let tenantA;
  let tenantB;

  test('tenant-scoped FAQ routing avoids AI and cross-tenant data', async () => {
    tenantA = await prisma.tenant.create({ data: { name: `Integration A ${suffix}`, faqs: { create: { question: 'كم السعر؟', answer: '100 AED', keywords: ['السعر'] } } } });
    tenantB = await prisma.tenant.create({ data: { name: `Integration B ${suffix}`, faqs: { create: { question: 'كم السعر؟', answer: '200 AED', keywords: ['السعر'] } } } });
    const conversation = await prisma.conversation.create({ data: { tenantId: tenantA.id, waChatId: `971500${suffix}` } });
    const result = await processIncomingMessage({ tenant: tenantA, conversation, userMessage: 'كم السعر؟', contactNumber: conversation.waChatId });
    assert.equal(result.route, 'FAQ');
    assert.equal(result.reply, '100 AED');
    assert.equal(await prisma.aIUsage.count({ where: { tenantId: tenantA.id } }), 0);
    assert.equal((await prisma.fAQ.findMany({ where: { tenantId: tenantA.id } })).length, 1);
    assert.equal((await prisma.fAQ.findMany({ where: { tenantId: tenantB.id } })).length, 1);
  });

  test('webhook event uniqueness prevents duplicate processing records', async () => {
    await prisma.webhookEvent.create({ data: { tenantId: tenantA.id, provider: 'TEST', externalId: `event-${suffix}` } });
    await assert.rejects(() => prisma.webhookEvent.create({ data: { tenantId: tenantA.id, provider: 'TEST', externalId: `event-${suffix}` } }), (error) => error.code === 'P2002');
  });

  test.after(async () => {
    if (tenantA && tenantB) {
      for (const tenantId of [tenantA.id, tenantB.id]) {
        await prisma.message.deleteMany({ where: { tenantId } });
        await prisma.handoff.deleteMany({ where: { tenantId } });
        await prisma.aIUsage.deleteMany({ where: { tenantId } });
        await prisma.auditLog.deleteMany({ where: { tenantId } });
        await prisma.webhookEvent.deleteMany({ where: { tenantId } });
        await prisma.conversation.deleteMany({ where: { tenantId } });
        await prisma.fAQ.deleteMany({ where: { tenantId } });
        await prisma.autoReplyRule.deleteMany({ where: { tenantId } });
        await prisma.conversationFlow.deleteMany({ where: { tenantId } });
        await prisma.trainingExample.deleteMany({ where: { tenantId } });
        await prisma.catalogItem.deleteMany({ where: { tenantId } });
        await prisma.appointment.deleteMany({ where: { tenantId } });
        await prisma.lead.deleteMany({ where: { tenantId } });
        await prisma.order.deleteMany({ where: { tenantId } });
        await prisma.campaign.deleteMany({ where: { tenantId } });
        await prisma.contact.deleteMany({ where: { tenantId } });
        await prisma.channel.deleteMany({ where: { tenantId } });
        await prisma.paymentMethod.deleteMany({ where: { tenantId } });
        await prisma.businessHour.deleteMany({ where: { tenantId } });
        await prisma.subscription.deleteMany({ where: { tenantId } });
        await prisma.user.deleteMany({ where: { tenantId } });
        await prisma.tenant.delete({ where: { id: tenantId } });
      }
    }
    await prisma.$disconnect();
  });
}