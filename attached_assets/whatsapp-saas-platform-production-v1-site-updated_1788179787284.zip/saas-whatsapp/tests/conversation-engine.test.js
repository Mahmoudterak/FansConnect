const test = require('node:test');
const assert = require('node:assert/strict');
const { faqMatch, autoReplyMatch, flowReply, buildSystemPrompt } = require('../src/services/conversationEngine');

test('exact FAQ wins and is tenant-local by caller supplied data', () => {
  const faq = faqMatch('كم سعر تنظيف الأسنان؟', [
    { question: 'كم سعر تنظيف الأسنان؟', answer: '250 AED', keywords: [], priority: 10 },
    { question: 'سعر الحشو', answer: 'غير ذلك', keywords: ['حشو'], priority: 20 },
  ]);
  assert.equal(faq.answer, '250 AED');
});

test('auto reply supports exact, starts with, regex and multiple keywords', () => {
  assert.equal(autoReplyMatch('حجز', [{ keywords: ['حجز'], matchType: 'EXACT', reply: 'اختر الخدمة', priority: 1 }]).reply, 'اختر الخدمة');
  assert.equal(autoReplyMatch('حجز موعد غداً', [{ keywords: ['حجز'], matchType: 'STARTS_WITH', reply: 'اختر الخدمة', priority: 1 }]).reply, 'اختر الخدمة');
  assert.equal(autoReplyMatch('أحتاج حجز موعد', [{ keywords: ['حجز.*موعد'], matchType: 'REGEX', reply: 'سأساعدك', priority: 1 }]).reply, 'سأساعدك');
  assert.equal(autoReplyMatch('أريد حجز موعد', [{ keywords: ['حجز', 'موعد'], matchType: 'ANY_KEYWORD', reply: 'تم', priority: 1 }]).reply, 'تم');
});

test('flow message is selected before AI when a trigger matches', () => {
  const result = flowReply('أريد حجز', [{ isActive: true, triggerKeywords: ['حجز'], definition: { nodes: [{ type: 'MESSAGE', config: { text: 'ما الخدمة؟' } }] } }]);
  assert.equal(result.reply, 'ما الخدمة؟');
});

test('dental prompt includes safety rules and tenant context', () => {
  const prompt = buildSystemPrompt({ name: 'Tenant A', activityType: 'DENTAL', businessInfo: { name: 'Clinic A' }, botSettings: {} }, { faqs: [], examples: [], catalog: [] });
  assert.match(prompt, /لا تشخّص/);
  assert.match(prompt, /Clinic A/);
  assert.doesNotMatch(prompt, /Tenant B/);
});