const { verifyToken } = require('../utils/jwt');

/**
 * وسيط حماية: يتأكد إن الطلب يحمل رمز دخول صالح
 * ويربط req.auth = { userId, tenantId, role } لباقي المسارات
 * هذا هو أساس عزل بيانات كل مستأجر عن غيره
 */
function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'غير مصرح، الرجاء تسجيل الدخول' });
  }

  try {
    const decoded = verifyToken(token);
    req.auth = decoded; // { userId, tenantId, role }
    next();
  } catch (err) {
    return res.status(401).json({ error: 'رمز الدخول غير صالح أو منتهي' });
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.auth || !roles.includes(req.auth.role)) return res.status(403).json({ error: 'لا تملك صلاحية تنفيذ هذا الإجراء' });
    next();
  };
}

module.exports = { requireAuth, requireRole };
