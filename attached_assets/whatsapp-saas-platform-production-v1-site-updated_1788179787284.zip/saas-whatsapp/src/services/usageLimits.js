const prisma = require('../config/db');

async function messageAllowance(tenantId) {
  const subscription = await prisma.subscription.findUnique({ where: { tenantId }, include: { plan: true } });
  const limits = subscription?.plan?.limits || {};
  const limit = Number(limits.messages || subscription?.plan?.messageLimit || 0);
  if (!limit) return { allowed: true, limit: null };
  const since = new Date(); since.setMonth(since.getMonth() - 1);
  const used = await prisma.message.count({ where: { tenantId, createdAt: { gte: since } } });
  return { allowed: used < limit, used, limit };
}

module.exports = { messageAllowance };