class FileStorage {
  async put() { throw new Error('FileStorage.put must be implemented'); }
  async delete() { throw new Error('FileStorage.delete must be implemented'); }
}

class LocalFileStorage extends FileStorage {
  async put() { throw new Error('Local file storage is disabled for production; configure an object storage provider'); }
  async delete() { return true; }
}

class S3CompatibleStorage extends FileStorage {
  async put() { throw new Error('S3-compatible storage is ready for configuration'); }
  async delete() { throw new Error('S3-compatible storage is ready for configuration'); }
}

function getFileStorage() {
  return process.env.FILE_STORAGE_PROVIDER === 's3' ? new S3CompatibleStorage() : new LocalFileStorage();
}

module.exports = { FileStorage, LocalFileStorage, S3CompatibleStorage, getFileStorage };