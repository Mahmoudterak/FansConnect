// Backwards-compatible facade for integrations that used the original service.
const { processIncomingMessage, buildSystemPrompt } = require('./conversationEngine');

async function handleIncomingMessage({ tenant, conversation, userMessage, contactNumber, providerMessageId }) {
  const result = await processIncomingMessage({ tenant, conversation, userMessage, contactNumber, providerMessageId });
  return result.reply;
}

module.exports = { handleIncomingMessage, buildSystemPrompt };