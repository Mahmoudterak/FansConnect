const { getProvider } = require('./messagingProviders');

async function sendWhatsAppMessage(tenant, to, text) {
  return getProvider(tenant).sendMessage(to, text);
}

module.exports = { sendWhatsAppMessage };
