const prisma = require('../config/db');

class AvailabilityProvider {
  async check() { throw new Error('AvailabilityProvider.check must be implemented'); }
}

class LocalAvailabilityProvider extends AvailabilityProvider {
  async check({ tenantId, date, time }) {
    const parsed = new Date(`${date}T${time || '00:00'}:00`);
    if (Number.isNaN(parsed.getTime())) return { available: false, reason: 'invalid_date' };
    const day = parsed.getDay();
    const hours = await prisma.businessHour.findFirst({ where: { tenantId, dayOfWeek: day } });
    if (hours && (!hours.isOpen || (hours.openTime && time < hours.openTime) || (hours.closeTime && time >= hours.closeTime))) return { available: false, reason: 'outside_business_hours' };
    const conflict = await prisma.appointment.findFirst({ where: { tenantId, date, time, status: { notIn: ['CANCELLED', 'NO_SHOW'] } } });
    return conflict ? { available: false, reason: 'slot_taken' } : { available: true, source: 'local' };
  }
}

class GoogleCalendarAvailabilityProvider extends AvailabilityProvider {
  async check() { return { available: false, reason: 'not_configured', provider: 'google_calendar' }; }
}

class CustomApiAvailabilityProvider extends AvailabilityProvider {
  async check() { return { available: false, reason: 'not_configured', provider: 'custom_api' }; }
}

function getAvailabilityProvider(name = process.env.AVAILABILITY_PROVIDER || 'local') {
  if (name === 'google_calendar') return new GoogleCalendarAvailabilityProvider();
  if (name === 'custom_api') return new CustomApiAvailabilityProvider();
  return new LocalAvailabilityProvider();
}

module.exports = { AvailabilityProvider, LocalAvailabilityProvider, GoogleCalendarAvailabilityProvider, CustomApiAvailabilityProvider, getAvailabilityProvider };