const OpenAI = require('openai');
const prisma = require('../config/db');
const { audit } = require('../utils/audit');
const { getActivityProfile } = require('./activityProfiles');
const { getAvailabilityProvider } = require('./availabilityProviders');

const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';
const MAX_HISTORY = 14;
const normalize = (value) => String(value || '').trim().toLocaleLowerCase('ar');
const parse = (value) => { try { return JSON.parse(value || '{}'); } catch { return {}; } };

function settingsFor(tenant) {
  return {
    personality: 'Friendly Professional',
    language: 'Arabic',
    dialect: 'Gulf',
    responseLength: 'Short',
    welcomeMessage: '',
    outOfScopeMessage: 'هذه المعلومة غير متوفرة لدي حالياً، وسأحوّلك إلى أحد أعضاء الفريق.',
    handoffMessage: 'أكيد، سأحوّلك إلى أحد أعضاء الفريق لمساعدتك.',
    aiFailureMessage: 'أعتذر، لم أتمكن من معالجة طلبك الآن. سيتابع معك أحد أعضاء الفريق.',
    forbiddenTopics: [],
    customInstructions: '',
    ...(tenant.botSettings || {}),
  };
}

function buildSystemPrompt(tenant, { faqs = [], examples = [], catalog = [] } = {}) {
  const info = tenant.businessInfo || {};
  const settings = settingsFor(tenant);
  const profile = getActivityProfile(tenant.activityType);
  const safety = [...profile.safety, ...(Array.isArray(settings.forbiddenTopics) ? settings.forbiddenTopics.map((x) => `تجنب موضوع: ${x}`) : [])];
  return [
    `أنت مساعد خدمة العملاء الرسمي لنشاط "${info.name || tenant.name}".`,
    `نوع النشاط: ${profile.label}. الشخصية: ${settings.personality}. اللغة: ${settings.language}، اللهجة: ${settings.dialect}، طول الرد: ${settings.responseLength}.`,
    'استخدم فقط بيانات هذا النشاط. لا تخترع أسعاراً أو خدمات أو مواعيد أو سياسات.',
    'إذا لم تعرف الإجابة، استخدم رسالة عدم توفر المعلومة واطلب تدخّل الموظف. لا تدّعي تنفيذ إجراء لم يتم تنفيذه.',
    'إذا طلب العميل إنساناً، نفّذ handoff فوراً.',
    safety.length ? `قواعد السلامة:\n- ${safety.join('\n- ')}` : '',
    settings.customInstructions ? `تعليمات النشاط:\n${settings.customInstructions}` : '',
    `بيانات النشاط: ${JSON.stringify(info)}`,
    `الخدمات والمنتجات المعتمدة: ${JSON.stringify(catalog)}`,
    `الأسئلة المتكررة:\n${faqs.map((x) => `س: ${x.question}\nج: ${x.answer}`).join('\n') || 'لا يوجد'}`,
    `أمثلة توجيهية (لا تتجاوز قواعد السلامة):\n${examples.map((x) => `عميل: ${x.customerMessage}\nرد مثالي: ${x.ownerReply}\nملاحظة: ${x.note || ''}`).join('\n') || 'لا يوجد'}`,
  ].filter(Boolean).join('\n\n');
}

function faqMatch(message, faqs) {
  const text = normalize(message);
  return [...faqs].sort((a, b) => (a.priority || 100) - (b.priority || 100)).find((faq) => {
    const question = normalize(faq.question);
    if (question && question === text) return true;
    return (faq.keywords || []).some((keyword) => normalize(keyword) && text.includes(normalize(keyword)));
  });
}

function autoReplyMatch(message, rules) {
  const text = normalize(message);
  return [...rules].sort((a, b) => (a.priority || 100) - (b.priority || 100)).find((rule) => {
    if (rule.isActive === false) return false;
    const keywords = (rule.keywords || []).map(normalize).filter(Boolean);
    if (!keywords.length) return false;
    switch (rule.matchType) {
      case 'EXACT': return keywords.some((keyword) => text === keyword);
      case 'STARTS_WITH': return keywords.some((keyword) => text.startsWith(keyword));
      case 'REGEX': return keywords.some((keyword) => { try { return new RegExp(keyword, 'iu').test(message); } catch { return false; } });
      case 'CONTAINS': return keywords.some((keyword) => text.includes(keyword));
      case 'ANY_KEYWORD':
      default: return keywords.every((keyword) => text.includes(keyword));
    }
  });
}

function flowReply(message, flows) {
  const text = normalize(message);
  const flow = flows.find((candidate) => candidate.isActive && (candidate.triggerKeywords || []).some((keyword) => text.includes(normalize(keyword))));
  if (!flow) return null;
  const definition = flow.definition || {};
  const nodes = Array.isArray(definition.nodes) ? definition.nodes : [];
  const node = nodes.find((candidate) => ['MESSAGE', 'SEND_MESSAGE'].includes(candidate.type) && (candidate.config?.text || candidate.text));
  return node ? { reply: node.config?.text || node.text, flow } : null;
}

async function saveMessage({ tenantId, conversationId, direction, content, provider, providerMessageId = null, aiGenerated = false, route = null }) {
  if (!content && !providerMessageId) return null;
  try {
    return await prisma.message.create({ data: { tenantId, conversationId, direction, content, provider, providerMessageId, aiGenerated, route } });
  } catch (error) {
    if (error.code === 'P2002') return null;
    throw error;
  }
}

async function ensureContact({ tenantId, phone, name }) {
  if (!phone) return null;
  return prisma.contact.upsert({
    where: { tenantId_phone: { tenantId, phone } },
    update: { ...(name ? { name } : {}), lastInteraction: new Date() },
    create: { tenantId, phone, name: name || null, source: 'WHATSAPP', lastInteraction: new Date() },
  });
}

async function createHandoff({ tenant, conversation, reason }) {
  const settings = settingsFor(tenant);
  const pauseMinutes = Math.max(1, Number(settings.handoffPauseMinutes || 60));
  const pausedUntil = new Date(Date.now() + pauseMinutes * 60000);
  await prisma.$transaction([
    prisma.conversation.update({ where: { id: conversation.id }, data: { handedOff: true, status: 'PENDING', aiPausedUntil: pausedUntil } }),
    prisma.handoff.create({ data: { tenantId: tenant.id, conversationId: conversation.id, reason, pausedUntil } }),
  ]);
  await audit({ tenantId: tenant.id, action: 'conversation.handoff', entity: 'Conversation', entityId: conversation.id, metadata: { reason } });
  return settings.handoffMessage;
}

async function runAI({ tenant, conversation, userMessage, faqs, examples, catalog, contactNumber }) {
  if (!process.env.OPENAI_API_KEY) return { reply: settingsFor(tenant).aiFailureMessage, route: 'AI_UNAVAILABLE' };
  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const history = Array.isArray(conversation.history) ? conversation.history.slice(-MAX_HISTORY) : [];
  const tools = [{
    type: 'function',
    function: {
      name: 'capture_lead',
      description: 'سجل العميل المحتمل عندما يبدي اهتماماً واضحاً',
      parameters: { type: 'object', properties: { name: { type: 'string' }, phone: { type: 'string' }, interest: { type: 'string' } }, required: ['interest'] },
    },
  }, {
    type: 'function',
    function: {
      name: 'book_appointment',
      description: 'أنشئ طلب موعد بحالة PENDING فقط بعد التحقق من التوفر المحلي. لا تؤكد الموعد للعميل قبل التحقق.',
      parameters: { type: 'object', properties: { name: { type: 'string' }, phone: { type: 'string' }, service: { type: 'string' }, date: { type: 'string' }, time: { type: 'string' }, notes: { type: 'string' } }, required: ['service', 'date', 'time'] },
    },
  }, {
    type: 'function',
    function: {
      name: 'request_human_handoff',
      description: 'حوّل المحادثة لموظف عندما يطلب العميل ذلك أو لا تتوفر المعلومة',
      parameters: { type: 'object', properties: { reason: { type: 'string' } }, required: ['reason'] },
    },
  }];
  const messages = [{ role: 'system', content: buildSystemPrompt(tenant, { faqs, examples, catalog }) }, ...history, { role: 'user', content: userMessage }];
  let response = await openai.chat.completions.create({ model: MODEL, messages, tools, tool_choice: 'auto' });
  const choice = response.choices?.[0];
  if (!choice) return { reply: settingsFor(tenant).aiFailureMessage, route: 'AI_EMPTY' };
  let handedOff = false;
  if (choice.finish_reason === 'tool_calls') {
    messages.push(choice.message);
    for (const call of choice.message.tool_calls || []) {
      const args = parse(call.function.arguments);
      if (call.function.name === 'capture_lead') {
        await prisma.lead.create({ data: { tenantId: tenant.id, name: args.name || null, phone: args.phone || contactNumber, interest: args.interest || null, source: 'AI' } });
      }
      if (call.function.name === 'book_appointment') {
        const availability = await getAvailabilityProvider().check({ tenantId: tenant.id, date: args.date, time: args.time });
        if (availability.available) {
          await prisma.appointment.create({ data: { tenantId: tenant.id, name: args.name || null, phone: args.phone || contactNumber, service: args.service, date: args.date, time: args.time, status: 'PENDING', timezone: tenant.businessInfo?.timezone || null, source: 'AI', notes: args.notes || null } });
          messages.push({ role: 'tool', tool_call_id: call.id, content: 'تم إنشاء طلب الموعد بحالة معلّق، ولم يتم تأكيده بعد.' });
          continue;
        }
        messages.push({ role: 'tool', tool_call_id: call.id, content: 'الموعد غير متاح أو لم يتم إعداد مزود توفر حقيقي، لا تؤكد الحجز.' });
        continue;
      }
      if (call.function.name === 'request_human_handoff') handedOff = true;
      messages.push({ role: 'tool', tool_call_id: call.id, content: 'تم تنفيذ الإجراء.' });
    }
    response = await openai.chat.completions.create({ model: MODEL, messages, tools, tool_choice: 'auto' });
  }
  const usage = response.usage || {};
  const estimatedCost = ((usage.prompt_tokens || 0) * 0.00000015) + ((usage.completion_tokens || 0) * 0.0000006);
  await prisma.aIUsage.create({ data: { tenantId: tenant.id, conversationId: conversation.id, model: MODEL, inputTokens: usage.prompt_tokens || 0, outputTokens: usage.completion_tokens || 0, estimatedCost, route: 'AI' } });
  return { reply: response.choices?.[0]?.message?.content || settingsFor(tenant).aiFailureMessage, route: 'AI', handedOff };
}

async function processIncomingMessage({ tenant, conversation, userMessage, contactNumber, provider = 'WHATSAPP', providerMessageId = null, contactName = null }) {
  const contact = await ensureContact({ tenantId: tenant.id, phone: contactNumber, name: contactName });
  if (contact && conversation.contactId !== contact.id) {
    conversation = await prisma.conversation.update({ where: { id: conversation.id }, data: { contactId: contact.id } });
  }
  await saveMessage({ tenantId: tenant.id, conversationId: conversation.id, direction: 'INBOUND', content: userMessage, provider, providerMessageId, route: 'INBOUND' });
  if (conversation.handedOff && conversation.aiPausedUntil && conversation.aiPausedUntil > new Date()) return { reply: null, route: 'HANDOFF' };

  const [faqs, rules, flows, examples, catalog] = await Promise.all([
    prisma.fAQ.findMany({ where: { tenantId: tenant.id, isActive: true }, take: 200 }),
    prisma.autoReplyRule.findMany({ where: { tenantId: tenant.id, isActive: true }, take: 200 }),
    prisma.conversationFlow.findMany({ where: { tenantId: tenant.id, isActive: true }, take: 50 }),
    prisma.trainingExample.findMany({ where: { tenantId: tenant.id }, orderBy: { createdAt: 'desc' }, take: 20 }),
    prisma.catalogItem.findMany({ where: { tenantId: tenant.id, isActive: true }, take: 200 }),
  ]);
  const settings = settingsFor(tenant);
  const faq = faqMatch(userMessage, faqs);
  const rule = faq ? null : autoReplyMatch(userMessage, rules);
  const flow = faq || rule ? null : flowReply(userMessage, flows);
  let result = faq ? { reply: faq.answer, route: 'FAQ' } : rule ? { reply: rule.reply, route: 'AUTO_REPLY' } : flow ? { ...flow, route: 'FLOW' } : null;
  if (!result) result = await runAI({ tenant, conversation, userMessage, faqs, examples, catalog, contactNumber });
  if (result.handedOff) result.reply = await createHandoff({ tenant, conversation, reason: 'AI requested human support' });
  const history = [...(Array.isArray(conversation.history) ? conversation.history : []), { role: 'user', content: userMessage }, ...(result.reply ? [{ role: 'assistant', content: result.reply }] : [])];
  await prisma.conversation.update({ where: { id: conversation.id }, data: { history: history.slice(-MAX_HISTORY), handedOff: result.handedOff || conversation.handedOff } });
  if (result.reply) await saveMessage({ tenantId: tenant.id, conversationId: conversation.id, direction: 'OUTBOUND', content: result.reply, provider, aiGenerated: result.route === 'AI', route: result.route });
  return result;
}

module.exports = { processIncomingMessage, buildSystemPrompt, faqMatch, autoReplyMatch, flowReply, settingsFor };