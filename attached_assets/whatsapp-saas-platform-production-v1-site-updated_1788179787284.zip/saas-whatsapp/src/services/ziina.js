const crypto = require('crypto');

const ZIINA_BASE_URL = 'https://api-v2.ziina.com/api';
const ZIINA_API_KEY = process.env.ZIINA_API_KEY;
const ZIINA_TEST_MODE = process.env.ZIINA_TEST_MODE === 'true';

/**
 * إنشاء رابط دفع (Payment Intent) عبر Ziina
 * ⚠️ مهم: Ziina لا يدعم تحصيل تلقائي متكرر من بطاقة محفوظة (بعكس Moyasar/Stripe)،
 * فكل عملية دفع (أول اشتراك أو كل تجديد شهري) تحتاج رابط دفع صريح يفتحه العميل ويدفع فيه بنفسه
 */
async function createPaymentIntent({ amountAED, message, successUrl, cancelUrl, failureUrl }) {
  const amountFils = Math.round(amountAED * 100); // Ziina يتعامل بالفلس (أصغر وحدة عملة)

  const res = await fetch(`${ZIINA_BASE_URL}/payment_intent`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${ZIINA_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      amount: amountFils,
      currency_code: 'AED',
      message,
      success_url: successUrl,
      cancel_url: cancelUrl,
      failure_url: failureUrl,
      test: ZIINA_TEST_MODE,
    }),
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(`فشل إنشاء رابط دفع Ziina: ${JSON.stringify(data)}`);
  }

  return data; // { id, redirect_url, status, ... }
}

/**
 * جلب حالة دفعة معيّنة مباشرة من Ziina - نعتمد عليها كمصدر الحقيقة الأدق
 * بدل الاعتماد فقط على شكل حمولة الويب هوك (اللي قد يختلف تفصيلها بمرور الوقت)
 */
async function getPaymentIntent(id) {
  const res = await fetch(`${ZIINA_BASE_URL}/payment_intent/${id}`, {
    headers: { Authorization: `Bearer ${ZIINA_API_KEY}` },
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(`فشل جلب حالة الدفعة من Ziina: ${JSON.stringify(data)}`);
  }
  return data;
}

/**
 * التحقق من توقيع الويب هوك (HMAC-SHA256 على النص الخام للطلب)
 * @param {Buffer} rawBody - جسم الطلب الخام (غير محوّل لـ JSON بعد)
 * @param {string} signatureHeader - قيمة الهيدر X-Hmac-Signature
 */
function verifyWebhookSignature(rawBody, signatureHeader) {
  if (!signatureHeader) return false;
  const secret = process.env.ZIINA_WEBHOOK_SECRET;
  const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');

  try {
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signatureHeader));
  } catch {
    return false; // لو اختلف الطول مثلاً
  }
}

module.exports = { createPaymentIntent, getPaymentIntent, verifyWebhookSignature };
