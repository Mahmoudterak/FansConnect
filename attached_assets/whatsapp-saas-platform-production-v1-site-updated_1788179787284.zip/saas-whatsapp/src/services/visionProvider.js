class VisionProvider {
  async describe() { throw new Error('VisionProvider.describe must be implemented'); }
}

class OpenAIVisionProvider extends VisionProvider {
  async describe() {
    if (!process.env.OPENAI_API_KEY) throw new Error('Vision provider is not configured');
    throw new Error('Vision provider is ready for configuration; image analysis must be explicitly enabled per tenant');
  }
}

module.exports = { VisionProvider, OpenAIVisionProvider };