const profiles = {
  GENERAL: {
    label: 'General business',
    tone: 'friendly professional',
    modules: ['inbox', 'contacts', 'leads', 'faq', 'flows'],
    safety: [],
    suggestedFaqs: ['ما هي ساعات العمل؟', 'كيف أتواصل معكم؟'],
  },
  CLINIC: {
    label: 'Medical clinic',
    tone: 'calm and professional',
    modules: ['inbox', 'contacts', 'appointments', 'faq', 'flows'],
    safety: ['لا تشخّص', 'لا تصف دواء أو جرعة', 'وجّه الحالات الطارئة لتقييم طبي عاجل'],
    suggestedFaqs: ['ما الخدمات المتاحة؟', 'كيف أحجز موعداً؟'],
  },
  DENTAL: {
    label: 'Dental clinic',
    tone: 'reassuring and professional',
    modules: ['inbox', 'contacts', 'appointments', 'faq', 'flows'],
    safety: ['لا تفسر الصور أو الأشعة كتَشخيص', 'لا تشخّص ولا تصف دواء أو جرعة'],
    suggestedFaqs: ['كم سعر تنظيف الأسنان؟', 'هل يوجد موعد اليوم؟'],
  },
  SALON: { label: 'Beauty salon', tone: 'warm and concise', modules: ['inbox', 'contacts', 'appointments', 'catalog', 'faq'], safety: [], suggestedFaqs: ['ما الخدمات والأسعار؟', 'ما أوقات العمل؟'] },
  RESTAURANT: { label: 'Restaurant', tone: 'warm and helpful', modules: ['inbox', 'contacts', 'catalog', 'orders', 'faq'], safety: [], suggestedFaqs: ['ما هي القائمة؟', 'هل يوجد توصيل؟'] },
  RETAIL: { label: 'E-commerce store', tone: 'helpful and concise', modules: ['inbox', 'contacts', 'catalog', 'orders', 'faq'], safety: [], suggestedFaqs: ['هل المنتج متوفر؟', 'ما سياسة الاستبدال؟'] },
  REAL_ESTATE: { label: 'Real estate', tone: 'professional and informative', modules: ['inbox', 'contacts', 'leads', 'catalog', 'faq'], safety: [], suggestedFaqs: ['ما العقارات المتاحة؟', 'ما الميزانية والموقع؟'] },
  HOTEL: { label: 'Hotel', tone: 'welcoming and polished', modules: ['inbox', 'contacts', 'appointments', 'catalog', 'faq'], safety: [], suggestedFaqs: ['هل توجد غرف متاحة؟', 'ما وقت تسجيل الدخول؟'] },
  EDUCATION: { label: 'Education / training', tone: 'encouraging and clear', modules: ['inbox', 'contacts', 'leads', 'catalog', 'faq'], safety: [], suggestedFaqs: ['ما الدورات المتاحة؟', 'كيف أسجل؟'] },
  AUTOMOTIVE: { label: 'Automotive', tone: 'practical and professional', modules: ['inbox', 'contacts', 'appointments', 'catalog', 'faq'], safety: [], suggestedFaqs: ['كيف أحجز صيانة؟', 'ما الخدمات المتاحة؟'] },
  HOME_SERVICES: { label: 'Home services', tone: 'clear and dependable', modules: ['inbox', 'contacts', 'appointments', 'catalog', 'faq'], safety: [], suggestedFaqs: ['هل تخدمون منطقتي؟', 'كيف أطلب زيارة؟'] },
  PROFESSIONAL_SERVICES: { label: 'Professional services', tone: 'professional and direct', modules: ['inbox', 'contacts', 'leads', 'appointments', 'faq'], safety: [], suggestedFaqs: ['ما الخدمات المتاحة؟', 'كيف أبدأ؟'] },
  OTHER: { label: 'Other', tone: 'friendly professional', modules: ['inbox', 'contacts', 'faq', 'flows'], safety: [], suggestedFaqs: [] },
};

function getActivityProfile(activityType) {
  return profiles[activityType] || profiles.GENERAL;
}

module.exports = { profiles, getActivityProfile };