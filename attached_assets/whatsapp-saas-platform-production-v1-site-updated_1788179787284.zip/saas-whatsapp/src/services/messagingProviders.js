const { decrypt } = require('../utils/crypto');

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function withRetry(fn, attempts = 3) {
  let lastError;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try { return await fn(); } catch (error) {
      lastError = error;
      if (attempt < attempts - 1 && (!error.status || error.status === 429 || error.status >= 500)) await sleep(250 * (attempt + 1));
    }
  }
  throw lastError;
}

class WhatsAppCloudProvider {
  constructor(tenant) {
    this.tenant = tenant;
    this.base = `https://graph.facebook.com/${process.env.META_GRAPH_API_VERSION || 'v19.0'}`;
  }

  async sendMessage(to, text) {
    const token = decrypt(this.tenant.whatsappAccessToken);
    if (!this.tenant.whatsappPhoneNumberId || !token) throw new Error('WhatsApp is not configured');
    return withRetry(async () => {
      const response = await fetch(`${this.base}/${this.tenant.whatsappPhoneNumberId}/messages`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ messaging_product: 'whatsapp', to, type: 'text', text: { body: text } }),
      });
      if (!response.ok) { const error = new Error(`WhatsApp provider returned ${response.status}`); error.status = response.status; throw error; }
      return response.json();
    });
  }
}

class SendsBotProvider {
  constructor({ apiKey, deviceId }) { this.apiKey = apiKey; this.deviceId = deviceId; }
  async sendMessage(to, text) {
    if (!this.apiKey || !this.deviceId) throw new Error('Sends Bot is not configured');
    return withRetry(async () => {
      const response = await fetch('https://www.sendsbot.com/api/messages/send', {
        method: 'POST',
        headers: { Authorization: `Bearer ${this.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ device_id: this.deviceId, phone: to, content: { text } }),
      });
      if (!response.ok) { const error = new Error(`Sends Bot returned ${response.status}`); error.status = response.status; throw error; }
      return response.json();
    });
  }
}

class InstagramProvider {
  constructor({ accessToken, accountId }) { this.accessToken = accessToken; this.accountId = accountId; }
  async sendMessage() {
    throw new Error('Instagram provider is ready for configuration but has not been connected');
  }
  normalizeIncomingMessage(payload) {
    return { externalId: payload?.message?.id || payload?.id, from: payload?.sender?.id, text: payload?.message?.text || payload?.text };
  }
  verifyWebhook() { return false; }
}

function getProvider(tenant) {
  const channel = tenant.channelProvider || 'WHATSAPP_CLOUD';
  if (channel === 'SENDS_BOT') return new SendsBotProvider({ apiKey: process.env.SENDSBOT_API_KEY, deviceId: tenant.sendsBotDeviceId });
  return new WhatsAppCloudProvider(tenant);
}

module.exports = { WhatsAppCloudProvider, SendsBotProvider, InstagramProvider, getProvider, withRetry };