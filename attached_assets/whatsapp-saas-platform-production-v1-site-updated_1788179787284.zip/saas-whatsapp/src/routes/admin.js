const express = require('express');
const prisma = require('../config/db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth, requireRole('SUPER_ADMIN'));

router.get('/overview', async (req, res) => {
  const [tenants, users, subscriptions, invoices, aiUsage] = await Promise.all([
    prisma.tenant.count(), prisma.user.count(), prisma.subscription.count(), prisma.invoice.count(),
    prisma.aIUsage.aggregate({ _sum: { estimatedCost: true, inputTokens: true, outputTokens: true } }),
  ]);
  res.json({ tenants, users, subscriptions, invoices, aiUsage });
});

router.get('/tenants', async (req, res) => {
  res.json(await prisma.tenant.findMany({ select: { id: true, name: true, activityType: true, status: true, createdAt: true, subscription: { include: { plan: true } } }, orderBy: { createdAt: 'desc' }, take: 200 }));
});

router.patch('/tenants/:id', async (req, res) => {
  const data = {};
  if (['TRIAL', 'ACTIVE', 'SUSPENDED', 'CANCELED'].includes(req.body.status)) data.status = req.body.status;
  if (req.body.activityType) data.activityType = req.body.activityType;
  const updated = await prisma.tenant.update({ where: { id: req.params.id }, data });
  res.json({ id: updated.id, status: updated.status, activityType: updated.activityType });
});

router.get('/audit-logs', async (req, res) => {
  res.json(await prisma.auditLog.findMany({ orderBy: { createdAt: 'desc' }, take: 500 }));
});

module.exports = router;