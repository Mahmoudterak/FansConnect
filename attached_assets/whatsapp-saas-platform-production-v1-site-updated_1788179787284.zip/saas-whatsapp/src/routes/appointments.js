const express = require('express');
const prisma = require('../config/db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

/**
 * عرض آخر 100 موعد حجزهم البوت لهذا المستأجر تحديداً
 */
router.get('/', requireAuth, async (req, res) => {
  const appointments = await prisma.appointment.findMany({
    where: { tenantId: req.auth.tenantId },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });
  res.json(appointments);
});

module.exports = router;
