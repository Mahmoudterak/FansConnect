const express = require('express');
const crypto = require('crypto');
const prisma = require('../config/db');
const { processIncomingMessage } = require('../services/conversationEngine');
const { sendWhatsAppMessage } = require('../services/whatsappCloud');
const { messageAllowance } = require('../services/usageLimits');

const router = express.Router();

router.post('/', async (req, res) => {
  res.sendStatus(200);
  try {
    const event = req.body || {};
    if (event.type && event.type !== 'message.received') return;
    const message = event.data?.message || event.message || event.data || event;
    const deviceId = message.device_id || event.device_id;
    const phone = message.from || message.phone || message.contact?.phone;
    const text = message.text || message.content?.text || message.message;
    if (!deviceId || !phone || !text) return;
    const tenant = await prisma.tenant.findFirst({ where: { sendsBotDeviceId: deviceId } });
    if (!tenant) return;
    if (!(await messageAllowance(tenant.id)).allowed) return;
    const id = event.id || message.id || crypto.createHash('sha256').update(JSON.stringify(event)).digest('hex');
    try { await prisma.webhookEvent.create({ data: { tenantId: tenant.id, provider: 'SENDS_BOT', externalId: id } }); } catch (error) { if (error.code === 'P2002') return; throw error; }
    const conversation = await prisma.conversation.upsert({ where: { tenantId_waChatId: { tenantId: tenant.id, waChatId: phone } }, update: {}, create: { tenantId: tenant.id, waChatId: phone, channel: 'WHATSAPP', history: [] } });
    const result = await processIncomingMessage({ tenant, conversation, userMessage: String(text), contactNumber: phone, provider: 'SENDS_BOT', providerMessageId: id, contactName: message.contact?.name });
    if (result.reply) await sendWhatsAppMessage(tenant, phone, result.reply);
  } catch (error) {
    console.error('Sends Bot webhook processing failed:', error.message);
  }
});

module.exports = router;