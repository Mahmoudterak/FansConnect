const express = require('express');
const prisma = require('../config/db');
const { verifyWebhookSignature, getPaymentIntent } = require('../services/ziina');

const router = express.Router();

router.post('/', express.raw({ type: '*/*' }), async (req, res) => {
  const signature = req.headers['x-hmac-signature'];
  const rawBody = req.body; // Buffer خام - ضروري لحساب التوقيع بشكل صحيح

  if (!verifyWebhookSignature(rawBody, signature)) {
    console.warn('⚠️ توقيع ويب هوك Ziina غير صالح، تم تجاهل الطلب');
    return res.sendStatus(401);
  }

  res.sendStatus(200); // نرد فوراً، والمعالجة الفعلية تكمل بالخلفية

  try {
    const event = JSON.parse(rawBody.toString('utf8'));
    // ملاحظة: أثناء أول اختبار حقيقي، راقب هذا الـ log للتأكد من شكل الحمولة بالضبط
    console.log('📩 حدث ويب هوك من Ziina:', JSON.stringify(event));

    const paymentIntentId = event?.data?.id || event?.data?.object?.id || event?.id;
    if (!paymentIntentId) {
      console.warn('⚠️ ما قدرنا نحدد معرف الدفعة من حمولة الويب هوك');
      return;
    }

    await syncInvoiceWithZiina(paymentIntentId);
  } catch (err) {
    console.error('❌ خطأ أثناء معالجة ويب هوك Ziina:', err);
  }
});

/**
 * نجلب الحالة الفعلية للدفعة مباشرة من Ziina (مصدر الحقيقة) ونحدّث فاتورتنا واشتراكنا تبعاً لها
 * هذا أضمن من الاعتماد فقط على حقول حمولة الويب هوك اللي قد تختلف تفاصيلها
 */
async function syncInvoiceWithZiina(paymentIntentId) {
  const invoice = await prisma.invoice.findFirst({ where: { gatewayInvoiceId: paymentIntentId } });
  if (!invoice) {
    console.warn('⚠️ فاتورة غير معروفة لدينا لمعرف الدفعة:', paymentIntentId);
    return;
  }

  const paymentIntent = await getPaymentIntent(paymentIntentId);
  const status = paymentIntent.status;

  const successStatuses = ['completed', 'succeeded', 'paid'];
  const failureStatuses = ['failed', 'canceled', 'cancelled'];

  if (successStatuses.includes(status) && invoice.status !== 'PAID') {
    await prisma.invoice.update({
      where: { id: invoice.id },
      data: { status: 'PAID', paidAt: new Date() },
    });

    const nextPeriodEnd = new Date();
    nextPeriodEnd.setMonth(nextPeriodEnd.getMonth() + 1);

    const subscription = await prisma.subscription.update({
      where: { id: invoice.subscriptionId },
      data: { status: 'ACTIVE', currentPeriodEnd: nextPeriodEnd },
    });

    await prisma.tenant.update({ where: { id: subscription.tenantId }, data: { status: 'ACTIVE' } });
    console.log(`✅ تم تأكيد دفع الفاتورة ${invoice.id}`);
  } else if (failureStatuses.includes(status)) {
    await prisma.invoice.update({ where: { id: invoice.id }, data: { status: 'FAILED' } });
    console.log(`❌ فشلت/أُلغيت الدفعة الخاصة بالفاتورة ${invoice.id} (الحالة: ${status})`);
  } else {
    console.log(`ℹ️ حالة دفعة غير نهائية بعد (${status}) للفاتورة ${invoice.id}`);
  }
}

module.exports = router;
