const express = require('express');
const prisma = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const { audit } = require('../utils/audit');

const router = express.Router();
router.use(requireAuth);
const own = (req) => ({ tenantId: req.auth.tenantId });
const array = (value) => Array.isArray(value) ? value.filter(Boolean).slice(0, 100) : [];

router.get('/me', async (req, res) => {
  const tenant = await prisma.tenant.findFirst({ where: { id: req.auth.tenantId }, select: { id: true, name: true, activityType: true, botSettings: true, knowledgeBase: true } });
  if (!tenant) return res.status(404).json({ error: 'المستأجر غير موجود' });
  res.json(tenant);
});

router.put('/me', async (req, res) => {
  const data = {};
  if (req.body.activityType) data.activityType = req.body.activityType;
  if (req.body.botSettings && typeof req.body.botSettings === 'object') data.botSettings = req.body.botSettings;
  if (req.body.knowledgeBase && Array.isArray(req.body.knowledgeBase)) data.knowledgeBase = req.body.knowledgeBase.slice(0, 200);
  const tenant = await prisma.tenant.update({ where: { id: req.auth.tenantId }, data });
  await audit({ tenantId: tenant.id, userId: req.auth.userId, action: 'bot.settings_updated', entity: 'Tenant' });
  res.json({ activityType: tenant.activityType, botSettings: tenant.botSettings, knowledgeBase: tenant.knowledgeBase });
});

router.get('/me/faqs', async (req, res) => res.json(await prisma.fAQ.findMany({ where: own(req), orderBy: [{ priority: 'asc' }, { createdAt: 'desc' }] })));
router.post('/me/faqs', async (req, res) => {
  const { question, answer, keywords = [], category = null, priority = 100 } = req.body;
  if (!question || !answer) return res.status(400).json({ error: 'السؤال والإجابة مطلوبان' });
  res.status(201).json(await prisma.fAQ.create({ data: { ...own(req), question, answer, keywords: array(keywords), category, priority: Number(priority) || 100 } }));
});
router.patch('/me/faqs/:id', async (req, res) => {
  const updated = await prisma.fAQ.updateMany({ where: { id: req.params.id, ...own(req) }, data: { ...(req.body.question !== undefined ? { question: req.body.question } : {}), ...(req.body.answer !== undefined ? { answer: req.body.answer } : {}), ...(req.body.keywords ? { keywords: array(req.body.keywords) } : {}), ...(req.body.category !== undefined ? { category: req.body.category } : {}), ...(req.body.priority !== undefined ? { priority: Number(req.body.priority) || 100 } : {}), ...(req.body.isActive !== undefined ? { isActive: Boolean(req.body.isActive) } : {}) } });
  if (!updated.count) return res.status(404).json({ error: 'FAQ غير موجودة' });
  res.json(await prisma.fAQ.findFirst({ where: { id: req.params.id, ...own(req) } }));
});
router.delete('/me/faqs/:id', async (req, res) => { await prisma.fAQ.deleteMany({ where: { id: req.params.id, ...own(req) } }); res.sendStatus(204); });

router.get('/me/auto-replies', async (req, res) => res.json(await prisma.autoReplyRule.findMany({ where: own(req), orderBy: [{ priority: 'asc' }, { createdAt: 'desc' }] })));
router.post('/me/auto-replies', async (req, res) => {
  const { name, keywords = [], reply, priority = 100, matchType = 'ANY_KEYWORD' } = req.body;
  if (!name || !reply || !array(keywords).length) return res.status(400).json({ error: 'اسم القاعدة والكلمات والرد مطلوبة' });
  res.status(201).json(await prisma.autoReplyRule.create({ data: { ...own(req), name, keywords: array(keywords), reply, priority: Number(priority) || 100, matchType } }));
});
router.patch('/me/auto-replies/:id', async (req, res) => {
  const updated = await prisma.autoReplyRule.updateMany({ where: { id: req.params.id, ...own(req) }, data: { ...(req.body.name !== undefined ? { name: req.body.name } : {}), ...(req.body.reply !== undefined ? { reply: req.body.reply } : {}), ...(req.body.keywords ? { keywords: array(req.body.keywords) } : {}), ...(req.body.matchType ? { matchType: req.body.matchType } : {}), ...(req.body.priority !== undefined ? { priority: Number(req.body.priority) || 100 } : {}), ...(req.body.isActive !== undefined ? { isActive: Boolean(req.body.isActive) } : {}) } });
  if (!updated.count) return res.status(404).json({ error: 'قاعدة الرد غير موجودة' });
  res.json(await prisma.autoReplyRule.findFirst({ where: { id: req.params.id, ...own(req) } }));
});
router.delete('/me/auto-replies/:id', async (req, res) => { await prisma.autoReplyRule.deleteMany({ where: { id: req.params.id, ...own(req) } }); res.sendStatus(204); });

router.get('/me/flows', async (req, res) => res.json(await prisma.conversationFlow.findMany({ where: own(req), include: { nodes: true }, orderBy: { updatedAt: 'desc' } })));
router.post('/me/flows', async (req, res) => {
  const { name, triggerKeywords = [], definition = {}, isActive = false } = req.body;
  if (!name) return res.status(400).json({ error: 'اسم التدفق مطلوب' });
  const flow = await prisma.conversationFlow.create({ data: { ...own(req), name, triggerKeywords: array(triggerKeywords), definition, isActive } });
  res.status(201).json(flow);
});
router.put('/me/flows/:id', async (req, res) => {
  const flow = await prisma.conversationFlow.findFirst({ where: { id: req.params.id, ...own(req) } });
  if (!flow) return res.status(404).json({ error: 'التدفق غير موجود' });
  const definition = req.body.definition || {};
  const updated = await prisma.conversationFlow.update({ where: { id: flow.id }, data: { ...(req.body.name ? { name: req.body.name } : {}), ...(req.body.triggerKeywords ? { triggerKeywords: array(req.body.triggerKeywords) } : {}), definition, ...(req.body.isActive !== undefined ? { isActive: Boolean(req.body.isActive) } : {}) } });
  res.json(updated);
});
router.delete('/me/flows/:id', async (req, res) => { await prisma.conversationFlow.deleteMany({ where: { id: req.params.id, ...own(req) } }); res.sendStatus(204); });

router.get('/me/examples', async (req, res) => res.json(await prisma.trainingExample.findMany({ where: own(req), orderBy: { createdAt: 'desc' } })));
router.post('/me/examples', async (req, res) => {
  const { customerMessage, ownerReply, note, imageUrl } = req.body;
  if (!customerMessage || !ownerReply) return res.status(400).json({ error: 'رسالة العميل والرد مطلوبان' });
  res.status(201).json(await prisma.trainingExample.create({ data: { ...own(req), customerMessage, ownerReply, note, imageUrl } }));
});
router.delete('/me/examples/:id', async (req, res) => { await prisma.trainingExample.deleteMany({ where: { id: req.params.id, ...own(req) } }); res.sendStatus(204); });

module.exports = router;