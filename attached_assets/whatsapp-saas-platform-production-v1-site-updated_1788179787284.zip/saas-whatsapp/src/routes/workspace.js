const express = require('express');
const prisma = require('../config/db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { sendWhatsAppMessage } = require('../services/whatsappCloud');
const { audit } = require('../utils/audit');
const { messageAllowance } = require('../services/usageLimits');

const router = express.Router();
router.use(requireAuth);
const tenantWhere = (req) => ({ tenantId: req.auth.tenantId });

router.get('/conversations', async (req, res) => {
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 50));
  const conversations = await prisma.conversation.findMany({
    where: { ...tenantWhere(req), ...(req.query.status ? { status: req.query.status } : {}) },
    include: { contact: true, messages: { orderBy: { createdAt: 'desc' }, take: 1 } },
    orderBy: { updatedAt: 'desc' }, take: limit,
  });
  res.json(conversations);
});

router.get('/conversations/:id/messages', async (req, res) => {
  const conversation = await prisma.conversation.findFirst({ where: { id: req.params.id, ...tenantWhere(req) }, include: { contact: true } });
  if (!conversation) return res.status(404).json({ error: 'المحادثة غير موجودة' });
  const messages = await prisma.message.findMany({ where: { conversationId: conversation.id, ...tenantWhere(req) }, orderBy: { createdAt: 'asc' }, take: 500 });
  res.json({ conversation, messages });
});

router.post('/conversations/:id/reply', async (req, res) => {
  const { text } = req.body;
  if (!text || String(text).length > 4000) return res.status(400).json({ error: 'نص الرد مطلوب وبحد أقصى 4000 حرف' });
  const conversation = await prisma.conversation.findFirst({ where: { id: req.params.id, ...tenantWhere(req) } });
  if (!conversation) return res.status(404).json({ error: 'المحادثة غير موجودة' });
  const tenant = await prisma.tenant.findUnique({ where: { id: req.auth.tenantId } });
  const allowance = await messageAllowance(tenant.id);
  if (!allowance.allowed) return res.status(402).json({ error: 'تم تجاوز حد الرسائل في الباقة الحالية' });
  await sendWhatsAppMessage(tenant, conversation.waChatId, text);
  const message = await prisma.message.create({ data: { tenantId: tenant.id, conversationId: conversation.id, direction: 'OUTBOUND', content: text, provider: tenant.channelProvider, route: 'HUMAN' } });
  await prisma.conversation.update({ where: { id: conversation.id }, data: { handedOff: false, status: 'OPEN' } });
  await audit({ tenantId: tenant.id, userId: req.auth.userId, action: 'conversation.reply', entity: 'Conversation', entityId: conversation.id });
  res.status(201).json(message);
});

router.patch('/conversations/:id', async (req, res) => {
  const allowed = {};
  if (['OPEN', 'PENDING', 'CLOSED'].includes(req.body.status)) allowed.status = req.body.status;
  if (typeof req.body.assignedUserId === 'string' || req.body.assignedUserId === null) allowed.assignedUserId = req.body.assignedUserId;
  if (req.body.action === 'pause') { allowed.handedOff = true; allowed.status = 'PENDING'; allowed.aiPausedUntil = new Date(Date.now() + Math.max(1, Number(req.body.minutes) || 60) * 60000); }
  if (req.body.action === 'resume') { allowed.handedOff = false; allowed.aiPausedUntil = null; allowed.status = 'OPEN'; }
  if (req.body.action === 'close') allowed.status = 'CLOSED';
  const updated = await prisma.conversation.updateMany({ where: { id: req.params.id, ...tenantWhere(req) }, data: allowed });
  if (!updated.count) return res.status(404).json({ error: 'المحادثة غير موجودة' });
  res.json(await prisma.conversation.findFirst({ where: { id: req.params.id, ...tenantWhere(req) }, include: { contact: true } }));
});

router.get('/contacts', async (req, res) => {
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 50));
  const search = String(req.query.search || '').trim();
  res.json(await prisma.contact.findMany({
    where: { ...tenantWhere(req), ...(search ? { OR: [{ name: { contains: search, mode: 'insensitive' } }, { phone: { contains: search } }, { email: { contains: search, mode: 'insensitive' } }] } : {}) },
    orderBy: { updatedAt: 'desc' }, take: limit,
  }));
});

router.get('/catalog', async (req, res) => {
  res.json(await prisma.catalogItem.findMany({ where: tenantWhere(req), orderBy: { updatedAt: 'desc' }, take: 200 }));
});

router.post('/catalog', async (req, res) => {
  const { name, description, price, type = 'service', category, durationMinutes, currency = 'AED' } = req.body;
  if (!name) return res.status(400).json({ error: 'اسم الخدمة أو المنتج مطلوب' });
  res.status(201).json(await prisma.catalogItem.create({ data: { ...tenantWhere(req), name, description, type, category, durationMinutes: durationMinutes ? Number(durationMinutes) : null, price: price === '' || price == null ? null : Number(price), currency } }));
});

router.delete('/catalog/:id', async (req, res) => {
  await prisma.catalogItem.deleteMany({ where: { id: req.params.id, ...tenantWhere(req) } });
  res.sendStatus(204);
});

router.post('/contacts', async (req, res) => {
  const { name, phone, email, tags = [], customFields = {} } = req.body;
  if (!phone) return res.status(400).json({ error: 'رقم الهاتف مطلوب' });
  const contact = await prisma.contact.upsert({ where: { tenantId_phone: { tenantId: req.auth.tenantId, phone } }, update: { name, email, tags, customFields }, create: { tenantId: req.auth.tenantId, name, phone, email, tags, customFields, source: 'DASHBOARD' } });
  res.status(201).json(contact);
});

router.patch('/contacts/:id', async (req, res) => {
  const updated = await prisma.contact.updateMany({ where: { id: req.params.id, ...tenantWhere(req) }, data: { ...(req.body.name !== undefined ? { name: req.body.name } : {}), ...(req.body.tags ? { tags: req.body.tags } : {}), ...(req.body.status ? { status: req.body.status } : {}), ...(req.body.notes !== undefined ? { notes: req.body.notes } : {}), ...(req.body.customFields ? { customFields: req.body.customFields } : {}) } });
  if (!updated.count) return res.status(404).json({ error: 'جهة الاتصال غير موجودة' });
  res.json(await prisma.contact.findFirst({ where: { id: req.params.id, ...tenantWhere(req) } }));
});

router.get('/analytics/summary', async (req, res) => {
  const where = tenantWhere(req);
  const [messages, conversations, leads, appointments, aiUsage, handoffs] = await Promise.all([
    prisma.message.count({ where }), prisma.conversation.count({ where }), prisma.lead.count({ where }), prisma.appointment.count({ where }),
    prisma.aIUsage.aggregate({ where, _sum: { inputTokens: true, outputTokens: true, estimatedCost: true }, _count: { id: true } }),
    prisma.handoff.count({ where }),
  ]);
  res.json({ messages, conversations, leads, appointments, handoffs, aiRequests: aiUsage._count.id, inputTokens: aiUsage._sum.inputTokens || 0, outputTokens: aiUsage._sum.outputTokens || 0, estimatedCost: aiUsage._sum.estimatedCost || 0 });
});

router.get('/admin/audit-logs', requireRole('OWNER'), async (req, res) => {
  res.json(await prisma.auditLog.findMany({ where: { tenantId: req.auth.tenantId }, orderBy: { createdAt: 'desc' }, take: 200 }));
});

module.exports = router;