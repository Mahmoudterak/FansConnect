const express = require('express');
const crypto = require('crypto');
const prisma = require('../config/db');
const { sendWhatsAppMessage } = require('../services/whatsappCloud');
const { processIncomingMessage } = require('../services/conversationEngine');
const { messageAllowance } = require('../services/usageLimits');

const router = express.Router();

router.get('/', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode === 'subscribe' && token && token === process.env.WHATSAPP_WEBHOOK_VERIFY_TOKEN) return res.status(200).send(challenge);
  return res.sendStatus(403);
});

function externalId(value, message) {
  return message?.id || value?.messages?.[0]?.id || crypto.createHash('sha256').update(JSON.stringify(value || {})).digest('hex');
}

router.post('/', async (req, res) => {
  // Meta expects a fast acknowledgement. Processing continues after the response.
  res.sendStatus(200);
  try {
    const value = req.body?.entry?.[0]?.changes?.[0]?.value;
    const message = value?.messages?.[0];
    const phoneNumberId = value?.metadata?.phone_number_id;
    if (!phoneNumberId || !message || !['text', 'image', 'document', 'audio'].includes(message.type)) return;

    const tenant = await prisma.tenant.findFirst({ where: { whatsappPhoneNumberId: phoneNumberId } });
    if (!tenant) return console.warn('Incoming WhatsApp message has no tenant:', phoneNumberId);
    const allowance = await messageAllowance(tenant.id);
    if (!allowance.allowed) return console.warn(`Tenant ${tenant.id} reached its message limit`);
    const eventId = externalId(value, message);
    try {
      await prisma.webhookEvent.create({ data: { tenantId: tenant.id, provider: 'WHATSAPP', externalId: eventId, payloadHash: crypto.createHash('sha256').update(JSON.stringify(req.body)).digest('hex') } });
    } catch (error) {
      if (error.code === 'P2002') return console.info(`Duplicate WhatsApp event ignored: ${eventId}`);
      throw error;
    }

    const waChatId = message.from;
    const userMessage = message.type === 'text' ? message.text?.body : `[${message.type}]`;
    const contactName = value?.contacts?.[0]?.profile?.name || null;
    const conversation = await prisma.conversation.upsert({
      where: { tenantId_waChatId: { tenantId: tenant.id, waChatId } },
      update: {},
      create: { tenantId: tenant.id, waChatId, channel: 'WHATSAPP', history: [], handedOff: false },
    });
    const result = await processIncomingMessage({ tenant, conversation, userMessage, contactNumber: waChatId, provider: 'WHATSAPP', providerMessageId: message.id, contactName });
    if (result.reply) await sendWhatsAppMessage(tenant, waChatId, result.reply);
    console.info(`[${tenant.id}] inbound ${eventId} route=${result.route}`);
  } catch (error) {
    console.error('WhatsApp webhook processing failed:', error.message);
  }
});

module.exports = router;