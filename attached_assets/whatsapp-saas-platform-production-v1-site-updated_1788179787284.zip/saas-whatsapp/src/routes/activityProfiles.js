const express = require('express');
const { profiles } = require('../services/activityProfiles');
const router = express.Router();
router.get('/', (req, res) => res.json(Object.entries(profiles).map(([id, profile]) => ({ id, ...profile }))));
module.exports = router;