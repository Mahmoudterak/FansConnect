const express = require('express');
const bcrypt = require('bcryptjs');
const prisma = require('../config/db');
const { signToken } = require('../utils/jwt');
const { getActivityProfile } = require('../services/activityProfiles');
const crypto = require('crypto');
const tokenHash = (value) => crypto.createHash('sha256').update(value).digest('hex');

const router = express.Router();

/**
 * تسجيل نشاط تجاري جديد (مستأجر) + أول مستخدم مالك له
 * هذا هو أول شيء يسويه أي عميل جديد يشترك بالخدمة
 */
router.post('/register', async (req, res) => {
  try {
    const { businessName, email, password, activityType = 'GENERAL', businessInfo = {} } = req.body;

    if (!businessName || !email || !password || password.length < 8) {
      return res.status(400).json({ error: 'الاسم التجاري والبريد وكلمة المرور مطلوبة' });
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    const existingUser = await prisma.user.findFirst({ where: { email: normalizedEmail } });
    if (existingUser) {
      return res.status(409).json({ error: 'هذا البريد مسجّل مسبقاً' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const verificationToken = crypto.randomBytes(32).toString('hex');

    // إنشاء المستأجر والمستخدم المالك معاً في عملية واحدة
    const tenant = await prisma.tenant.create({
      data: {
        name: businessName.trim(),
        activityType,
        businessInfo: { ...businessInfo, name: businessName.trim() },
        botSettings: {
          personality: getActivityProfile(activityType).tone,
          language: 'Arabic',
          dialect: 'Gulf',
          responseLength: 'Short',
          handoffPauseMinutes: 60,
        },
        status: 'TRIAL',
        users: {
          create: {
            email: normalizedEmail,
            passwordHash,
            verificationTokenHash: tokenHash(verificationToken),
            role: 'OWNER',
          },
        },
      },
      include: { users: true },
    });

    const owner = tenant.users[0];
    const token = signToken({ userId: owner.id, tenantId: tenant.id, role: owner.role });

    res.status(201).json({
      token,
      tenant: { id: tenant.id, name: tenant.name, status: tenant.status },
      ...(process.env.NODE_ENV !== 'production' ? { verificationToken } : {}),
    });
  } catch (err) {
    console.error('❌ خطأ بالتسجيل:', err);
    res.status(500).json({ error: 'حدث خطأ أثناء إنشاء الحساب' });
  }
});

router.post('/verify-email', async (req, res) => {
  const token = String(req.body.token || '');
  if (!token) return res.status(400).json({ error: 'رمز التحقق مطلوب' });
  const user = await prisma.user.findFirst({ where: { verificationTokenHash: tokenHash(token) } });
  if (!user) return res.status(400).json({ error: 'رمز التحقق غير صالح أو منتهي' });
  await prisma.user.update({ where: { id: user.id }, data: { emailVerifiedAt: new Date(), verificationTokenHash: null } });
  res.json({ verified: true });
});

router.post('/forgot-password', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const user = await prisma.user.findFirst({ where: { email } });
  const response = { message: 'إذا كان البريد مسجلاً، ستصلك تعليمات إعادة التعيين.' };
  if (!user) return res.json(response);
  const resetToken = crypto.randomBytes(32).toString('hex');
  await prisma.user.update({ where: { id: user.id }, data: { passwordResetTokenHash: tokenHash(resetToken), passwordResetExpiresAt: new Date(Date.now() + 30 * 60 * 1000) } });
  if (process.env.NODE_ENV !== 'production') response.resetToken = resetToken;
  res.json(response);
});

router.post('/reset-password', async (req, res) => {
  const token = String(req.body.token || '');
  const password = String(req.body.password || '');
  if (password.length < 8) return res.status(400).json({ error: 'كلمة المرور يجب أن تكون 8 أحرف على الأقل' });
  const user = await prisma.user.findFirst({ where: { passwordResetTokenHash: tokenHash(token), passwordResetExpiresAt: { gt: new Date() } } });
  if (!user) return res.status(400).json({ error: 'الرابط غير صالح أو منتهي' });
  await prisma.user.update({ where: { id: user.id }, data: { passwordHash: await bcrypt.hash(password, 10), passwordResetTokenHash: null, passwordResetExpiresAt: null } });
  res.json({ reset: true });
});

/**
 * تسجيل الدخول
 */
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await prisma.user.findFirst({ where: { email: String(email || '').trim().toLowerCase() } });
    if (!user) {
      return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
    }

    const isValid = await bcrypt.compare(password, user.passwordHash);
    if (!isValid) {
      return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
    }

    const token = signToken({ userId: user.id, tenantId: user.tenantId, role: user.role });
    res.json({ token });
  } catch (err) {
    console.error('❌ خطأ بتسجيل الدخول:', err);
    res.status(500).json({ error: 'حدث خطأ أثناء تسجيل الدخول' });
  }
});

module.exports = router;
