const express = require('express');
const prisma = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const { sendWhatsAppMessage } = require('../services/whatsappCloud');
const { encrypt } = require('../utils/crypto');
const { audit } = require('../utils/audit');

const router = express.Router();

/**
 * جلب بيانات حساب المستأجر الحالي (النشاط اللي سجّل دخوله المستخدم)
 */
router.get('/me', requireAuth, async (req, res) => {
  const tenant = await prisma.tenant.findUnique({
    where: { id: req.auth.tenantId },
    include: { subscription: { include: { plan: true } } },
  });

  if (!tenant) return res.status(404).json({ error: 'المستأجر غير موجود' });

  // ما نرجع بيانات حساسة زي whatsappAccessToken كامل بالاستجابة
  res.json({
    id: tenant.id,
    name: tenant.name,
    status: tenant.status,
    businessInfo: tenant.businessInfo,
    whatsappConnected: Boolean(tenant.whatsappPhoneNumberId),
    channelProvider: tenant.channelProvider,
    subscription: tenant.subscription,
  });
});

/**
 * تحديث معلومات النشاط التجاري (يُستخدم كسياق للذكاء الاصطناعي بالبوت)
 */
router.put('/me/business-info', requireAuth, async (req, res) => {
  const { businessInfo } = req.body;

  if (!businessInfo || typeof businessInfo !== 'object') return res.status(400).json({ error: 'بيانات النشاط يجب أن تكون كائناً' });
  const tenant = await prisma.tenant.update({
    where: { id: req.auth.tenantId },
    data: { businessInfo },
  });

  res.json({ businessInfo: tenant.businessInfo });
});

/**
 * ربط رقم واتساب المستأجر (يُدخلها من لوحة تحكمه بعد ما يجيبها من Meta Business):
 * - Phone Number ID: من WhatsApp > API Setup بلوحة Meta for Developers
 * - Access Token: توكن دائم (System User Token) من نفس الصفحة أو من إعدادات Business
 */
router.put('/me/whatsapp-config', requireAuth, async (req, res) => {
  const { whatsappPhoneNumberId, whatsappAccessToken, channelProvider = 'WHATSAPP_CLOUD', sendsBotDeviceId } = req.body;

  if (channelProvider === 'WHATSAPP_CLOUD' && (!whatsappPhoneNumberId || !whatsappAccessToken)) {
    return res.status(400).json({ error: 'رقم Phone Number ID والتوكن مطلوبين' });
  }

  // نتأكد إن هذا الرقم مو مربوط بمستأجر آخر مسبقاً
  const existing = await prisma.tenant.findFirst({
    where: { whatsappPhoneNumberId, NOT: { id: req.auth.tenantId } },
  });
  if (existing) {
    return res.status(409).json({ error: 'رقم الواتساب هذا مربوط بحساب آخر مسبقاً' });
  }

  await prisma.tenant.update({
    where: { id: req.auth.tenantId },
    data: {
      whatsappPhoneNumberId: whatsappPhoneNumberId || null,
      whatsappAccessToken: whatsappAccessToken ? encrypt(whatsappAccessToken) : undefined,
      channelProvider,
      sendsBotDeviceId: sendsBotDeviceId || null,
    },
  });

  await audit({ tenantId: req.auth.tenantId, userId: req.auth.userId, action: 'tenant.channel_connected', entity: 'Tenant' });
  res.json({ whatsappConnected: true });
});

/**
 * إرسال رسالة تجريبية للتأكد إن الربط شغّال صح (تُستخدم من لوحة التحكم بعد إدخال البيانات)
 */
router.post('/me/whatsapp-test', requireAuth, async (req, res) => {
  const { to, message } = req.body;

  const tenant = await prisma.tenant.findUnique({ where: { id: req.auth.tenantId } });
  if (!tenant?.whatsappPhoneNumberId) {
    return res.status(400).json({ error: 'لم تربط رقم واتساب بعد' });
  }

  try {
    await sendWhatsAppMessage(tenant, to, message || 'رسالة تجريبية من نظامك ✅');
    res.json({ sent: true });
  } catch (err) {
    console.error('❌ فشل إرسال رسالة تجريبية:', err.message);
    res.status(502).json({ error: 'فشل إرسال الرسالة، تأكد من صحة التوكن والرقم' });
  }
});

module.exports = router;
