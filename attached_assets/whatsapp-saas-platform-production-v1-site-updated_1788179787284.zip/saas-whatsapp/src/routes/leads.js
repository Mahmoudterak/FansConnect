const express = require('express');
const prisma = require('../config/db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

/**
 * عرض آخر 100 عميل محتمل جمعهم البوت لهذا المستأجر تحديداً
 */
router.get('/', requireAuth, async (req, res) => {
  const leads = await prisma.lead.findMany({
    where: { tenantId: req.auth.tenantId },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });
  res.json(leads);
});

module.exports = router;
