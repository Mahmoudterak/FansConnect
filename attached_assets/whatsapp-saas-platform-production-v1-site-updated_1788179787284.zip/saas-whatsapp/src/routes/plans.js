const express = require('express');
const prisma = require('../config/db');

const router = express.Router();

/**
 * عرض كل الباقات النشطة - تظهر بصفحة التسعير قبل التسجيل
 */
router.get('/', async (req, res) => {
  const plans = await prisma.plan.findMany({
    where: { isActive: true },
    orderBy: { priceMonthly: 'asc' },
  });
  res.json(plans);
});

module.exports = router;
