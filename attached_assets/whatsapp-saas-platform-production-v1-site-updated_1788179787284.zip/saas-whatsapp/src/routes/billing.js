const express = require('express');
const prisma = require('../config/db');
const { requireAuth } = require('../middleware/auth');
const { createPaymentIntent } = require('../services/ziina');

const router = express.Router();

const APP_BASE_URL = process.env.APP_BASE_URL || 'http://localhost:4000';

/**
 * عرض حالة اشتراك المستأجر الحالي مع كل فواتيره
 */
router.get('/subscription', requireAuth, async (req, res) => {
  const subscription = await prisma.subscription.findUnique({
    where: { tenantId: req.auth.tenantId },
    include: { plan: true, invoices: { orderBy: { issuedAt: 'desc' } } },
  });

  res.json(subscription || null);
});

/**
 * بدء اشتراك جديد في باقة معيّنة
 * ننشئ رابط دفع عبر Ziina ونرجعه للعميل ليفتحه ويكمل الدفع بنفسه (بطاقة/Apple Pay/Google Pay)
 */
router.post('/subscribe', requireAuth, async (req, res) => {
  const { planId } = req.body;

  if (!planId) {
    return res.status(400).json({ error: 'الباقة مطلوبة' });
  }

  const plan = await prisma.plan.findUnique({ where: { id: planId } });
  if (!plan) return res.status(404).json({ error: 'الباقة غير موجودة' });

  const subscription = await prisma.subscription.upsert({
    where: { tenantId: req.auth.tenantId },
    update: { planId: plan.id },
    create: { tenantId: req.auth.tenantId, planId: plan.id, status: 'TRIALING' },
  });

  try {
    const paymentIntent = await createPaymentIntent({
      amountAED: Number(plan.priceMonthly),
      message: `اشتراك باقة ${plan.name}`,
      successUrl: `${APP_BASE_URL}/api/billing/payment-result?status=success`,
      cancelUrl: `${APP_BASE_URL}/api/billing/payment-result?status=cancel`,
      failureUrl: `${APP_BASE_URL}/api/billing/payment-result?status=failed`,
    });

    const invoice = await prisma.invoice.create({
      data: {
        subscriptionId: subscription.id,
        amount: plan.priceMonthly,
        currency: 'AED',
        status: 'PENDING',
        gatewayInvoiceId: paymentIntent.id,
        paymentUrl: paymentIntent.redirect_url,
      },
    });

    res.status(201).json({ paymentUrl: paymentIntent.redirect_url, invoiceId: invoice.id });
  } catch (err) {
    console.error('❌ خطأ أثناء إنشاء رابط الدفع:', err.message);
    res.status(502).json({ error: 'تعذر إنشاء رابط الدفع، حاول مرة أخرى لاحقاً' });
  }
});

/**
 * جلب أي فاتورة معلّقة تحتاج دفع (تُستخدم بلوحة التحكم لعرض زر "أكمل الدفع")
 */
router.get('/pending-invoice', requireAuth, async (req, res) => {
  const subscription = await prisma.subscription.findUnique({ where: { tenantId: req.auth.tenantId } });
  if (!subscription) return res.json(null);

  const pending = await prisma.invoice.findFirst({
    where: { subscriptionId: subscription.id, status: 'PENDING' },
    orderBy: { issuedAt: 'desc' },
  });

  res.json(pending || null);
});

/**
 * صفحة بسيطة يهبط عليها العميل بعد إتمام/إلغاء الدفع على صفحة Ziina
 * (الحالة الفعلية والموثوقة تُحدَّث عبر الويب هوك، هذي فقط لتجربة مستخدم لطيفة)
 */
router.get('/payment-result', (req, res) => {
  const status = req.query.status;
  const messages = {
    success: 'تم استلام دفعتك بنجاح، جاري تفعيل اشتراكك خلال لحظات ✅',
    cancel: 'تم إلغاء عملية الدفع.',
    failed: 'فشلت عملية الدفع، حاول مرة أخرى ببطاقة أخرى.',
  };
  res.send(`<div style="font-family:sans-serif;text-align:center;padding:40px;direction:rtl">
    <h2>${messages[status] || 'تم استلام النتيجة'}</h2>
  </div>`);
});

module.exports = router;
