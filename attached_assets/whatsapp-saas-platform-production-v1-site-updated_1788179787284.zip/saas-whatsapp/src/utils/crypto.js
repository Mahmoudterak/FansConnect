const crypto = require('crypto');

const algorithm = 'aes-256-gcm';
function key() {
  return crypto.createHash('sha256').update(process.env.SECRETS_ENCRYPTION_KEY || process.env.JWT_SECRET || 'development-only-key').digest();
}

function encrypt(value) {
  if (!value) return value;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(algorithm, key(), iv);
  const encrypted = Buffer.concat([cipher.update(String(value), 'utf8'), cipher.final()]);
  return `enc:v1:${iv.toString('base64url')}:${cipher.getAuthTag().toString('base64url')}:${encrypted.toString('base64url')}`;
}

function decrypt(value) {
  if (!value || !String(value).startsWith('enc:v1:')) return value;
  const [, , iv, tag, data] = String(value).split(':');
  const decipher = crypto.createDecipheriv(algorithm, key(), Buffer.from(iv, 'base64url'));
  decipher.setAuthTag(Buffer.from(tag, 'base64url'));
  return Buffer.concat([decipher.update(Buffer.from(data, 'base64url')), decipher.final()]).toString('utf8');
}

module.exports = { encrypt, decrypt };