const prisma = require('../config/db');

async function audit({ tenantId = null, userId = null, action, entity = null, entityId = null, metadata = {} }) {
  try {
    await prisma.auditLog.create({ data: { tenantId, userId, action, entity, entityId, metadata } });
  } catch (error) {
    console.error('audit log failed:', error.message);
  }
}

module.exports = { audit };