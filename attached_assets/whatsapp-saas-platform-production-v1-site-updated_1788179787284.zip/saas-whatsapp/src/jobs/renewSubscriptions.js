const cron = require('node-cron');
const prisma = require('../config/db');
const { createPaymentIntent } = require('../services/ziina');

const APP_BASE_URL = process.env.APP_BASE_URL || 'http://localhost:4000';

/**
 * تشتغل هذه المهمة يومياً وتبحث عن كل الاشتراكات اللي وصل تاريخ تجديدها
 * (currentPeriodEnd <= الآن) وحالتها ACTIVE.
 *
 * ⚠️ بعكس Moyasar، Ziina ما يدعم تحصيل صامت من بطاقة محفوظة، فبدل "خصم تلقائي"
 * نسوّي: ننشئ فاتورة جديدة برابط دفع، ونحوّل حالة الاشتراك لـ PAST_DUE مؤقتاً
 * لحد ما يدفع العميل (يرجع تلقائياً لـ ACTIVE فور تأكيد الدفع عبر الويب هوك)
 */
async function renewDueSubscriptions() {
  const dueSubscriptions = await prisma.subscription.findMany({
    where: {
      status: 'ACTIVE',
      currentPeriodEnd: { lte: new Date() },
    },
    include: { plan: true, tenant: true },
  });

  console.log(`🔄 فحص التجديد: ${dueSubscriptions.length} اشتراك مستحق`);

  for (const sub of dueSubscriptions) {
    try {
      const paymentIntent = await createPaymentIntent({
        amountAED: Number(sub.plan.priceMonthly),
        message: `تجديد شهري - ${sub.tenant.name}`,
        successUrl: `${APP_BASE_URL}/api/billing/payment-result?status=success`,
        cancelUrl: `${APP_BASE_URL}/api/billing/payment-result?status=cancel`,
        failureUrl: `${APP_BASE_URL}/api/billing/payment-result?status=failed`,
      });

      await prisma.invoice.create({
        data: {
          subscriptionId: sub.id,
          amount: sub.plan.priceMonthly,
          currency: 'AED',
          status: 'PENDING',
          gatewayInvoiceId: paymentIntent.id,
          paymentUrl: paymentIntent.redirect_url,
        },
      });

      // نحوّله لحالة "متأخر الدفع" مؤقتاً لحين يدفع - يرجع ACTIVE تلقائياً بعد تأكيد الويب هوك
      await prisma.subscription.update({ where: { id: sub.id }, data: { status: 'PAST_DUE' } });

      console.log(`📨 تم إنشاء رابط تجديد لـ ${sub.tenant.name}: ${paymentIntent.redirect_url}`);

      // TODO: إرسال رابط الدفع فعلياً لصاحب النشاط (بريد إلكتروني، أو عرضه بلوحة تحكمه بالمرحلة 4)
      // حالياً الرابط محفوظ بجدول Invoice ويمكن جلبه عبر GET /api/billing/pending-invoice
    } catch (err) {
      console.error(`❌ فشل إنشاء رابط تجديد لـ ${sub.tenant.name}:`, err.message);
    }
  }
}

/**
 * جدولة المهمة لتعمل يومياً الساعة 3 فجراً (توقيت السيرفر)
 */
function scheduleRenewalJob() {
  cron.schedule('0 3 * * *', () => {
    renewDueSubscriptions().catch((err) => console.error('❌ خطأ عام بمهمة التجديد:', err));
  });
  console.log('🕒 تمت جدولة مهمة التجديد اليومية (3:00 صباحاً)');
}

module.exports = { scheduleRenewalJob, renewDueSubscriptions };
