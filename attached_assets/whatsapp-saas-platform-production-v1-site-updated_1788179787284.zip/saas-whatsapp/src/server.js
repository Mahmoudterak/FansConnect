require('dotenv').config();
const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const tenantRoutes = require('./routes/tenants');
const planRoutes = require('./routes/plans');
const billingRoutes = require('./routes/billing');
const ziinaWebhookRoutes = require('./routes/ziinaWebhook');
const whatsappRoutes = require('./routes/whatsapp');
const leadRoutes = require('./routes/leads');
const appointmentRoutes = require('./routes/appointments');
const botConfigRoutes = require('./routes/botConfig');
const workspaceRoutes = require('./routes/workspace');
const activityProfileRoutes = require('./routes/activityProfiles');
const sendsBotWebhookRoutes = require('./routes/sendsbotWebhook');
const adminRoutes = require('./routes/admin');
const { scheduleRenewalJob } = require('./jobs/renewSubscriptions');

const app = express();
app.use(cors({ origin: process.env.DASHBOARD_ORIGIN ? process.env.DASHBOARD_ORIGIN.split(',') : true }));
app.disable('x-powered-by');

const buckets = new Map();
app.use((req, res, next) => {
  const requestId = req.headers['x-request-id'] || require('crypto').randomUUID();
  req.requestId = requestId;
  res.setHeader('x-request-id', requestId);
  res.setHeader('x-content-type-options', 'nosniff');
  res.setHeader('x-frame-options', 'DENY');
  res.setHeader('referrer-policy', 'no-referrer');
  if (req.path.startsWith('/webhook/')) return next();
  const now = Date.now();
  const bucket = buckets.get(req.ip) || { start: now, count: 0 };
  if (now - bucket.start > 60_000) { bucket.start = now; bucket.count = 0; }
  bucket.count += 1;
  buckets.set(req.ip, bucket);
  if (bucket.count > Number(process.env.RATE_LIMIT_PER_MINUTE || 180)) return res.status(429).json({ error: 'طلبات كثيرة، حاول بعد دقيقة' });
  next();
});

// ⚠️ مهم جداً: مسار ويب هوك Ziina لازم يُسجَّل قبل express.json() العام
// لأن التحقق من توقيع HMAC يحتاج النص الخام للطلب (Buffer) وليس JSON محوّل مسبقاً
app.use('/webhook/ziina', ziinaWebhookRoutes);

app.use(express.json({ limit: '1mb' }));

app.use('/api/auth', authRoutes);
app.use('/api/tenants', tenantRoutes);
app.use('/api/plans', planRoutes);
app.use('/api/billing', billingRoutes);
app.use('/api/leads', leadRoutes);
app.use('/api/appointments', appointmentRoutes);
app.use('/api/bot-config', botConfigRoutes);
app.use('/api/workspace', workspaceRoutes);
app.use('/api/activity-profiles', activityProfileRoutes);
app.use('/api/admin', adminRoutes);
app.use('/webhook/whatsapp', whatsappRoutes);
app.use('/webhook/sendsbot', sendsBotWebhookRoutes);

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'saas-whatsapp' }));
app.get('/ready', async (req, res) => {
  try {
    await require('./config/db').$queryRaw`SELECT 1`;
    res.json({ status: 'ready', database: 'ok' });
  } catch (error) {
    res.status(503).json({ status: 'not_ready', database: 'unavailable' });
  }
});

app.use((err, req, res, next) => {
  console.error(`[${req.requestId || 'unknown'}]`, err.message);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'حدث خطأ داخلي', requestId: req.requestId });
});

const PORT = process.env.PORT || 4000;
const server = app.listen(PORT, () => {
  console.log(`✅ منصة SaaS تعمل على المنفذ ${PORT}`);
  scheduleRenewalJob();
});

async function shutdown(signal) {
  console.log(`Received ${signal}; shutting down gracefully`);
  server.close(async () => {
    await require('./config/db').$disconnect();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
