# نشر SahaAI على Ubuntu VPS

هذا الدليل يشغّل الموقع العام والـDashboard والـAPI وقاعدة PostgreSQL على خادم VPS حقيقي.
لا تستخدم `localhost` داخل Docker بين الخدمات؛ يستخدم الـAPI اسم الخدمة `postgres:5432`.

## 1. تثبيت Ubuntu وDocker

استخدم Ubuntu 22.04 أو 24.04 مع نطاق يشير إلى عنوان الخادم:

```bash
sudo apt update
sudo apt install -y ca-certificates curl git ufw
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker "$USER"
newgrp docker
docker --version
docker compose version
```

افتح SSH وHTTP وHTTPS فقط:

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

## 2. تنزيل المشروع وتجهيز PostgreSQL

```bash
git clone <repository-url> sahai
cd sahai
```

`docker-compose.yml` ينشئ PostgreSQL 16 مع volume دائم باسم `postgres_data`.
لا تستخدم `docker compose down -v` لأنه يحذف بيانات قاعدة البيانات.

```bash
docker compose up -d postgres
docker compose ps
```

## 3. المتغيرات السرية

انسخ القالب إلى مدير أسرار الخادم أو ملف `.env` محلي غير متعقب في Git:

```bash
cp saas-whatsapp/.env.production.example saas-whatsapp/.env
```

اضبط على الأقل:

```env
NODE_ENV=production
DATABASE_URL=postgresql://app:CHANGE_ME@postgres:5432/whatsapp_saas?schema=public
JWT_SECRET=<random-long-value>
SECRETS_ENCRYPTION_KEY=<32-byte-key>
DASHBOARD_ORIGIN=https://app.example.com
APP_BASE_URL=https://api.example.com
OPENAI_API_KEY=<provider-secret>
ZIINA_API_KEY=<provider-secret>
ZIINA_WEBHOOK_SECRET=<provider-secret>
WHATSAPP_WEBHOOK_VERIFY_TOKEN=<random-webhook-token>
SENDSBOT_API_KEY=<optional-provider-secret>
```

في Compose، القيم الموجودة تحت `api.environment` يجب نقلها إلى Secret Manager أو ملف
Compose production منفصل وعدم إبقاء كلمات المرور الافتراضية.

## 4. Prisma migrations وseed

بعد تشغيل PostgreSQL:

```bash
cd saas-whatsapp
npm ci
npx prisma generate
npx prisma migrate deploy
node prisma/seed.js
cd ..
```

## 5. تشغيل Backend وDashboard

```bash
docker compose build
docker compose up -d
docker compose ps
docker compose logs --tail=100 api
docker compose logs --tail=100 dashboard
```

العناوين الداخلية:

- API: `http://127.0.0.1:4000`
- Dashboard/site: `http://127.0.0.1:8080`
- Readiness: `http://127.0.0.1:4000/ready`

المسار العام `/` يعرض الموقع التسويقي. مسارات التطبيق تحت `/app/*`، والمصادقة مشتركة:

`Landing → Register → Activity → Workspace → Plan → Ziina checkout → Onboarding → WhatsApp → AI → Dashboard`

## 6. Nginx وDomain

ثبّت Nginx على المضيف:

```bash
sudo apt install -y nginx
sudo nano /etc/nginx/sites-available/sahai
```

مثال reverse proxy:

```nginx
server {
  server_name app.example.com;
  location / {
    proxy_pass http://127.0.0.1:8080;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
server {
  server_name api.example.com;
  location / {
    proxy_pass http://127.0.0.1:4000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/sahai /etc/nginx/sites-enabled/sahai
sudo nginx -t
sudo systemctl reload nginx
```

اضبط `VITE_API_BASE_URL=https://api.example.com` قبل بناء صورة Dashboard إذا كان الـAPI
على نطاق منفصل. إذا استخدمت reverse proxy موحداً، يمكن استخدام مسار API نسبي بعد إعداد proxy المناسب.

## 7. HTTPS/TLS

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d app.example.com -d api.example.com
sudo systemctl enable --now certbot.timer
```

## 8. Webhooks والقنوات

بعد توفر HTTPS:

- WhatsApp Cloud: `https://api.example.com/webhook/whatsapp`
- Sends Bot: `https://api.example.com/webhook/sendsbot`
- Ziina: `https://api.example.com/webhook/ziina`

في Meta Developer Dashboard استخدم `WHATSAPP_WEBHOOK_VERIFY_TOKEN` نفسه، واشترك في
`messages`. لكل Tenant يُحفظ `phone_number_id` والتوكن مشفراً داخل قاعدة البيانات.

Instagram موجود كطبقة Provider وChannel architecture؛ يحتاج ربط Meta/Instagram business
حقيقي قبل تفعيل استقبال وإرسال رسائل Instagram في بيئة الإنتاج.

## 9. OpenAI وAI

ضع مفتاح OpenAI في Secret Manager وليس في Git. اختبر أولاً على Tenant تجريبي. محرك المحادثة
يطبق FAQ ثم Auto Reply ثم Flow ثم AI، ويسجل استهلاك AI لكل Tenant.

## 10. Backups

نفّذ نسخة يومية مشفرة خارج الخادم واحتفظ بعدة نقاط زمنية:

```bash
mkdir -p /var/backups/sahai
docker compose exec -T postgres pg_dump -U app whatsapp_saas | gzip > \
  /var/backups/sahai/whatsapp_saas-$(date +%F).sql.gz
```

انسخ الملفات إلى تخزين خارجي، واختبر الاستعادة دورياً على قاعدة منفصلة. لا تعتمد على Docker
volume وحده كنسخة احتياطية.

## 11. Logs وRestart policy

```bash
docker compose logs -f api
docker compose logs -f postgres
docker compose restart api dashboard
```

في بيئة VPS أضف `restart: unless-stopped` إلى خدمات Compose بعد مراجعة سياسة التشغيل،
وفعّل log rotation على Docker حتى لا يمتلئ القرص.

## 12. Health checks والتحديث

راقب:

```bash
curl -fsS https://api.example.com/health
curl -fsS https://api.example.com/ready
```

`/health` يثبت أن العملية تعمل، و`/ready` يتحقق من اتصال Prisma/PostgreSQL. عند كل إصدار:

```bash
git pull
docker compose build
docker compose run --rm api npx prisma migrate deploy
docker compose up -d
docker compose ps
```

## 13. تحقق ما بعد النشر

اختبر التسجيل، اختيار النشاط، الدفع الاختباري، onboarding، ربط WhatsApp، FAQ، Flow Builder،
Handoff، الرد البشري، حدود الاستخدام، وصلاحيات Tenant. لا تعتبر تكاملات Meta أو Ziina أو
OpenAI مختبرة حتى تستخدم حسابات اختبار حقيقية وآمنة.
