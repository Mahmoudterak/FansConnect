import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Link, Route, Switch, Router as WouterRouter, useLocation, useParams } from 'wouter';
import {
  AlertCircle, ArrowRight, ArrowUpRight, BadgeCheck, BarChart3, Bell, BookOpen, Bot, BotMessageSquare,
  BriefcaseBusiness, CalendarCheck2, CalendarDays, Check, CheckCircle2, ChevronDown, ChevronLeft,
  ChevronRight, CircleHelp, Clock3, Copy, CreditCard, Download, Eye, FileText, Filter, Globe2,
  Headphones, Inbox, Instagram, Languages, LayoutDashboard, Link2, ListFilter, LockKeyhole, LogIn,
  MapPin, Menu, MessageCircle, MessageSquareText, MoreHorizontal, PanelLeftClose, Pause, Pencil,
  Phone, Play, Plus, RotateCcw, Save, Search, Send, Settings2, SlidersHorizontal, Sparkles, Star,
  Store, Tag, Trash2, TrendingUp, UserRound, Users, WalletCards, Wifi, Workflow, X, Zap
} from 'lucide-react';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

type Channel = 'WhatsApp' | 'Instagram';
type Conversation = { id: number; contactName: string; avatar: string; channel: Channel; lastMessage: string; timestamp: string; unread: number; status: string; tags: string[]; messages: { from: 'customer' | 'team'; text: string; time: string }[] };
type LiveChannel = {
  channel: 'whatsapp' | 'instagram';
  name: string;
  provider: string;
  status: 'setup_required' | 'connecting' | 'connected' | 'degraded' | 'failed' | 'paused' | 'disconnected';
  verified: boolean;
  displayName: string | null;
  lastVerifiedAt: string | null;
  failureReason: string | null;
  health: { state: string; verified: boolean; message: string; action: string | null };
};
type LiveConversation = {
  id: string;
  channel: 'whatsapp' | 'instagram';
  contactName: string;
  contactAddress: string;
  status: 'open' | 'pending' | 'resolved';
  handoff: 'assistant' | 'team';
  updatedAt: string;
  messages: { id: string; from: 'customer' | 'team' | 'assistant'; text: string; timestamp: string; deliveryStatus?: string }[];
};
type FaqItem = {
  id: string;
  question: string;
  answer: string;
  category: string;
  priority: number;
  enabled: boolean;
};
type AutoReplyRule = {
  id: string;
  name: string;
  keywords: string[];
  matchType: 'contains' | 'exact' | 'starts_with';
  response: string;
  priority: number;
  enabled: boolean;
};
type AssistantConfig = {
  status: string;
  personality: string;
  language: 'ar' | 'en';
  dialect: string;
  responseStyle: string;
  welcomeMessage: string;
  outOfScopeResponse: string;
  humanHandoffMessage: string;
  aiFailureMessage: string;
  businessInstructions: string;
};
type WorkspaceSetup = {
  profile: WorkspaceContextData['profile'];
  assistant: AssistantConfig | null;
  channels: { type: string; provider: string | null; status: string }[];
  faq: FaqItem[];
  autoReplies: AutoReplyRule[];
};

type WorkspaceContextData = {
  workspace: { id: string; name: string };
  user: { id: string; email: string; emailVerified: boolean; role: string };
  profile: { businessName: string; activityType: string; country: string } | null;
  assistant: { status: string } | null;
  counts: { contacts: number; conversations: number; messages: number; leads: number; appointments: number; orders: number; faq: number; autoReplies: number; trainingExamples: number; unreadConversations: number };
};
type AuthState = {
  loading: boolean;
  authenticated: boolean;
  onboardingCompleted: boolean;
  workspace: WorkspaceContextData | null;
  refresh: () => Promise<void>;
  signOut: () => Promise<void>;
};
type Language = 'en' | 'ar';

const ar: Record<string, string> = {
  'Workspace': 'مساحة العمل',
  'Overview': 'نظرة عامة',
  'Inbox': 'صندوق الوارد',
  'Contacts': 'جهات الاتصال',
  'Leads': 'العملاء المحتملون',
  'Appointments': 'المواعيد',
  'Automation': 'الأتمتة',
  'AI assistant': 'المساعد الذكي',
  'FAQ & auto-replies': 'الأسئلة الشائعة والردود التلقائية',
  'Training': 'التدريب',
  'Flows': 'التدفقات',
  'Analytics': 'التحليلات',
  'Campaigns': 'الحملات',
  'Workspace settings': 'إعدادات مساحة العمل',
  'Business profile': 'ملف النشاط',
  'Channels': 'القنوات',
  'Catalog': 'الكتالوج',
  'Orders': 'الطلبات',
  'Plan & billing': 'الباقة والفوترة',
  'Home': 'الرئيسية',
  'Settings': 'الإعدادات',
  'Search workspace': 'البحث في مساحة العمل',
  'Workspace owner': 'مالك مساحة العمل',
  'Sign out': 'تسجيل الخروج',
  'Checking channels…': 'جارٍ التحقق من القنوات…',
  'Channel action needed': 'القنوات تحتاج إلى إجراء',
  'Channels verified': 'تم التحقق من القنوات',
  'Channel setup required': 'يلزم إعداد القنوات',
  'Channel status unavailable': 'حالة القنوات غير متاحة',
  'Shared inbox': 'صندوق الوارد المشترك',
  'Your inbox is loading.': 'جارٍ تحميل صندوق الوارد.',
  'Stay close to every conversation.': 'تابع كل محادثة عن قرب.',
  'No conversations yet': 'لا توجد محادثات بعد',
  'Connect and verify WhatsApp Business or Instagram to start receiving real customer messages. This inbox does not contain demo conversations.': 'اربط WhatsApp Business أو Instagram وتحقق منه لبدء استقبال رسائل العملاء الحقيقية. لا يحتوي صندوق الوارد على محادثات تجريبية.',
  'Connect a channel': 'ربط قناة',
  'Manage channels': 'إدارة القنوات',
  'Search conversations': 'البحث في المحادثات',
  'All': 'الكل',
  'Open': 'مفتوحة',
  'Hand off to team': 'تحويل إلى الفريق',
  'Write a reply in English or العربية...': 'اكتب ردًا بالعربية أو الإنجليزية...',
  'Messages are sent only after the provider accepts them.': 'لا يتم إرسال الرسائل إلا بعد قبول مزود الخدمة لها.',
  'Connect WhatsApp Business through Gupshup. A channel is marked connected only after provider verification.': 'اربط WhatsApp Business عبر Gupshup. لن تظهر القناة كمتصلة إلا بعد التحقق الفعلي من المزود.',
  'Checking provider state…': 'جارٍ التحقق من حالة مزود الخدمة…',
  'Connected': 'متصل',
  'Authorization in progress': 'جارٍ التفويض',
  'Verification failed': 'فشل التحقق',
  'Disconnected': 'غير متصل',
  'Not connected': 'غير متصل',
  'Error': 'خطأ',
  'Paused': 'متوقف مؤقتًا',
  'Setup required': 'غير متصل',
  'Verified': 'تم التحقق',
  'Connecting': 'جارٍ الربط',
  'Action needed': 'يلزم إجراء',
  'Not ready': 'غير متصل',
  'Disconnect': 'قطع الاتصال',
  'Checking…': 'جارٍ التحقق…',
  'Try again': 'إعادة المحاولة',
  'Connect': 'ربط',
  'WhatsApp app ID': 'معرّف تطبيق WhatsApp',
  'WhatsApp app name': 'اسم تطبيق WhatsApp',
  'WhatsApp business number': 'رقم WhatsApp للأعمال',
  'These details identify your WhatsApp app. Your provider key stays private on the server.': 'تُستخدم هذه البيانات لتحديد تطبيق WhatsApp الخاص بك. يبقى مفتاح المزود محفوظًا بشكل خاص على الخادم.',
  'Retry': 'إعادة المحاولة',
  'Could not connect to the server.': 'تعذر الاتصال بالخادم.',
  'Workspace overview': 'نظرة عامة على مساحة العمل',
  'Good morning.': 'مرحبًا.',
  'Open daily brief': 'فتح الملخص اليومي',
  'Conversations': 'المحادثات',
  'New leads': 'العملاء المحتملون الجدد',
  'Appointments booked': 'المواعيد المحجوزة',
  'Connect a channel to begin': 'اربط قناة للبدء',
  'Your next conversations': 'محادثاتك التالية',
  'Your shared inbox is waiting for a channel': 'صندوق الوارد المشترك بانتظار ربط قناة',
  'Assistant health': 'حالة المساعد',
  'Ready to be trained.': 'جاهز للتدريب.',
  'PAUSED': 'متوقف مؤقتًا',
  'No items yet': 'لا توجد عناصر بعد',
  'Real workspace data will appear here after you add it.': 'ستظهر بيانات مساحة العمل الحقيقية هنا بعد إضافتها.',
  'Save changes': 'حفظ التغييرات',
  'Saved': 'تم الحفظ',
  'Business name': 'اسم النشاط',
  'Industry': 'نوع النشاط',
  'Country': 'الدولة',
  'Your profile is up to date.': 'تم تحديث ملف النشاط.',
  'Workspace setup': 'إعداد مساحة العمل',
  'Tell us about your business.': 'أخبرنا عن نشاطك.',
  'Choose your channels.': 'اختر قنواتك.',
  'Your workspace is ready.': 'مساحة عملك جاهزة.',
  'Step': 'الخطوة',
  'of': 'من',
  'Continue': 'متابعة',
  'Open workspace': 'فتح مساحة العمل',
  'Connect later from Channels': 'يمكنك الربط لاحقًا من صفحة القنوات',
  'Your workspace has been created. Connect a channel when you are ready to start receiving conversations.': 'تم إنشاء مساحة العمل. اربط قناة عندما تكون جاهزًا لاستقبال المحادثات.',
  'Welcome back': 'مرحبًا بعودتك',
  'Start your workspace': 'ابدأ مساحة عملك',
  'Good to see you again.': 'سعداء برؤيتك مجددًا.',
  'A better inbox starts here.': 'صندوق وارد أفضل يبدأ هنا.',
  'Work email': 'البريد الإلكتروني للعمل',
  'Password': 'كلمة المرور',
  'Forgot password?': 'هل نسيت كلمة المرور؟',
  'Sign in to FansConnect': 'تسجيل الدخول إلى FansConnect',
  'Create workspace': 'إنشاء مساحة العمل',
  'Business name (optional)': 'اسم النشاط (اختياري)',
  'New to FansConnect?': 'جديد في FansConnect؟',
  'Already have a workspace?': 'لديك مساحة عمل بالفعل؟',
  'Create an account': 'إنشاء حساب',
  'Sign in': 'تسجيل الدخول',
  'Reset your password': 'إعادة تعيين كلمة المرور',
  'Send reset link': 'إرسال رابط إعادة التعيين',
  'New password': 'كلمة المرور الجديدة',
  'Reset password': 'إعادة تعيين كلمة المرور',
  'Verify your email': 'تحقق من بريدك الإلكتروني',
  'Verify email': 'تأكيد البريد الإلكتروني',
  'Email verified': 'تم تأكيد البريد الإلكتروني',
  'Access denied': 'تم رفض الوصول',
  'Your session has expired. Please sign in again.': 'انتهت صلاحية جلستك. يرجى تسجيل الدخول مرة أخرى.',
};

const LanguageContext = createContext<{ language: Language; t: (text: string) => string }>({ language: 'ar', t: (text) => text });
const AuthContext = createContext<AuthState>({ loading: true, authenticated: false, onboardingCompleted: false, workspace: null, refresh: async () => {}, signOut: async () => {} });
const useLanguage = () => useContext(LanguageContext);
const useAuth = () => useContext(AuthContext);

const apiRequest = async <T,>(path: string, init?: RequestInit): Promise<T> => {
  let response: Response;
  try {
    response = await fetch(`/api${path}`, {
      ...init,
      credentials: 'include',
      headers: { 'content-type': 'application/json', ...(init?.headers ?? {}) },
    });
  } catch {
    throw Object.assign(new Error('Could not connect to the server.'), { status: 0 });
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401) window.dispatchEvent(new CustomEvent('fansconnect:session-expired'));
    throw Object.assign(new Error(payload.message || payload.error || 'Workspace service unavailable.'), { status: response.status, payload });
  }
  return payload as T;
};

const workspaceApi = async <T,>(path: string, init?: RequestInit): Promise<T> => {
  return apiRequest<T>(`/workspaces/current${path}`, init);
};

const liveChannelLabel = (channel: LiveChannel['channel']) => channel === 'whatsapp' ? 'WhatsApp Business' : 'Instagram Direct';
const liveChannelMark = (channel: LiveChannel['channel']): Channel => channel === 'whatsapp' ? 'WhatsApp' : 'Instagram';

const formatAED = (amount: number, locale = 'en-AE') => new Intl.NumberFormat(locale, {
  style: 'currency',
  currency: 'AED',
  maximumFractionDigits: 0,
}).format(amount);

const conversationsSeed: Conversation[] = [
  { id: 1, contactName: 'New conversation', avatar: 'NC', channel: 'WhatsApp', lastMessage: 'Can you share the available options?', timestamp: '09:42', unread: 2, status: 'Open', tags: ['High intent'], messages: [{ from: 'customer', text: 'Hello, I would like to learn more about your services.', time: '09:30' }, { from: 'team', text: 'Welcome. I can share the options and help you choose the right one.', time: '09:34' }, { from: 'customer', text: 'Can you share the available options?', time: '09:42' }] },
  { id: 2, contactName: 'Instagram enquiry', avatar: 'IE', channel: 'Instagram', lastMessage: 'Is this available this week?', timestamp: '09:16', unread: 1, status: 'Open', tags: ['Product question'], messages: [{ from: 'customer', text: 'This looks great. Is it available this week?', time: '09:16' }] },
  { id: 3, contactName: 'Quote request', avatar: 'QR', channel: 'WhatsApp', lastMessage: 'I will send the details now.', timestamp: 'Yesterday', unread: 0, status: 'Pending', tags: ['Quote'], messages: [{ from: 'team', text: 'We can prepare a tailored quote once we have the details.', time: 'Yesterday' }, { from: 'customer', text: 'I will send the details now.', time: 'Yesterday' }] },
  { id: 4, contactName: 'Appointment enquiry', avatar: 'AE', channel: 'WhatsApp', lastMessage: 'Can I move my appointment to 5pm?', timestamp: 'Yesterday', unread: 0, status: 'Open', tags: ['Appointment'], messages: [{ from: 'customer', text: 'Can I move my appointment to 5pm?', time: 'Yesterday' }] },
  { id: 5, contactName: 'Partnership enquiry', avatar: 'PE', channel: 'Instagram', lastMessage: 'We would love to collaborate this season.', timestamp: 'Monday', unread: 0, status: 'Resolved', tags: ['Partnership'], messages: [{ from: 'customer', text: 'We would love to collaborate this season.', time: 'Monday' }] },
];

const contactsSeed = [
  { id: 1, name: 'New conversation', phone: '+971 50 000 0000', source: 'WhatsApp', lastSeen: 'Today, 09:42', segment: 'High intent', status: 'Lead' },
  { id: 2, name: 'Instagram enquiry', phone: '@yourbusiness', source: 'Instagram', lastSeen: 'Today, 09:16', segment: 'Product question', status: 'New' },
  { id: 3, name: 'Quote request', phone: '+971 50 000 0001', source: 'WhatsApp', lastSeen: 'Yesterday, 18:20', segment: 'Quote', status: 'Lead' },
  { id: 4, name: 'Appointment enquiry', phone: '+971 50 000 0002', source: 'WhatsApp', lastSeen: 'Yesterday, 16:04', segment: 'Appointment', status: 'Customer' },
  { id: 5, name: 'Partnership enquiry', phone: '@yourbusiness', source: 'Instagram', lastSeen: 'Monday, 11:30', segment: 'Partnership', status: 'Customer' },
  { id: 6, name: 'Returning customer', phone: '+971 50 000 0003', source: 'WhatsApp', lastSeen: 'Sunday, 14:08', segment: 'Returning', status: 'Customer' },
];

const leadsSeed = [
  { id: 1, name: 'New conversation', service: 'Service enquiry', value: 4200, stage: 'Qualified', source: 'WhatsApp', createdAt: 'Today, 09:34' },
  { id: 2, name: 'Quote request', service: 'Custom quote', value: 1850, stage: 'New', source: 'WhatsApp', createdAt: 'Yesterday' },
  { id: 3, name: 'Instagram enquiry', service: 'Product question', value: 680, stage: 'Proposal', source: 'Instagram', createdAt: 'Monday' },
  { id: 4, name: 'Returning customer', service: 'Repeat service', value: 2400, stage: 'Won', source: 'WhatsApp', createdAt: 'Last week' },
  { id: 5, name: 'Partnership enquiry', service: 'Business enquiry', value: 3200, stage: 'Contacted', source: 'Instagram', createdAt: 'Last week' },
];

const appointmentsSeed = [
  { id: 1, client: 'New conversation', service: 'Initial consultation', date: 'Thursday', time: '11:30 AM', status: 'Confirmed' },
  { id: 2, client: 'Appointment enquiry', service: 'Follow-up meeting', date: 'Thursday', time: '05:00 PM', status: 'Confirmed' },
  { id: 3, client: 'Returning customer', service: 'Service appointment', date: 'Friday', time: '10:00 AM', status: 'Pending' },
  { id: 4, client: 'Instagram enquiry', service: 'Product consultation', date: 'Saturday', time: '01:30 PM', status: 'Confirmed' },
];

const navGroups: { label: string; items: { href: string; label: string; icon: React.ElementType; count?: number }[] }[] = [
  { label: 'Workspace', items: [{ href: '/app', label: 'Overview', icon: LayoutDashboard }, { href: '/app/inbox', label: 'Inbox', icon: Inbox }, { href: '/app/contacts', label: 'Contacts', icon: Users }, { href: '/app/leads', label: 'Leads', icon: TrendingUp }, { href: '/app/appointments', label: 'Appointments', icon: CalendarDays }] },
  { label: 'Automation', items: [{ href: '/app/ai-assistant', label: 'AI assistant', icon: Bot }, { href: '/app/training', label: 'FAQ & auto-replies', icon: CircleHelp }, { href: '/app/training', label: 'Training', icon: BookOpen }, { href: '/app/flows', label: 'Flows', icon: Workflow }, { href: '/app/analytics', label: 'Analytics', icon: BarChart3 }, { href: '/app/campaigns', label: 'Campaigns', icon: Send }] },
  { label: 'Workspace settings', items: [{ href: '/app/business-profile', label: 'Business profile', icon: BriefcaseBusiness }, { href: '/app/channels', label: 'Channels', icon: Wifi }, { href: '/app/catalog', label: 'Catalog', icon: Store }, { href: '/app/orders', label: 'Orders', icon: FileText }, { href: '/app/billing', label: 'Plan & billing', icon: WalletCards }] },
];

function Brand({ dark = false }: { dark?: boolean }) {
  return <div className="flex items-center gap-2.5"><div className={`grid size-9 place-items-center rounded-xl ${dark ? 'bg-[#b8e3c2] text-[#173f36]' : 'bg-[#235d51] text-[#f4f0e3]'} shadow-sm`}><MessageCircle size={19} strokeWidth={2.4} /></div><span className={`font-display text-[20px] font-extrabold tracking-[-.04em] ${dark ? 'text-[#f1eadc]' : 'text-[#173f36]'}`}>Fans<span className={dark ? 'text-[#b8e3c2]' : 'text-[#d27f46]'}>Connect</span></span></div>;
}

function Avatar({ initials, tone = 'green', size = 'md' }: { initials: string; tone?: string; size?: 'sm' | 'md' | 'lg' }) {
  const colors: Record<string, string> = { green: 'bg-[#d4e8d8] text-[#245d4f]', clay: 'bg-[#f2d8c6] text-[#954b2d]', blue: 'bg-[#d7e6e8] text-[#286270]', plum: 'bg-[#e6dbea] text-[#664d75]', gold: 'bg-[#f5e3b2] text-[#80601d]' };
  return <div data-testid={`avatar-${initials}`} className={`grid shrink-0 place-items-center rounded-full font-display font-bold ${colors[tone] ?? colors.green} ${size === 'sm' ? 'size-7 text-[10px]' : size === 'lg' ? 'size-12 text-sm' : 'size-9 text-xs'}`}>{initials}</div>;
}

function ChannelMark({ channel }: { channel: Channel }) {
  return <span className={`inline-grid size-5 place-items-center rounded-md ${channel === 'WhatsApp' ? 'bg-[#d8f0dc] text-[#287550]' : 'bg-[#f6dbe8] text-[#a14472]'}`}>{channel === 'WhatsApp' ? <MessageCircle size={12} /> : <Instagram size={12} />}</span>;
}

function Button({ children, variant = 'primary', className = '', onClick, type = 'button', disabled = false }: { children: React.ReactNode; variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; className?: string; onClick?: () => void; type?: 'button' | 'submit'; disabled?: boolean }) {
  const variants = { primary: 'bg-[#235d51] text-[#f8f2e7] shadow-[0_5px_14px_rgba(35,93,81,.18)] hover:bg-[#194c42]', secondary: 'border border-[#d9d4c8] bg-[#fbf8f0] text-[#28574d] hover:bg-[#f3eddf]', ghost: 'text-[#63766f] hover:bg-[#ece9de] hover:text-[#28574d]', danger: 'border border-[#e9c5be] bg-[#fdf3f0] text-[#ad4b3c] hover:bg-[#fae8e3]' };
  return <button data-testid="button-action" type={type} disabled={disabled} onClick={onClick} className={`focus-ring inline-flex items-center justify-center gap-2 rounded-xl px-3.5 py-2.5 text-[13px] font-bold transition-all duration-200 active:translate-y-px disabled:cursor-not-allowed disabled:opacity-50 ${variants[variant]} ${className}`}>{children}</button>;
}

function Badge({ children, tone = 'neutral' }: { children: React.ReactNode; tone?: 'green' | 'gold' | 'blue' | 'red' | 'neutral' }) {
  const tones = { green: 'bg-[#e0f1e2] text-[#2c7154]', gold: 'bg-[#f8ebc7] text-[#8b6824]', blue: 'bg-[#e1eef0] text-[#34707a]', red: 'bg-[#f7e2dc] text-[#a25243]', neutral: 'bg-[#eeece5] text-[#66766f]' };
  return <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-bold ${tones[tone]}`}>{children}</span>;
}

function LegacyShell({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [channelHealth, setChannelHealth] = useState('Checking channels…');
  const current = navGroups.flatMap(group => group.items).find(item => location === item.href)?.label ?? 'Overview';
  useEffect(() => {
    workspaceApi<{ channels: LiveChannel[] }>('/channels').then(({ channels }) => {
      if (channels.some((item) => item.status === 'failed' || item.status === 'degraded')) setChannelHealth('Channel action needed');
      else if (channels.length > 0 && channels.every((item) => item.status === 'connected' && item.verified)) setChannelHealth('Channels verified');
      else setChannelHealth('Channel setup required');
    }).catch(() => setChannelHealth('Channel status unavailable'));
  }, []);
  return <div className="app-shell grain flex">
    <aside className={`desktop-sidebar fixed inset-y-0 left-0 z-40 flex w-[248px] flex-col border-r border-[#2a5147] bg-[#173f36] px-4 py-5 text-[#ecede1] transition-transform duration-300 ${mobileOpen ? 'translate-x-0' : ''}`}>
      <div className="mb-8 flex items-center justify-between px-2"><Brand dark /><button data-testid="button-close-sidebar" className="text-[#94b8a6] md:hidden" onClick={() => setMobileOpen(false)}><X size={19} /></button></div>
      <div className="mb-6 flex items-center gap-3 rounded-2xl border border-[#356357] bg-[#214c42] p-3"><div className="grid size-9 place-items-center rounded-xl bg-[#e8d8b8] font-display text-sm font-extrabold text-[#28574d]">FC</div><div className="min-w-0"><div className="truncate text-[13px] font-bold">Your workspace</div><div className="mt-0.5 text-[10px] text-[#9cbaab]">United Arab Emirates</div></div><ChevronDown size={15} className="ml-auto text-[#9cbaab]" /></div>
      <nav className="flex-1 space-y-6 overflow-y-auto">{navGroups.map(group => <div key={group.label}><div className="mb-2 px-3 text-[10px] font-bold uppercase tracking-[.16em] text-[#7ea496]">{group.label}</div><div className="space-y-1">{group.items.map(item => { const active = location === item.href || (item.href !== '/app' && location.startsWith(item.href)); const Icon = item.icon; return <Link key={item.label} href={item.href} data-testid={`link-${item.label.toLowerCase().replaceAll(' ', '-')}`} onClick={() => setMobileOpen(false)} className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-semibold transition-colors ${active ? 'bg-[#b8e3c2] text-[#173f36] shadow-[0_4px_16px_rgba(184,227,194,.12)]' : 'text-[#a9c4b7] hover:bg-[#214c42] hover:text-[#f1eadc]'}`}><Icon size={17} strokeWidth={active ? 2.5 : 1.8} /><span className="flex-1">{item.label}</span>{item.count && <span className={`grid size-5 place-items-center rounded-full text-[10px] ${active ? 'bg-[#173f36] text-[#b8e3c2]' : 'bg-[#cc7c4c] text-white'}`}>{item.count}</span>}</Link>})}</div></div>)}</nav>
      <div className="mt-4 border-t border-[#2a5147] pt-4"><div className="mb-3 flex items-center gap-3 px-2"><Avatar initials="FC" tone="gold" size="sm" /><div className="min-w-0 flex-1"><div className="truncate text-xs font-bold">Workspace owner</div><div className="truncate text-[10px] text-[#91b1a2]">Admin account</div></div><button data-testid="button-sidebar-settings" onClick={() => setLocation('/app/business-profile')} className="text-[#91b1a2] hover:text-[#e8d8b8]"><Settings2 size={16} /></button></div><div className="flex items-center justify-between rounded-xl bg-[#214c42] px-3 py-2"><div className="flex items-center gap-2 text-[11px] text-[#b7d2c4]"><span className="size-2 rounded-full bg-[#e7c893]" />{channelHealth}</div><Link href="/app/channels" className="text-[#8aad9c] hover:text-[#e8d8b8]" aria-label="Manage channel setup"><CircleHelp size={14} /></Link></div></div>
    </aside>
    {mobileOpen && <button data-testid="button-overlay" className="fixed inset-0 z-30 bg-[#173f36]/35 md:hidden" onClick={() => setMobileOpen(false)} />}
      <main className="workspace ml-0 flex min-h-[100dvh] w-full flex-col md:ml-[248px]">
        <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-[#e6e0d4] bg-[#f8f5ec]/90 px-5 backdrop-blur-md md:px-9"><div className="flex items-center gap-3"><button data-testid="button-open-sidebar" className="text-[#315f54] md:hidden" onClick={() => setMobileOpen(true)}><Menu size={21} /></button><div><div className="text-[11px] font-bold uppercase tracking-[.16em] text-[#82948c]">Your workspace</div><div className="font-display text-[19px] font-extrabold tracking-[-.035em] text-[#1c4b40]">{current}</div></div></div><div className="flex items-center gap-2.5"><div className="hidden items-center gap-2 rounded-xl border border-[#e4dfd3] bg-[#fbf9f3] px-3 py-2 text-[12px] text-[#87968e] lg:flex"><Search size={15} /><span>Search workspace</span><span className="ml-5 rounded-md bg-[#eeece4] px-1.5 py-0.5 font-mono-custom text-[9px]">⌘ K</span></div><button data-testid="button-notifications" className="focus-ring relative grid size-10 place-items-center rounded-xl border border-[#e4dfd3] bg-[#fbf9f3] text-[#5c746b] transition hover:bg-[#eee9dc]"><Bell size={17} /><span className="absolute right-2 top-2 size-1.5 rounded-full bg-[#cc7c4c]" /></button><div className="relative"><button data-testid="button-profile-menu" onClick={() => setProfileOpen(!profileOpen)} className="focus-ring flex items-center gap-2 rounded-xl px-1.5 py-1 text-left hover:bg-[#eee9dc]"><Avatar initials="FC" tone="gold" size="sm" /><ChevronDown size={14} className="text-[#82948c]" /></button>{profileOpen && <div className="absolute right-0 top-12 z-30 w-44 rounded-2xl border border-[#e1dbcf] bg-[#fbf9f3] p-1.5 shadow-[0_12px_35px_rgba(38,73,62,.14)]"><Link data-testid="link-profile-settings" href="/app/business-profile" className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-xs font-bold text-[#315f54] hover:bg-[#eee9dc]"><Settings2 size={14} />Workspace settings</Link><Link data-testid="link-sign-out" href="/login" className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-xs font-bold text-[#ad4b3c] hover:bg-[#f7e2dc]"><ArrowRight size={14} />Sign out</Link></div>}</div></div></header>
      <div className="flex-1 px-5 py-7 md:px-9 md:py-8">{children}</div>
      <div className="mobile-nav fixed bottom-0 left-0 right-0 z-30 items-center justify-around border-t border-[#ded8ca] bg-[#fbf9f3]/95 px-2 py-2 backdrop-blur-md"><Link data-testid="link-mobile-overview" href="/app" className="grid justify-items-center gap-1 px-3 py-1 text-[10px] font-bold text-[#315f54]"><LayoutDashboard size={18} /><span>Home</span></Link><Link data-testid="link-mobile-inbox" href="/app/inbox" className="relative grid justify-items-center gap-1 px-3 py-1 text-[10px] font-bold text-[#315f54]"><Inbox size={18} /><span>Inbox</span><span className="absolute right-1 top-0 size-2 rounded-full bg-[#cc7c4c]" /></Link><Link data-testid="link-mobile-leads" href="/app/leads" className="grid justify-items-center gap-1 px-3 py-1 text-[10px] font-bold text-[#315f54]"><TrendingUp size={18} /><span>Leads</span></Link><Link data-testid="link-mobile-settings" href="/app/business-settings" className="grid justify-items-center gap-1 px-3 py-1 text-[10px] font-bold text-[#315f54]"><Settings2 size={18} /><span>Settings</span></Link></div>
    </main>
  </div>;
}

function Shell({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const { t } = useLanguage();
  const auth = useAuth();
  const current = navGroups.flatMap((group) => group.items).find((item) => location === item.href)?.label ?? 'Overview';
  const name = auth.workspace?.workspace.name || t('Workspace');
  const email = auth.workspace?.user.email || '';
  const role = auth.workspace?.user.role || '';
  const initials = (name || email || 'FC').split(/\s+/).map((part) => part[0]).join('').slice(0, 2).toUpperCase();
  const unread = auth.workspace?.counts.unreadConversations || 0;
  const logout = async () => { await auth.signOut(); setLocation('/login'); };
  return <div className="app-shell grain flex">
    <aside className={`desktop-sidebar fixed inset-y-0 z-40 flex w-[248px] flex-col border-[#2a5147] bg-[#173f36] px-4 py-5 text-[#ecede1] transition-transform duration-300 ${mobileOpen ? 'translate-x-0' : ''}`}>
      <div className="mb-8 flex items-center justify-between px-2"><Brand dark /><button aria-label={t('Close')} className="text-[#94b8a6] md:hidden" onClick={() => setMobileOpen(false)}><X size={19} /></button></div>
      <div className="mb-6 flex items-center gap-3 rounded-2xl border border-[#356357] bg-[#214c42] p-3"><div className="grid size-9 place-items-center rounded-xl bg-[#e8d8b8] font-display text-sm font-extrabold text-[#28574d]">{initials}</div><div className="min-w-0"><div className="truncate text-[13px] font-bold">{name}</div><div className="mt-0.5 truncate text-[10px] text-[#9cbaab]">{email}</div></div></div>
      <nav className="flex-1 space-y-6 overflow-y-auto">{navGroups.map((group) => <div key={group.label}><div className="mb-2 px-3 text-[10px] font-bold uppercase tracking-[.16em] text-[#7ea496]">{t(group.label)}</div><div className="space-y-1">{group.items.map((item) => { const active = location === item.href || (item.href !== '/app' && location.startsWith(item.href)); const Icon = item.icon; const count = item.href === '/app/inbox' ? unread : 0; return <Link key={item.label} href={item.href} onClick={() => setMobileOpen(false)} className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-semibold transition-colors ${active ? 'bg-[#b8e3c2] text-[#173f36]' : 'text-[#a9c4b7] hover:bg-[#214c42] hover:text-[#f1eadc]'}`}><Icon size={17} /><span className="flex-1">{t(item.label)}</span>{count > 0 && <span className="grid size-5 place-items-center rounded-full bg-[#cc7c4c] text-[10px] text-white">{count}</span>}</Link>; })}</div></div>)}</nav>
      <div className="mt-4 border-t border-[#2a5147] pt-4"><div className="flex items-center gap-3 px-2"><Avatar initials={initials} tone="gold" size="sm" /><div className="min-w-0 flex-1"><div className="truncate text-xs font-bold">{email}</div><div className="truncate text-[10px] text-[#91b1a2]">{role}</div></div><button onClick={() => setLocation('/app/business-profile')} className="text-[#91b1a2]"><Settings2 size={16} /></button></div></div>
    </aside>
    {mobileOpen && <button aria-label={t('Close')} className="fixed inset-0 z-30 bg-[#173f36]/35 md:hidden" onClick={() => setMobileOpen(false)} />}
    <main className="workspace flex min-h-[100dvh] w-full flex-col">
      <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-[#e6e0d4] bg-[#f8f5ec]/90 px-5 backdrop-blur-md md:px-9"><div className="flex items-center gap-3"><button aria-label={t('Open menu')} className="text-[#315f54] md:hidden" onClick={() => setMobileOpen(true)}><Menu size={21} /></button><div><div className="text-[11px] font-bold uppercase tracking-[.16em] text-[#82948c]">{name}</div><div className="font-display text-[19px] font-extrabold text-[#1c4b40]">{t(current)}</div></div></div><div className="flex items-center gap-2.5"><div className="hidden items-center gap-2 rounded-xl border border-[#e4dfd3] bg-[#fbf9f3] px-3 py-2 text-[12px] text-[#87968e] lg:flex"><Search size={15} /><span>{t('Search workspace')}</span></div><div className="relative"><button onClick={() => setProfileOpen(!profileOpen)} className="flex items-center gap-2 rounded-xl px-1.5 py-1 hover:bg-[#eee9dc]"><Avatar initials={initials} tone="gold" size="sm" /><ChevronDown size={14} /></button>{profileOpen && <div className="profile-menu absolute top-12 z-30 w-48 rounded-2xl border border-[#e1dbcf] bg-[#fbf9f3] p-1.5 shadow-xl"><Link href="/app/business-profile" className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-xs font-bold text-[#315f54]"><Settings2 size={14} />{t('Business profile')}</Link><button onClick={() => void logout()} className="flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-xs font-bold text-[#ad4b3c]"><LogIn size={14} />{t('Sign out')}</button></div>}</div></div></header>
      <div className="flex-1 px-5 py-7 pb-24 md:px-9 md:py-8">{children}</div>
      <div className="mobile-nav fixed inset-x-0 bottom-0 z-30 items-center justify-around border-t border-[#ded8ca] bg-[#fbf9f3]/95 px-2 py-2 backdrop-blur-md"><Link href="/app" className="grid justify-items-center gap-1 px-3 py-1 text-[10px] font-bold text-[#315f54]"><LayoutDashboard size={18} /><span>{t('Home')}</span></Link><Link href="/app/inbox" className="relative grid justify-items-center gap-1 px-3 py-1 text-[10px] font-bold text-[#315f54]"><Inbox size={18} /><span>{t('Inbox')}</span>{unread > 0 && <span className="absolute right-1 top-0 size-2 rounded-full bg-[#cc7c4c]" />}</Link><Link href="/app/leads" className="grid justify-items-center gap-1 px-3 py-1 text-[10px] font-bold text-[#315f54]"><TrendingUp size={18} /><span>{t('Leads')}</span></Link><Link href="/app/settings" className="grid justify-items-center gap-1 px-3 py-1 text-[10px] font-bold text-[#315f54]"><Settings2 size={18} /><span>{t('Settings')}</span></Link></div>
    </main>
  </div>;
}

function LegacyPageHeading({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: React.ReactNode }) {
  return <div className="page-enter mb-7 flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><div className="mb-2 text-[10px] font-bold uppercase tracking-[.18em] text-[#b66c43]">{eyebrow ?? 'Workspace'}</div><h1 data-testid="text-page-title" className="font-display text-[30px] font-extrabold tracking-[-.05em] text-[#1b4a3f] md:text-[35px]">{title}</h1>{description && <p className="mt-2 max-w-xl text-[13px] leading-6 text-[#71847b]">{description}</p>}</div>{action}</div>;
}

function PageHeading({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: React.ReactNode }) {
  const { t } = useLanguage();
  return <div className="page-enter mb-7 flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><div className="mb-2 text-[10px] font-bold uppercase tracking-[.18em] text-[#b66c43]">{t(eyebrow ?? 'Workspace')}</div><h1 data-testid="text-page-title" className="font-display text-[30px] font-extrabold tracking-[-.05em] text-[#1b4a3f] md:text-[35px]">{t(title)}</h1>{description && <p className="mt-2 max-w-xl text-[13px] leading-6 text-[#71847b]">{t(description)}</p>}</div>{action}</div>;
}

function MetricCard({ label, value, change, detail, icon: Icon, tone = 'green' }: { label: string; value: string; change: string; detail: string; icon: typeof TrendingUp; tone?: string }) {
  return <div className="page-enter rounded-2xl border border-[#e4ded1] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="mb-5 flex items-start justify-between"><div className={`grid size-9 place-items-center rounded-xl ${tone === 'gold' ? 'bg-[#f8eac5] text-[#8a6326]' : tone === 'blue' ? 'bg-[#deedef] text-[#2c7078]' : 'bg-[#dcecdf] text-[#2b6a56]'}`}><Icon size={17} /></div><span className="flex items-center gap-1 text-[11px] font-bold text-[#3d8966]"><ArrowUpRight size={13} />{change}</span></div><div className="font-display text-[29px] font-extrabold tracking-[-.06em] text-[#1b4a3f]">{value}</div><div className="mt-1 text-xs font-bold text-[#536c62]">{label}</div><div className="mt-3 text-[11px] text-[#92a097]">{detail}</div></div>;
}

function Overview() {
  return <WorkspaceHomePage />;
  const [range, setRange] = useState('This week');
  const [showBrief, setShowBrief] = useState(false);
  return <Shell><PageHeading eyebrow="Workspace overview" title="Good morning." description="Here is the pulse of your workspace. Your assistant handled the first replies while you were away." action={<div className="flex gap-2"><select data-testid="select-overview-range" value={range} onChange={e => setRange(e.target.value)} className="focus-ring rounded-xl border border-[#dfd9cc] bg-[#fbf9f3] px-3 py-2.5 text-xs font-bold text-[#48665b]"><option>This week</option><option>Last week</option><option>This month</option></select><Button onClick={() => setShowBrief(!showBrief)}><Sparkles size={15} />{showBrief ? 'Hide brief' : 'Open daily brief'}</Button></div>} />
     {showBrief && <div className="page-enter mb-6 flex items-center gap-4 rounded-2xl border border-[#d9e6d6] bg-[#e8f2e4] px-5 py-4 text-[#28574d]"><div className="grid size-9 place-items-center rounded-xl bg-[#c8e3cb]"><BotMessageSquare size={18} /></div><div className="flex-1 text-xs leading-5"><span className="font-bold">Your daily brief:</span> 3 conversations are waiting for your voice. One customer is ready to book, and two follow-ups are due today.</div><button data-testid="button-close-brief" onClick={() => setShowBrief(false)}><X size={16} /></button></div>}
     <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4"><MetricCard label="Conversations" value="128" change="+18.4%" detail="vs. last week" icon={MessageSquareText} /><MetricCard label="Resolved by assistant" value="74.2%" change="+6.8%" detail="conversations resolved" icon={CheckCircle2} tone="blue" /><MetricCard label="New leads" value="23" change="+11.9%" detail="high-intent this week" icon={TrendingUp} tone="gold" /><MetricCard label="Appointments booked" value="12" change="+3 this week" detail={`${formatAED(18450)} attributed`} icon={CalendarCheck2} /></div>
    <div className="mt-6 grid gap-5 xl:grid-cols-[1.45fr_1fr]"><section className="rounded-2xl border border-[#e4ded1] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="mb-5 flex items-center justify-between"><div><h2 className="font-display text-[16px] font-extrabold text-[#28574d]">Conversation pulse</h2><p className="mt-1 text-[11px] text-[#899991]">Messages across both channels</p></div><Link data-testid="link-overview-analytics" href="/app/analytics" className="flex items-center gap-1 text-[11px] font-bold text-[#b66c43] hover:text-[#8f4f31]">View analytics <ArrowUpRight size={13} /></Link></div><div className="flex h-[190px] items-end gap-2 border-b border-[#e5dfd3] px-2 pb-0 pt-7">{[42, 55, 48, 73, 62, 88, 78, 91, 68, 76, 84, 63, 95, 81].map((height, i) => <div key={i} className="group flex h-full flex-1 items-end gap-0.5"><div style={{ height: `${height}%` }} className="w-full rounded-t-md bg-[#b8dec0] transition-all duration-300 group-hover:bg-[#6da883]" /><div style={{ height: `${Math.max(12, height - 28)}%` }} className="w-full rounded-t-md bg-[#e7c893] transition-all duration-300 group-hover:bg-[#d99c4b]" /></div>)}</div><div className="mt-3 flex justify-between text-[10px] text-[#97a49e]"><span>Mon 27</span><span>Tue 28</span><span>Wed 29</span><span>Thu 30</span><span>Fri 31</span><span>Sat 01</span><span>Sun 02</span></div><div className="mt-4 flex gap-4 text-[10px] font-bold text-[#73857c]"><span className="flex items-center gap-1.5"><i className="size-2 rounded-sm bg-[#b8dec0]" />Incoming</span><span className="flex items-center gap-1.5"><i className="size-2 rounded-sm bg-[#e7c893]" />Resolved</span></div></section><section className="rounded-2xl border border-[#e4ded1] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="mb-5 flex items-center justify-between"><div><h2 className="font-display text-[16px] font-extrabold text-[#28574d]">Needs your voice</h2><p className="mt-1 text-[11px] text-[#899991]">Conversations the assistant flagged</p></div><Badge tone="red">3 waiting</Badge></div><div className="space-y-1">{conversationsSeed.slice(0, 3).map((conversation, i) => <Link data-testid={`card-priority-${conversation.id}`} href="/app/inbox" key={conversation.id} className="group flex items-center gap-3 rounded-xl p-2.5 transition hover:bg-[#f0ede4]"><Avatar initials={conversation.avatar} tone={i === 0 ? 'clay' : i === 1 ? 'blue' : 'plum'} size="sm" /><div className="min-w-0 flex-1"><div className="flex items-center gap-1.5 text-xs font-bold text-[#315f54]"><span className="truncate">{conversation.contactName}</span><ChannelMark channel={conversation.channel} /></div><div className="truncate text-[11px] text-[#87968e]">{conversation.lastMessage}</div></div><ChevronRight size={15} className="text-[#a5b0aa] transition group-hover:translate-x-0.5" /></Link>)}</div><Link data-testid="link-open-inbox" href="/app/inbox" className="mt-3 flex items-center justify-center gap-1 border-t border-[#eee9df] pt-4 text-[11px] font-bold text-[#b66c43]">Open inbox <ArrowRight size={13} /></Link></section></div>
    <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_1fr]"><section className="rounded-2xl border border-[#e4ded1] bg-[#fbf9f3] p-5"><div className="mb-4 flex items-center justify-between"><h2 className="font-display text-[16px] font-extrabold text-[#28574d]">Upcoming appointments</h2><Link data-testid="link-overview-appointments" href="/app/appointments" className="text-[11px] font-bold text-[#b66c43]">See calendar</Link></div><div className="space-y-2">{appointmentsSeed.slice(0, 3).map(appointment => <div data-testid={`row-appointment-${appointment.id}`} key={appointment.id} className="flex items-center gap-3 rounded-xl border border-[#eee9df] bg-[#fdfbf6] px-3 py-2.5"><div className="grid size-9 place-items-center rounded-xl bg-[#e8f0e4] text-[#39745a]"><CalendarDays size={16} /></div><div className="min-w-0 flex-1"><div className="text-xs font-bold text-[#315f54]">{appointment.client}</div><div className="truncate text-[11px] text-[#8b9993]">{appointment.service}</div></div><div className="text-right"><div className="text-[11px] font-bold text-[#315f54]">{appointment.time}</div><div className="text-[10px] text-[#9aa69f]">{appointment.date}</div></div></div>)}</div></section><section className="rounded-2xl border border-[#dce5d9] bg-[#e8f2e4] p-5"><div className="mb-4 flex items-start justify-between"><div><div className="mb-2 flex items-center gap-2"><span className="grid size-7 place-items-center rounded-lg bg-[#cae3ca] text-[#2d7054]"><Bot size={15} /></span><span className="text-[10px] font-bold uppercase tracking-[.14em] text-[#628570]">Assistant health</span></div><h2 className="font-display text-[20px] font-extrabold tracking-[-.04em] text-[#28574d]">On, listening, helpful.</h2></div><Badge tone="green">Live</Badge></div><p className="max-w-sm text-xs leading-5 text-[#658477]">Saha is answering common questions in English and Arabic, and knows when to hand a conversation back to you.</p><div className="mt-5 flex items-end justify-between border-t border-[#d1e2d0] pt-4"><div><div className="font-mono-custom text-[22px] font-bold text-[#2d7054]">94.8%</div><div className="text-[10px] text-[#789489]">positive conversations</div></div><Link data-testid="link-configure-assistant" href="/app/bot-settings" className="flex items-center gap-1 text-[11px] font-bold text-[#2d7054]">Configure <ArrowUpRight size={13} /></Link></div></section></div>
  </Shell>;
}

function LegacyInboxPage() {
  const [selected, setSelected] = useState(1);
  const [filter, setFilter] = useState('All');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState<Record<number, string[]>>({});
  const current = conversationsSeed.find(c => c.id === selected) ?? conversationsSeed[0];
  const filtered = conversationsSeed.filter(c => filter === 'All' || c.channel === filter || c.status === filter);
  const send = () => { if (!message.trim()) return; setSent(prev => ({ ...prev, [selected]: [...(prev[selected] ?? []), message.trim()] })); setMessage(''); };
  return <Shell><div className="page-enter mb-5 flex flex-col justify-between gap-4 md:flex-row md:items-center"><div><div className="mb-2 text-[10px] font-bold uppercase tracking-[.18em] text-[#b66c43]">Shared inbox</div><h1 className="font-display text-[30px] font-extrabold tracking-[-.05em] text-[#1b4a3f]">Stay close to every conversation.</h1></div><div className="flex gap-2"><Button variant="secondary"><Filter size={15} />Filters</Button><Button><Plus size={15} />New message</Button></div></div><div className="grid min-h-[650px] overflow-hidden rounded-2xl border border-[#e1dbce] bg-[#fbf9f3] shadow-[var(--shadow-card)] md:grid-cols-[300px_1fr_250px]"><section className="border-b border-[#e5dfd4] md:border-b-0 md:border-r"><div className="border-b border-[#eee9df] p-4"><div className="relative"><Search size={15} className="absolute left-3 top-3 text-[#98a69f]" /><input data-testid="input-search-inbox" placeholder="Search conversations" className="focus-ring w-full rounded-xl border border-[#e2dcd1] bg-[#f5f2e9] py-2.5 pl-9 pr-3 text-xs text-[#315f54] outline-none placeholder:text-[#9aa69e]" /></div><div className="mt-3 flex gap-1 overflow-auto">{['All', 'WhatsApp', 'Instagram', 'Open'].map(item => <button data-testid={`button-filter-${item.toLowerCase()}`} key={item} onClick={() => setFilter(item)} className={`whitespace-nowrap rounded-lg px-2.5 py-1.5 text-[10px] font-bold transition ${filter === item ? 'bg-[#d9e9d8] text-[#2f7055]' : 'text-[#899991] hover:bg-[#eee9df]'}`}>{item}</button>)}</div></div><div className="max-h-[545px] overflow-auto p-2">{filtered.map((conversation, i) => <button data-testid={`button-conversation-${conversation.id}`} key={conversation.id} onClick={() => setSelected(conversation.id)} className={`float-in flex w-full items-start gap-3 rounded-xl p-3 text-left transition ${selected === conversation.id ? 'bg-[#e4f0e2]' : 'hover:bg-[#f0ede4]'}`} style={{ animationDelay: `${i * 55}ms` }}><div className="relative"><Avatar initials={conversation.avatar} tone={i % 3 === 0 ? 'clay' : i % 3 === 1 ? 'blue' : 'green'} size="sm" />{conversation.unread > 0 && <span className="absolute -right-1 -top-1 grid size-4 place-items-center rounded-full bg-[#cc7c4c] text-[9px] font-bold text-white">{conversation.unread}</span>}</div><div className="min-w-0 flex-1"><div className="flex items-center justify-between gap-2"><span className="truncate text-xs font-bold text-[#315f54]">{conversation.contactName}</span><span className="text-[10px] text-[#99a49e]">{conversation.timestamp}</span></div><div className="mt-1 truncate text-[11px] text-[#87958e]">{conversation.lastMessage}</div><div className="mt-2 flex items-center gap-1.5"><ChannelMark channel={conversation.channel} /><span className="text-[9px] font-bold text-[#8b9b92]">{conversation.status}</span></div></div></button>)}</div></section><section className="flex min-h-[550px] flex-col border-b border-[#e5dfd4] md:border-b-0 md:border-r"><div className="flex items-center justify-between border-b border-[#eee9df] px-5 py-3.5"><div className="flex items-center gap-3"><Avatar initials={current.avatar} tone="clay" /><div><div className="flex items-center gap-2 text-sm font-bold text-[#28574d]">{current.contactName}<ChannelMark channel={current.channel} /></div><div className="text-[10px] text-[#95a29c]">Last active 2 minutes ago</div></div></div><div className="flex gap-1"><button data-testid="button-mark-resolved" className="grid size-8 place-items-center rounded-lg text-[#759086] hover:bg-[#e8f0e4] hover:text-[#2e7355]" title="Mark resolved"><CheckCircle2 size={16} /></button><button data-testid="button-more-conversation" className="grid size-8 place-items-center rounded-lg text-[#759086] hover:bg-[#eee9df]"><MoreHorizontal size={17} /></button></div></div><div className="flex-1 space-y-4 overflow-auto bg-[#f7f4eb] p-5"><div className="flex justify-center"><span className="rounded-full bg-[#ebe7db] px-3 py-1 text-[9px] font-bold uppercase tracking-wider text-[#95a198]">Today</span></div>{current.messages.map((msg, i) => <div key={`${current.id}-${i}`} className={`flex ${msg.from === 'team' ? 'justify-end' : 'justify-start'}`}><div className={`max-w-[78%] rounded-2xl px-3.5 py-2.5 text-xs leading-5 shadow-sm ${msg.from === 'team' ? 'rounded-br-md bg-[#d5ebd7] text-[#315f54]' : 'rounded-bl-md border border-[#e4ded3] bg-[#fbf9f3] text-[#506961]'}`}><div>{msg.text}</div><div className={`mt-1 text-[9px] ${msg.from === 'team' ? 'text-[#6d9580]' : 'text-[#9ba69f]'}`}>{msg.time}</div></div></div>)}{(sent[current.id] ?? []).map((text, i) => <div key={`sent-${i}`} className="flex justify-end"><div className="max-w-[78%] rounded-2xl rounded-br-md bg-[#d5ebd7] px-3.5 py-2.5 text-xs leading-5 text-[#315f54] shadow-sm"><div>{text}</div><div className="mt-1 text-[9px] text-[#6d9580]">Just now</div></div></div>)}</div><div className="border-t border-[#e6e0d5] bg-[#fbf9f3] p-4"><div className="flex items-end gap-2 rounded-xl border border-[#ddd8cc] bg-[#f7f4eb] p-1.5"><textarea data-testid="textarea-reply" value={message} onChange={e => setMessage(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} rows={1} placeholder="Write a reply in English or العربية..." className="focus-ring min-h-9 flex-1 resize-none bg-transparent px-2 py-2 text-xs text-[#315f54] outline-none placeholder:text-[#99a69e]" /><button data-testid="button-send-reply" onClick={send} className="grid size-9 place-items-center rounded-lg bg-[#235d51] text-[#f8f2e7] transition hover:bg-[#194c42] disabled:opacity-40" disabled={!message.trim()}><Send size={15} /></button></div><div className="mt-2 flex items-center justify-between px-1 text-[9px] text-[#9aa59f]"><span>Press Enter to send</span><button data-testid="button-suggest-reply" className="flex items-center gap-1 font-bold text-[#ad704c] hover:text-[#8f4f31]"><Sparkles size={11} />Suggest reply</button></div></div></section><aside className="hidden p-5 md:block"><div className="mb-5 flex items-center justify-between"><span className="text-[10px] font-bold uppercase tracking-[.15em] text-[#9aa59f]">Contact context</span><button data-testid="button-edit-contact" className="text-[#b66c43]"><Pencil size={14} /></button></div><div className="flex flex-col items-center text-center"><Avatar initials={current.avatar} tone="clay" size="lg" /><div className="mt-3 font-display text-[16px] font-extrabold text-[#28574d]">{current.contactName}</div><div className="mt-1 text-[11px] text-[#94a29b]">{current.channel === 'WhatsApp' ? '+966 55 291 8042' : '@mariam.studio'}</div></div><div className="my-5 border-t border-[#eee9df]" /><div className="space-y-4"><div><div className="mb-2 text-[10px] font-bold uppercase tracking-wider text-[#a0aaa4]">Labels</div><div className="flex flex-wrap gap-1.5">{current.tags.map(tag => <Badge key={tag} tone={tag === 'High intent' ? 'gold' : 'neutral'}>{tag}</Badge>)}<button data-testid="button-add-tag" className="grid size-6 place-items-center rounded-full border border-dashed border-[#c6cfc8] text-[#8ca098] hover:border-[#6da883] hover:text-[#39745a]"><Plus size={12} /></button></div></div><div><div className="mb-2 text-[10px] font-bold uppercase tracking-wider text-[#a0aaa4]">Lead status</div><select data-testid="select-lead-status" className="w-full rounded-lg border border-[#e3ddd2] bg-[#f7f4eb] px-2.5 py-2 text-xs font-bold text-[#527068] outline-none"><option>Qualified</option><option>New</option><option>Follow-up</option><option>Won</option></select></div><div><div className="mb-2 text-[10px] font-bold uppercase tracking-wider text-[#a0aaa4]">Notes</div><div className="rounded-xl bg-[#f3efe5] p-3 text-[11px] leading-5 text-[#7d8f86]">Interested in November. Prefers morning consultations.</div></div></div></aside></div></Shell>;
}

function LegacyRealInboxPage() {
  const [conversations, setConversations] = useState<LiveConversation[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [filter, setFilter] = useState('All');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    workspaceApi<{ conversations: LiveConversation[] }>('/conversations')
      .then(({ conversations: next }) => {
        setConversations(next);
        setSelectedId(next[0]?.id ?? null);
      })
      .catch((reason: Error) => setError(reason.message))
      .finally(() => setLoading(false));
  }, []);

  const filtered = conversations.filter((conversation) =>
    filter === 'All' || conversation.channel === filter.toLowerCase() || conversation.status === filter.toLowerCase(),
  );
  const current = filtered.find((conversation) => conversation.id === selectedId) ?? filtered[0] ?? null;

  const send = async () => {
    if (!current || !message.trim() || busy) return;
    setBusy(true);
    setError('');
    try {
      const result = await workspaceApi<{ conversation: LiveConversation }>(
        `/conversations/${current.id}/replies`,
        { method: 'POST', body: JSON.stringify({ text: message.trim() }) },
      );
      setConversations((previous) => previous.map((item) => item.id === result.conversation.id ? result.conversation : item));
      setMessage('');
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'The provider rejected this reply.');
    } finally {
      setBusy(false);
    }
  };

  const handoff = async () => {
    if (!current || busy) return;
    setBusy(true);
    setError('');
    try {
      const result = await workspaceApi<{ conversation: LiveConversation }>(
        `/conversations/${current.id}/handoff`,
        { method: 'POST', body: JSON.stringify({}) },
      );
      setConversations((previous) => previous.map((item) => item.id === result.conversation.id ? result.conversation : item));
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'The handoff could not be completed.');
    } finally {
      setBusy(false);
    }
  };

  if (loading) return <Shell><PageHeading eyebrow="Shared inbox" title="Your inbox is loading." description="Conversations appear here after a verified channel receives a message." /></Shell>;

  return <Shell>
    <PageHeading eyebrow="Shared inbox" title="Stay close to every conversation." description="Replies and assistant handoffs are sent through the verified channel that received the message." action={<Link href="/app/channels" className="inline-flex items-center gap-2 rounded-xl border border-[#d9d4c8] bg-[#fbf8f0] px-3.5 py-2.5 text-[13px] font-bold text-[#28574d]">Manage channels <Link2 size={14} /></Link>} />
    {error && <div data-testid="inbox-error" className="mb-5 flex items-start gap-2 rounded-xl border border-[#e9c5be] bg-[#fdf3f0] px-4 py-3 text-xs font-bold text-[#a25243]"><AlertCircle size={15} className="mt-0.5 shrink-0" />{error}</div>}
    {conversations.length === 0 ? <div className="rounded-2xl border border-dashed border-[#d7dfd5] bg-[#f3f7ee] p-10 text-center"><Inbox size={28} className="mx-auto text-[#7da189]" /><h2 className="mt-4 font-display text-lg font-extrabold text-[#315f54]">No conversations yet</h2><p className="mx-auto mt-2 max-w-md text-xs leading-5 text-[#71857b]">Connect and verify WhatsApp Business or Instagram to start receiving real customer messages. This inbox does not contain demo conversations.</p><Link href="/app/channels" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-[#235d51] px-3.5 py-2.5 text-xs font-bold text-[#f8f2e7]">Connect a channel <ArrowRight size={14} /></Link></div> :
      <div className="grid min-h-[620px] overflow-hidden rounded-2xl border border-[#e1dbce] bg-[#fbf9f3] shadow-[var(--shadow-card)] md:grid-cols-[290px_1fr]">
        <section className="border-b border-[#e5dfd4] md:border-b-0 md:border-r">
          <div className="border-b border-[#eee9df] p-4"><div className="relative"><Search size={15} className="absolute left-3 top-3 text-[#98a69f]" /><input data-testid="input-search-inbox" placeholder="Search conversations" className="focus-ring w-full rounded-xl border border-[#e2dcd1] bg-[#f5f2e9] py-2.5 pl-9 pr-3 text-xs outline-none placeholder:text-[#9aa69e]" /></div><div className="mt-3 flex gap-1 overflow-auto">{['All', 'WhatsApp', 'Instagram', 'open'].map((item) => <button data-testid={`button-filter-${item.toLowerCase()}`} key={item} onClick={() => setFilter(item === 'open' ? 'open' : item)} className={`whitespace-nowrap rounded-lg px-2.5 py-1.5 text-[10px] font-bold ${filter === item ? 'bg-[#d9e9d8] text-[#2f7055]' : 'text-[#899991]'}`}>{item === 'open' ? 'Open' : item}</button>)}</div></div>
          <div className="max-h-[545px] overflow-auto p-2">{filtered.map((conversation, index) => <button data-testid={`button-conversation-${conversation.id}`} key={conversation.id} onClick={() => setSelectedId(conversation.id)} className={`flex w-full items-start gap-3 rounded-xl p-3 text-left ${current?.id === conversation.id ? 'bg-[#e4f0e2]' : 'hover:bg-[#f0ede4]'}`}><Avatar initials={conversation.contactName.slice(0, 2).toUpperCase()} tone={index % 2 ? 'blue' : 'clay'} size="sm" /><div className="min-w-0 flex-1"><div className="flex items-center justify-between gap-2"><span className="truncate text-xs font-bold text-[#315f54]">{conversation.contactName}</span><span className="text-[10px] text-[#99a49e]">{new Date(conversation.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span></div><div className="mt-1 truncate text-[11px] text-[#87958e]">{conversation.messages.at(-1)?.text}</div><div className="mt-2 flex items-center gap-1.5"><ChannelMark channel={liveChannelMark(conversation.channel)} /><span className="text-[9px] font-bold text-[#8b9b92]">{conversation.handoff === 'team' ? 'Team handoff' : conversation.status}</span></div></div></button>)}</div>
        </section>
        {current && <section className="flex min-h-[550px] flex-col"><div className="flex items-center justify-between border-b border-[#eee9df] px-5 py-3.5"><div className="flex items-center gap-3"><Avatar initials={current.contactName.slice(0, 2).toUpperCase()} tone="clay" /><div><div className="flex items-center gap-2 text-sm font-bold text-[#28574d]">{current.contactName}<ChannelMark channel={liveChannelMark(current.channel)} /></div><div className="mt-0.5 text-[10px] text-[#92a098]">{current.contactAddress}</div></div></div><Button variant="secondary" onClick={handoff} disabled={busy}><Headphones size={14} />Hand off to team</Button></div><div className="flex-1 space-y-3 overflow-auto p-5">{current.messages.map((item) => <div key={item.id} className={`flex ${item.from === 'customer' ? 'justify-start' : 'justify-end'}`}><div className={`max-w-[78%] rounded-2xl px-3.5 py-2.5 text-xs leading-5 shadow-sm ${item.from === 'customer' ? 'rounded-bl-md border border-[#e4ded3] bg-[#fbf9f3] text-[#506961]' : 'rounded-br-md bg-[#d5ebd7] text-[#315f54]'}`}><div>{item.text}</div><div className="mt-1 text-[9px] opacity-70">{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}{item.deliveryStatus ? ` · ${item.deliveryStatus}` : ''}</div></div></div>)}</div><div className="border-t border-[#e6e0d5] p-4"><div className="flex items-end gap-2 rounded-xl border border-[#ddd8cc] bg-[#f7f4eb] p-1.5"><textarea data-testid="textarea-reply" value={message} onChange={(event) => setMessage(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); void send(); } }} rows={1} placeholder="Write a reply in English or العربية..." className="focus-ring min-h-9 flex-1 resize-none bg-transparent px-2 py-2 text-xs text-[#315f54] outline-none placeholder:text-[#99a69e]" /><button data-testid="button-send-reply" onClick={() => void send()} className="grid size-9 place-items-center rounded-lg bg-[#235d51] text-[#f8f2e7] disabled:opacity-40" disabled={!message.trim() || busy}><Send size={15} /></button></div><div className="mt-2 text-[9px] text-[#9aa59f]">Messages are sent only after the provider accepts them.</div></div></section>}
      </div>}
  </Shell>;
}

function LegacyRealChannelsPageV2() {
  const [channels, setChannels] = useState<LiveChannel[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [notice, setNotice] = useState<{ tone: 'error' | 'info'; text: string } | null>(null);

  const loadChannels = () => {
    setLoading(true);
    workspaceApi<{ channels: LiveChannel[] }>('/channels')
      .then(({ channels: next }) => setChannels(next))
      .catch((reason: Error) => setNotice({ tone: 'error', text: reason.message }))
      .finally(() => setLoading(false));
  };

  useEffect(() => { loadChannels(); }, []);

  const connect = async (channel: LiveChannel['channel']) => {
    setBusy(channel);
    setNotice(null);
    try {
      const result = await workspaceApi<{ channel: LiveChannel; connectUrl: string | null; message: string }>(
        `/channels/${channel}/connect`,
        { method: 'POST', body: JSON.stringify({}) },
      );
      setChannels((previous) => previous.map((item) => item.channel === channel ? result.channel : item));
      setNotice({ tone: 'info', text: result.message });
      if (result.connectUrl) window.location.assign(result.connectUrl);
    } catch (reason) {
      const payload = (reason as Error & { payload?: { channel?: LiveChannel } }).payload;
      if (payload?.channel) setChannels((previous) => previous.map((item) => item.channel === channel ? payload.channel! : item));
      setNotice({ tone: 'error', text: reason instanceof Error ? reason.message : 'Provider verification failed.' });
    } finally {
      setBusy(null);
    }
  };

  const disconnect = async (channel: LiveChannel['channel']) => {
    setBusy(channel);
    setNotice(null);
    try {
      await workspaceApi(`/channels/${channel}`, { method: 'DELETE' });
      loadChannels();
    } catch (reason) {
      setNotice({ tone: 'error', text: reason instanceof Error ? reason.message : 'The channel could not be disconnected.' });
    } finally {
      setBusy(null);
    }
  };

  return <SettingsLayout title="Channels" description="Connect WhatsApp Business and Instagram only after provider verification. Setup-required states are shown until real credentials pass Meta checks.">
    {notice && <div data-testid="channel-notice" className={`mb-5 flex items-start gap-2 rounded-xl border px-4 py-3 text-xs font-bold ${notice.tone === 'error' ? 'border-[#e9c5be] bg-[#fdf3f0] text-[#a25243]' : 'border-[#d9e6d6] bg-[#e8f2e4] text-[#39745a]'}`}><AlertCircle size={15} className="mt-0.5 shrink-0" />{notice.text}</div>}
    {loading ? <div className="rounded-2xl border border-dashed border-[#d7dfd5] bg-[#f3f7ee] p-10 text-center text-xs font-bold text-[#6e8579]">Checking provider state…</div> : <div className="grid gap-5 md:grid-cols-2">{channels.map((item) => { const isConnected = item.status === 'connected' && item.verified; const isFailed = item.status === 'failed'; return <div data-testid={`card-channel-${item.channel}`} key={item.channel} className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="flex items-start justify-between gap-3"><div className="flex items-center gap-3"><div className={`grid size-11 place-items-center rounded-xl ${item.channel === 'whatsapp' ? 'bg-[#d8f0dc] text-[#287550]' : 'bg-[#f6dbe8] text-[#a14472]'}`}>{item.channel === 'whatsapp' ? <MessageCircle size={22} /> : <Instagram size={22} />}</div><div><h2 className="font-display text-[17px] font-extrabold text-[#315f54]">{liveChannelLabel(item.channel)}</h2><p data-testid={`status-channel-${item.channel}`} className="mt-1 text-[11px] text-[#82938b]">{isConnected ? `Connected${item.displayName ? ` · ${item.displayName}` : ''}` : item.status === 'connecting' ? 'Authorization in progress' : item.status === 'failed' ? 'Verification failed' : item.status === 'disconnected' ? 'Disconnected' : 'Setup required'}</p></div></div><Badge tone={isConnected ? 'green' : isFailed ? 'red' : item.status === 'connecting' ? 'blue' : 'gold'}>{isConnected ? 'Verified' : item.status === 'connecting' ? 'Connecting' : isFailed ? 'Action needed' : 'Not ready'}</Badge></div><div className="mt-6 rounded-xl bg-[#f4f1e8] p-3 text-xs leading-5 text-[#71857b]"><div className="font-bold text-[#557269]">{item.health.message}</div>{item.health.action && <div className="mt-1">{item.health.action}</div>}</div>{isFailed && item.failureReason && <div className="mt-3 text-[11px] font-bold text-[#a25243]">{item.failureReason}</div>}<div className="mt-5 flex gap-2">{isConnected ? <Button variant="danger" onClick={() => void disconnect(item.channel)} disabled={busy === item.channel}>Disconnect</Button> : <Button onClick={() => void connect(item.channel)} disabled={busy === item.channel || item.status === 'connecting'}>{busy === item.channel ? 'Checking…' : isFailed ? 'Try again' : 'Connect'} <Link2 size={14} /></Button>}</div>{isConnected && <div className="mt-3 text-[10px] text-[#8a9a92]">Last verified {item.lastVerifiedAt ? new Date(item.lastVerifiedAt).toLocaleString() : 'recently'}</div>}</div>; })}</div>}
  </SettingsLayout>;
}

function InboxPage() {
  const { t } = useLanguage();
  const [conversations, setConversations] = useState<LiveConversation[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading');
  const load = useCallback(async () => {
    setState('loading');
    try {
      const result = await workspaceApi<{ conversations: LiveConversation[] }>('/conversations');
      setConversations(result.conversations);
      setSelected(result.conversations[0]?.id || null);
      setState('ready');
    } catch { setState('error'); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  const current = conversations.find((item) => item.id === selected) || conversations[0];
  const send = async () => {
    if (!current || !message.trim()) return;
    try {
      const result = await workspaceApi<{ conversation: LiveConversation }>(`/conversations/${current.id}/replies`, { method: 'POST', body: JSON.stringify({ text: message.trim() }) });
      setConversations((items) => items.map((item) => item.id === current.id ? result.conversation : item));
      setMessage('');
    } catch { setState('error'); }
  };
  return <Shell><PageHeading eyebrow="Shared inbox" title="Stay close to every conversation." description="Replies are sent through the verified channel that received the message." action={<Link href="/app/channels" className="rounded-xl border border-[#d9d4c8] px-3.5 py-2.5 text-xs font-bold text-[#28574d]">{t('Manage channels')}</Link>} />{state === 'loading' ? <div className="rounded-2xl border border-dashed p-10 text-center text-xs font-bold text-[#6e8579]">{t('Your inbox is loading.')}</div> : state === 'error' ? <div className="rounded-2xl border border-[#e9c5be] bg-[#fdf3f0] p-8 text-center"><AlertCircle className="mx-auto text-[#a25243]" /><p className="mt-3 text-xs font-bold text-[#a25243]">{t('Could not connect to the server.')}</p><Button className="mt-4" onClick={() => void load()}>{t('Retry')}</Button></div> : conversations.length === 0 ? <div className="rounded-2xl border border-dashed border-[#d7dfd5] bg-[#f3f7ee] p-10 text-center"><Inbox size={28} className="mx-auto text-[#7da189]" /><h2 className="mt-4 font-display text-lg font-extrabold text-[#315f54]">{t('No conversations yet')}</h2><p className="mx-auto mt-2 max-w-md text-xs leading-5 text-[#71857b]">{t('Connect and verify WhatsApp Business or Instagram to start receiving real customer messages. This inbox does not contain demo conversations.')}</p><Link href="/app/channels" className="mt-5 inline-flex rounded-xl bg-[#235d51] px-3.5 py-2.5 text-xs font-bold text-white">{t('Connect a channel')}</Link></div> : <div className="grid min-h-[620px] overflow-hidden rounded-2xl border border-[#e1dbce] bg-[#fbf9f3] md:grid-cols-[280px_1fr]"><aside className="border-e border-[#e5dfd4] p-2">{conversations.map((item) => <button key={item.id} onClick={() => setSelected(item.id)} className={`flex w-full items-center gap-3 rounded-xl p-3 text-start ${current?.id === item.id ? 'bg-[#e4f0e2]' : ''}`}><Avatar initials={item.contactName.slice(0, 2).toUpperCase()} size="sm" /><span className="truncate text-xs font-bold">{item.contactName}</span></button>)}</aside>{current && <section className="flex flex-col"><div className="border-b p-4 text-sm font-bold">{current.contactName}</div><div className="flex-1 space-y-3 overflow-auto p-5">{current.messages.map((item) => <div key={item.id} className={`flex ${item.from === 'customer' ? 'justify-start' : 'justify-end'}`}><div className="max-w-[80%] rounded-2xl bg-[#e8f2e4] px-3.5 py-2.5 text-xs">{item.text}</div></div>)}</div><div className="flex gap-2 border-t p-4"><textarea value={message} onChange={(event) => setMessage(event.target.value)} placeholder={t('Write a reply in English or العربية...')} className="min-h-11 flex-1 rounded-xl border bg-[#f7f4eb] p-3 text-xs" /><Button onClick={() => void send()} disabled={!message.trim()}><Send size={15} /></Button></div></section>}</div>}</Shell>;
}

function ChannelsPageV2() {
  const { t } = useLanguage();
  const [channels, setChannels] = useState<LiveChannel[]>([]);
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading');
  const [busy, setBusy] = useState('');
  const [notice, setNotice] = useState('');
  const [gupshupSetup, setGupshupSetup] = useState<{ embeddedSignupAvailable: boolean; state: string; message: string } | null>(null);
  const load = useCallback(async () => {
    setState('loading');
    try {
      const [result, setup] = await Promise.all([
        workspaceApi<{ channels: LiveChannel[] }>('/channels'),
        workspaceApi<{ gupshup: { embeddedSignupAvailable: boolean; state: string; message: string } }>('/channels/setup'),
      ]);
      setChannels(result.channels);
      setGupshupSetup(setup.gupshup);
      setState('ready');
    } catch { setState('error'); }
  }, []);
  useEffect(() => {
    const callbackStatus = new URLSearchParams(window.location.search).get('gupshup');
    if (callbackStatus === 'connected') setNotice('WhatsApp Business is connected.');
    if (callbackStatus === 'failed') setNotice('Gupshup could not verify the WhatsApp Business connection.');
    void load();
  }, [load]);
  const connect = async (channel: LiveChannel['channel']) => {
    setBusy(channel);
    setNotice('');
    try {
      const result = await workspaceApi<{ connectUrl: string | null; message: string }>(
        `/channels/${channel}/connect`,
        {
          method: 'POST',
          body: JSON.stringify({}),
        },
      );
      setNotice(result.message);
      if (result.connectUrl) window.location.assign(result.connectUrl);
      else await load();
    } catch (reason) {
      setNotice(reason instanceof Error ? reason.message : 'Unable to connect WhatsApp right now. Please try again later.');
    }
    finally { setBusy(''); }
  };
  const disconnect = async (channel: LiveChannel['channel']) => {
    setBusy(channel);
    try { await workspaceApi(`/channels/${channel}`, { method: 'DELETE' }); await load(); }
    catch { setState('error'); }
    finally { setBusy(''); }
  };
  return <SettingsLayout title="Channels" description="Connect WhatsApp Business through Gupshup. A channel is marked connected only after provider verification.">
    {notice && <div data-testid="channel-notice" className="mb-5 rounded-xl border border-[#d9e6d6] bg-[#e8f2e4] px-4 py-3 text-xs font-bold text-[#39745a]">{t(notice)}</div>}
    {state === 'loading' ? <div className="rounded-2xl border border-dashed p-10 text-center text-xs font-bold text-[#6e8579]">{t('Checking provider state…')}</div> : state === 'error' ? <div className="rounded-2xl border border-[#e9c5be] bg-[#fdf3f0] p-8 text-center"><AlertCircle className="mx-auto text-[#a25243]" /><p className="mt-3 text-xs font-bold text-[#a25243]">{t('Could not connect to the server.')}</p><Button className="mt-4" onClick={() => void load()}>{t('Retry')}</Button></div> : <div className="grid gap-5 md:grid-cols-2">{channels.map((item) => {
      const connected = item.status === 'connected' && item.verified;
      const status = connected ? 'Connected' : item.status === 'connecting' ? 'Connecting' : item.status === 'failed' ? 'Error' : item.status === 'paused' ? 'Paused' : 'Not connected';
      const isGupshup = item.channel === 'whatsapp' && item.provider === 'Gupshup';
      return <article data-testid={`card-channel-${item.channel}`} key={item.channel} className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3"><div className={`grid size-11 place-items-center rounded-xl ${item.channel === 'whatsapp' ? 'bg-[#d8f0dc] text-[#287550]' : 'bg-[#f6dbe8] text-[#a14472]'}`}>{item.channel === 'whatsapp' ? <MessageCircle size={22} /> : <Instagram size={22} />}</div><div><h2 className="font-display text-[17px] font-extrabold text-[#315f54]">{item.channel === 'whatsapp' ? 'WhatsApp Business' : 'Instagram'}</h2><p className="mt-1 text-[11px] text-[#82938b]">{item.provider}</p></div></div>
          <Badge tone={connected ? 'green' : item.status === 'failed' ? 'red' : 'gold'}>{t(status)}</Badge>
        </div>
        {isGupshup && !connected && <div className="mt-5 space-y-3 rounded-xl bg-[#f4f1e8] p-4">
          <div className="flex items-start gap-3"><BadgeCheck size={18} className="mt-0.5 shrink-0 text-[#39745a]" /><div><div className="text-xs font-extrabold text-[#45675b]">Gupshup Embedded Signup</div><p className="mt-1 text-[11px] leading-5 text-[#71857b]">{gupshupSetup?.message || 'Checking Embedded Signup availability…'}</p></div></div>
          {!gupshupSetup?.embeddedSignupAvailable && <p className="rounded-lg border border-[#ead8b8] bg-[#fff8e9] px-3 py-2 text-[10px] leading-4 text-[#8a682d]">A Gupshup Partner or Tech Provider account is required before customer onboarding can start. No connection will be shown until Gupshup verifies it.</p>}
        </div>}
        <div className="mt-5">{connected ? <Button variant="danger" onClick={() => void disconnect(item.channel)} disabled={busy === item.channel}>{t('Disconnect')}</Button> : <Button onClick={() => void connect(item.channel)} disabled={busy === item.channel || item.status === 'connecting' || (isGupshup && !gupshupSetup?.embeddedSignupAvailable)}>{busy === item.channel ? t('Checking…') : isGupshup ? 'Continue with Gupshup' : `${t('Connect')} Instagram`} <Link2 size={14} /></Button>}</div>
      </article>;
    })}</div>}
  </SettingsLayout>;
}

function TrainingPage() {
  const { t } = useLanguage();
  const auth = useAuth();
  const [setup, setSetup] = useState<WorkspaceSetup | null>(null);
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading');
  const [notice, setNotice] = useState('');
  const [faqForm, setFaqForm] = useState({ id: '', question: '', answer: '', category: 'General' });
  const [ruleForm, setRuleForm] = useState({ id: '', name: '', keywords: '', matchType: 'contains' as AutoReplyRule['matchType'], response: '' });
  const load = useCallback(async () => {
    setState('loading');
    try {
      setSetup(await apiRequest<WorkspaceSetup>('/workspace/setup'));
      setState('ready');
    } catch {
      setState('error');
    }
  }, []);
  useEffect(() => { void load(); }, [load]);
  const saveFaq = async (event: React.FormEvent) => {
    event.preventDefault();
    setNotice('');
    try {
      await apiRequest(`/workspace/faq${faqForm.id ? `/${faqForm.id}` : ''}`, {
        method: faqForm.id ? 'PATCH' : 'POST',
        body: JSON.stringify({ question: faqForm.question, answer: faqForm.answer, category: faqForm.category, priority: 0, enabled: true }),
      });
      setFaqForm({ id: '', question: '', answer: '', category: 'General' });
      setNotice('FAQ saved.');
      await Promise.all([load(), auth.refresh()]);
    } catch (reason) {
      setNotice(reason instanceof Error ? reason.message : 'Unable to save FAQ.');
    }
  };
  const saveRule = async (event: React.FormEvent) => {
    event.preventDefault();
    const keywords = ruleForm.keywords.split(',').map((item) => item.trim()).filter(Boolean);
    setNotice('');
    try {
      await apiRequest(`/workspace/auto-replies${ruleForm.id ? `/${ruleForm.id}` : ''}`, {
        method: ruleForm.id ? 'PATCH' : 'POST',
        body: JSON.stringify({ name: ruleForm.name, keywords, matchType: ruleForm.matchType, response: ruleForm.response, priority: 0, enabled: true }),
      });
      setRuleForm({ id: '', name: '', keywords: '', matchType: 'contains', response: '' });
      setNotice('Auto-reply saved.');
      await Promise.all([load(), auth.refresh()]);
    } catch (reason) {
      setNotice(reason instanceof Error ? reason.message : 'Unable to save auto-reply.');
    }
  };
  const remove = async (kind: 'faq' | 'auto-replies', id: string) => {
    setNotice('');
    try {
      await apiRequest(`/workspace/${kind}/${id}`, { method: 'DELETE' });
      await Promise.all([load(), auth.refresh()]);
    } catch (reason) {
      setNotice(reason instanceof Error ? reason.message : 'Unable to delete this item.');
    }
  };
  const editFaq = (item: FaqItem) => {
    setFaqForm({ id: item.id, question: item.question, answer: item.answer, category: item.category });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const editRule = (item: AutoReplyRule) => {
    setRuleForm({ id: item.id, name: item.name, keywords: item.keywords.join(', '), matchType: item.matchType, response: item.response });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  if (state === 'loading') return <Shell><div className="rounded-2xl border border-dashed p-10 text-center text-xs font-bold text-[#6e8579]">{t('Loading workspace settings…')}</div></Shell>;
  if (state === 'error' || !setup) return <Shell><div className="rounded-2xl border border-[#e9c5be] bg-[#fdf3f0] p-8 text-center"><AlertCircle className="mx-auto text-[#a25243]" /><p className="mt-3 text-xs font-bold text-[#a25243]">{t('Could not connect to the server.')}</p><Button className="mt-4" onClick={() => void load()}>{t('Retry')}</Button></div></Shell>;
  return <Shell>
    <PageHeading eyebrow="Automation" title="FAQ & auto-replies" description="Add the approved answers and keyword rules the assistant may send. Changes are saved to this workspace." />
    {notice && <div role="status" className="mb-5 rounded-xl border border-[#d9e6d6] bg-[#e8f2e4] px-4 py-3 text-xs font-bold text-[#39745a]">{t(notice)}</div>}
    <div className="grid gap-5 xl:grid-cols-2">
      <section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5">
        <div className="flex items-center gap-3"><div className="grid size-10 place-items-center rounded-xl bg-[#e8f2e4] text-[#39745a]"><CircleHelp size={18} /></div><div><h2 className="font-display text-lg font-extrabold text-[#315f54]">Frequently asked questions</h2><p className="text-[11px] text-[#82938b]">FAQ matches are checked before keyword rules.</p></div></div>
        <form onSubmit={saveFaq} className="mt-5 space-y-3">
          <input required aria-label="FAQ question" value={faqForm.question} onChange={(event) => setFaqForm((value) => ({ ...value, question: event.target.value }))} placeholder="Customer question" className="w-full rounded-xl border border-[#ddd8cc] bg-[#f7f4eb] px-3 py-3 text-xs" />
          <textarea required aria-label="FAQ answer" value={faqForm.answer} onChange={(event) => setFaqForm((value) => ({ ...value, answer: event.target.value }))} placeholder="Approved answer" className="min-h-28 w-full rounded-xl border border-[#ddd8cc] bg-[#f7f4eb] px-3 py-3 text-xs" />
          <div className="flex flex-col gap-3 sm:flex-row"><input required aria-label="FAQ category" value={faqForm.category} onChange={(event) => setFaqForm((value) => ({ ...value, category: event.target.value }))} placeholder="Category" className="min-w-0 flex-1 rounded-xl border border-[#ddd8cc] bg-[#f7f4eb] px-3 py-3 text-xs" /><Button type="submit"><Save size={14} />{faqForm.id ? 'Update FAQ' : 'Add FAQ'}</Button>{faqForm.id && <Button type="button" variant="secondary" onClick={() => setFaqForm({ id: '', question: '', answer: '', category: 'General' })}>Cancel</Button>}</div>
        </form>
        <div className="mt-6 space-y-3">{setup.faq.length === 0 ? <div className="rounded-xl border border-dashed p-6 text-center text-xs text-[#82938b]">No FAQs yet.</div> : setup.faq.map((item) => <article key={item.id} className="rounded-xl border border-[#e7e1d6] bg-[#f7f4eb] p-4"><div className="flex items-start justify-between gap-3"><div><div className="text-xs font-extrabold text-[#315f54]">{item.question}</div><p className="mt-2 text-xs leading-5 text-[#71857b]">{item.answer}</p><div className="mt-2 text-[10px] font-bold uppercase text-[#9a7a4f]">{item.category} · {item.enabled ? 'Enabled' : 'Disabled'}</div></div><div className="flex shrink-0 gap-1"><button aria-label="Edit FAQ" onClick={() => editFaq(item)} className="grid size-8 place-items-center rounded-lg text-[#6d8c7e] hover:bg-[#e5f0e3]"><Pencil size={14} /></button><button aria-label="Delete FAQ" onClick={() => void remove('faq', item.id)} className="grid size-8 place-items-center rounded-lg text-[#a25243] hover:bg-[#f7e2dc]"><Trash2 size={14} /></button></div></div></article>)}</div>
      </section>
      <section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5">
        <div className="flex items-center gap-3"><div className="grid size-10 place-items-center rounded-xl bg-[#f8eac5] text-[#8a6326]"><Zap size={18} /></div><div><h2 className="font-display text-lg font-extrabold text-[#315f54]">Automatic replies</h2><p className="text-[11px] text-[#82938b]">Trigger an approved response using customer keywords.</p></div></div>
        <form onSubmit={saveRule} className="mt-5 space-y-3">
          <input required aria-label="Rule name" value={ruleForm.name} onChange={(event) => setRuleForm((value) => ({ ...value, name: event.target.value }))} placeholder="Rule name" className="w-full rounded-xl border border-[#ddd8cc] bg-[#f7f4eb] px-3 py-3 text-xs" />
          <input required aria-label="Rule keywords" value={ruleForm.keywords} onChange={(event) => setRuleForm((value) => ({ ...value, keywords: event.target.value }))} placeholder="Keywords, separated by commas" className="w-full rounded-xl border border-[#ddd8cc] bg-[#f7f4eb] px-3 py-3 text-xs" />
          <select aria-label="Match type" value={ruleForm.matchType} onChange={(event) => setRuleForm((value) => ({ ...value, matchType: event.target.value as AutoReplyRule['matchType'] }))} className="w-full rounded-xl border border-[#ddd8cc] bg-[#f7f4eb] px-3 py-3 text-xs"><option value="contains">Contains</option><option value="exact">Exact match</option><option value="starts_with">Starts with</option></select>
          <textarea required aria-label="Rule response" value={ruleForm.response} onChange={(event) => setRuleForm((value) => ({ ...value, response: event.target.value }))} placeholder="Approved response" className="min-h-28 w-full rounded-xl border border-[#ddd8cc] bg-[#f7f4eb] px-3 py-3 text-xs" />
          <div className="flex flex-wrap gap-3"><Button type="submit"><Save size={14} />{ruleForm.id ? 'Update rule' : 'Add auto-reply'}</Button>{ruleForm.id && <Button type="button" variant="secondary" onClick={() => setRuleForm({ id: '', name: '', keywords: '', matchType: 'contains', response: '' })}>Cancel</Button>}</div>
        </form>
        <div className="mt-6 space-y-3">{setup.autoReplies.length === 0 ? <div className="rounded-xl border border-dashed p-6 text-center text-xs text-[#82938b]">No automatic replies yet.</div> : setup.autoReplies.map((item) => <article key={item.id} className="rounded-xl border border-[#e7e1d6] bg-[#f7f4eb] p-4"><div className="flex items-start justify-between gap-3"><div><div className="text-xs font-extrabold text-[#315f54]">{item.name}</div><div className="mt-1 text-[10px] font-bold text-[#9a7a4f]">{item.matchType} · {item.keywords.join(', ')}</div><p className="mt-2 text-xs leading-5 text-[#71857b]">{item.response}</p></div><div className="flex shrink-0 gap-1"><button aria-label="Edit auto-reply" onClick={() => editRule(item)} className="grid size-8 place-items-center rounded-lg text-[#6d8c7e] hover:bg-[#e5f0e3]"><Pencil size={14} /></button><button aria-label="Delete auto-reply" onClick={() => void remove('auto-replies', item.id)} className="grid size-8 place-items-center rounded-lg text-[#a25243] hover:bg-[#f7e2dc]"><Trash2 size={14} /></button></div></div></article>)}</div>
      </section>
    </div>
  </Shell>;
}

function ContactsPage() {
  return <ContactsPageV2 />;
  const [contacts, setContacts] = useState(contactsSeed);
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState('');
  const filtered = useMemo(() => contacts.filter(c => `${c.name} ${c.phone} ${c.segment}`.toLowerCase().includes(search.toLowerCase())), [contacts, search]);
  const addContact = () => { if (!name.trim()) return; setContacts([{ id: Date.now(), name, phone: 'Add phone number', source: 'Manual', lastSeen: 'Just now', segment: 'New contact', status: 'New' }, ...contacts]); setName(''); setShowAdd(false); };
  return <Shell><PageHeading eyebrow="People & relationships" title="Contacts" description="Every person who has reached Bayt Noor, with the context to make the next reply feel personal." action={<Button onClick={() => setShowAdd(!showAdd)}><Plus size={15} />Add contact</Button>} />{showAdd && <div className="page-enter mb-5 flex flex-wrap items-center gap-3 rounded-2xl border border-[#dce5d9] bg-[#e8f2e4] p-4"><input data-testid="input-new-contact" autoFocus value={name} onChange={e => setName(e.target.value)} onKeyDown={e => e.key === 'Enter' && addContact()} placeholder="Contact name" className="focus-ring flex-1 rounded-xl border border-[#d4e2d2] bg-[#fbf9f3] px-3 py-2.5 text-xs text-[#315f54] outline-none" /><Button onClick={addContact}>Save contact</Button><button data-testid="button-cancel-contact" onClick={() => setShowAdd(false)} className="text-xs font-bold text-[#748a80]">Cancel</button></div>}<div className="overflow-hidden rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] shadow-[var(--shadow-soft)]"><div className="flex flex-col gap-3 border-b border-[#eee9df] p-4 md:flex-row md:items-center md:justify-between"><div className="relative max-w-sm flex-1"><Search size={15} className="absolute left-3 top-3 text-[#98a69f]" /><input data-testid="input-search-contacts" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search name, phone or segment" className="focus-ring w-full rounded-xl border border-[#e2dcd1] bg-[#f5f2e9] py-2.5 pl-9 pr-3 text-xs outline-none placeholder:text-[#9aa69e]" /></div><div className="flex items-center gap-2"><button data-testid="button-contact-filter" className="flex items-center gap-2 rounded-xl border border-[#e2dcd1] px-3 py-2.5 text-xs font-bold text-[#61776d]"><ListFilter size={14} />All contacts<ChevronDown size={13} /></button><span className="text-[11px] text-[#9aa69e]">{filtered.length} contacts</span></div></div><div className="hidden grid-cols-[1.7fr_1.25fr_1fr_1fr_100px] gap-4 border-b border-[#eee9df] px-5 py-3 text-[10px] font-bold uppercase tracking-wider text-[#9da8a2] md:grid"><span>Contact</span><span>Source</span><span>Last seen</span><span>Segment</span><span>Status</span></div><div>{filtered.map((contact, i) => <div data-testid={`row-contact-${contact.id}`} key={contact.id} className="grid items-center gap-3 border-b border-[#f0ece4] px-4 py-4 transition hover:bg-[#f6f3ea] md:grid-cols-[1.7fr_1.25fr_1fr_1fr_100px] md:gap-4 md:px-5"><div className="flex min-w-0 items-center gap-3"><Avatar initials={contact.name.split(' ').map(n => n[0]).join('').slice(0, 2)} tone={i % 3 === 0 ? 'clay' : i % 3 === 1 ? 'blue' : 'green'} size="sm" /><div className="min-w-0"><div className="truncate text-xs font-bold text-[#315f54]">{contact.name}</div><div className="truncate text-[11px] text-[#92a098]">{contact.phone}</div></div></div><div className="flex items-center gap-2 text-xs text-[#667b71]"><ChannelMark channel={contact.source === 'Instagram' ? 'Instagram' : 'WhatsApp'} />{contact.source}</div><div className="text-xs text-[#788b82]">{contact.lastSeen}</div><div><Badge tone={contact.segment === 'High intent' ? 'gold' : 'neutral'}>{contact.segment}</Badge></div><div><Badge tone={contact.status === 'Lead' ? 'green' : contact.status === 'New' ? 'blue' : 'neutral'}>{contact.status}</Badge></div></div>)}</div></div></Shell>;
}

function LeadsPage() {
  const [stage, setStage] = useState('All');
  const stages = ['New', 'Contacted', 'Qualified', 'Proposal', 'Won'];
  const visible = leadsSeed.filter(l => stage === 'All' || l.stage === stage);
  return <Shell><PageHeading eyebrow="Pipeline" title="Leads worth following." description="A clear path from first message to meaningful work. Move opportunities forward without opening five tabs." action={<div className="flex gap-2"><Button variant="secondary"><Download size={15} />Export</Button><Button><Plus size={15} />Add lead</Button></div>} /><div className="mb-5 flex gap-2 overflow-auto pb-1">{['All', ...stages].map(s => <button data-testid={`button-leads-${s.toLowerCase()}`} key={s} onClick={() => setStage(s)} className={`whitespace-nowrap rounded-xl px-3.5 py-2 text-xs font-bold transition ${stage === s ? 'bg-[#235d51] text-[#f8f2e7]' : 'border border-[#e1dbcf] bg-[#fbf9f3] text-[#71847b] hover:bg-[#f0ede4]'}`}>{s}{s !== 'All' && <span className={`ml-2 rounded-full px-1.5 py-0.5 text-[10px] ${stage === s ? 'bg-[#b8e3c2] text-[#28574d]' : 'bg-[#eee9df]'}`}>{leadsSeed.filter(l => l.stage === s).length}</span>}</button>)}</div><div className="grid gap-4 xl:grid-cols-5">{stages.map((s, si) => <section key={s} className={`rounded-2xl border border-[#e3ddd2] bg-[#f7f4eb] p-3 ${stage !== 'All' && stage !== s ? 'hidden xl:block opacity-45' : ''}`}><div className="mb-3 flex items-center justify-between px-1"><div className="flex items-center gap-2"><span className={`size-2 rounded-full ${['bg-[#92b8a0]', 'bg-[#d9a35c]', 'bg-[#6da8b0]', 'bg-[#ae8dbb]', 'bg-[#6f9d76]'][si]}`} /><h2 className="text-xs font-extrabold text-[#45675b]">{s}</h2></div><span className="font-mono-custom text-[10px] text-[#a0aaa4]">{leadsSeed.filter(l => l.stage === s).length}</span></div><div className="space-y-2">{leadsSeed.filter(l => l.stage === s).map(lead => <div data-testid={`card-lead-${lead.id}`} key={lead.id} className="group rounded-xl border border-[#e6e0d5] bg-[#fbf9f3] p-3 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"><div className="flex items-start justify-between gap-2"><div className="flex min-w-0 items-center gap-2"><Avatar initials={lead.name.split(' ').map(n => n[0]).join('').slice(0, 2)} tone={si === 1 ? 'gold' : si === 3 ? 'plum' : 'green'} size="sm" /><span className="truncate text-xs font-bold text-[#315f54]">{lead.name}</span></div><button data-testid={`button-lead-menu-${lead.id}`} className="text-[#a5aea8] opacity-0 transition group-hover:opacity-100"><MoreHorizontal size={15} /></button></div><div className="mt-3 text-[11px] font-medium leading-4 text-[#70847a]">{lead.service}</div><div className="mt-3 flex items-center justify-between border-t border-[#eee9df] pt-2.5"><span className="font-mono-custom text-[11px] font-bold text-[#3c7560]">{formatAED(lead.value)}</span><ChannelMark channel={lead.source === 'Instagram' ? 'Instagram' : 'WhatsApp'} /></div></div>)}</div></section>)}</div></Shell>;
}

function AppointmentsPage() {
  const [appointments, setAppointments] = useState(appointmentsSeed);
  const [view, setView] = useState<'list' | 'calendar'>('list');
  const changeStatus = (id: number) => setAppointments(appointments.map(a => a.id === id ? { ...a, status: a.status === 'Confirmed' ? 'Completed' : 'Confirmed' } : a));
  return <Shell><PageHeading eyebrow="Bookings" title="Appointments" description="Keep the day moving. Every booking captured by FansConnect, ready for a human touch when it matters." action={<div className="flex gap-2"><div className="flex rounded-xl border border-[#dfd9cc] bg-[#fbf9f3] p-1"><button data-testid="button-appointments-list" onClick={() => setView('list')} className={`rounded-lg px-3 py-1.5 text-[11px] font-bold ${view === 'list' ? 'bg-[#e1eee0] text-[#2e7054]' : 'text-[#8a9991]'}`}>List</button><button data-testid="button-appointments-calendar" onClick={() => setView('calendar')} className={`rounded-lg px-3 py-1.5 text-[11px] font-bold ${view === 'calendar' ? 'bg-[#e1eee0] text-[#2e7054]' : 'text-[#8a9991]'}`}>Calendar</button></div><Button><Plus size={15} />New appointment</Button></div>} /><div className="mb-5 grid gap-4 md:grid-cols-3"><MetricCard label="This week" value="12" change="+3" detail="appointments booked" icon={CalendarDays} /><MetricCard label="Confirmed" value="9" change="75%" detail="of this week's bookings" icon={CheckCircle2} tone="blue" /><MetricCard label="Attributed value" value="18.4k" change="+16%" detail="AED · this week" icon={WalletCards} tone="gold" /></div>{view === 'calendar' ? <div className="grid-paper page-enter rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5"><div className="mb-5 flex items-center justify-between"><button data-testid="button-calendar-prev" className="grid size-8 place-items-center rounded-lg text-[#71877c] hover:bg-[#eee9df]"><ChevronLeft size={16} /></button><h2 className="font-display text-[17px] font-extrabold text-[#315f54]">This month</h2><button data-testid="button-calendar-next" className="grid size-8 place-items-center rounded-lg text-[#71877c] hover:bg-[#eee9df]"><ChevronRight size={16} /></button></div><div className="grid grid-cols-7 gap-px overflow-hidden rounded-xl border border-[#e4ded1] bg-[#e4ded1]">{['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => <div key={d} className="bg-[#f1eee5] p-3 text-center text-[10px] font-bold uppercase tracking-wider text-[#8e9c94]">{d}</div>)}{Array.from({ length: 35 }, (_, i) => { const num = i - 5; const dayAppt = num === 6 || num === 7 || num === 8; return <div key={i} className={`min-h-[90px] bg-[#fbf9f3] p-2 text-xs ${num === 4 ? 'ring-2 ring-inset ring-[#b8dcbf]' : ''}`}><span className={`${num === 4 ? 'grid size-6 place-items-center rounded-full bg-[#235d51] text-white' : 'text-[#71847b]'}`}>{num > 0 && num < 31 ? num : ''}</span>{dayAppt && <div className="mt-2 rounded-md bg-[#dcecdf] px-1.5 py-1 text-[9px] font-bold text-[#39745a]">1 booking</div>}</div>})}</div></div> : <div className="page-enter overflow-hidden rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] shadow-[var(--shadow-soft)]"><div className="flex items-center justify-between border-b border-[#eee9df] px-5 py-4"><div className="flex items-center gap-2 text-sm font-extrabold text-[#315f54]"><CalendarDays size={17} className="text-[#b66c43]" />Upcoming bookings</div><button data-testid="button-appointment-filter" className="flex items-center gap-2 text-xs font-bold text-[#84958c]"><SlidersHorizontal size={14} />Filter</button></div>{appointments.map((a, i) => <div data-testid={`row-appointment-detail-${a.id}`} key={a.id} className="flex flex-col gap-3 border-b border-[#f0ece4] px-5 py-4 transition hover:bg-[#f7f4eb] md:flex-row md:items-center"><div className="grid size-11 shrink-0 place-items-center rounded-xl bg-[#e5f0e3] text-[#3a765c]"><CalendarCheck2 size={19} /></div><div className="min-w-0 flex-1"><div className="flex items-center gap-2 text-sm font-bold text-[#315f54]">{a.client}<Badge tone={a.status === 'Confirmed' ? 'green' : a.status === 'Pending' ? 'gold' : 'blue'}>{a.status}</Badge></div><div className="mt-1 text-xs text-[#819189]">{a.service}</div></div><div className="flex items-center gap-6 text-right"><div><div className="text-xs font-bold text-[#46685d]">{a.date}</div><div className="mt-1 text-[11px] text-[#8e9c95]">{a.time}</div></div><div className="flex gap-1"><button data-testid={`button-appointment-complete-${a.id}`} onClick={() => changeStatus(a.id)} className="grid size-8 place-items-center rounded-lg text-[#6d8c7e] hover:bg-[#e3f0e3] hover:text-[#317457]" title="Update status">{a.status === 'Confirmed' ? <Check size={15} /> : <RotateCcw size={15} />}</button><button data-testid={`button-appointment-edit-${a.id}`} className="grid size-8 place-items-center rounded-lg text-[#9ba59f] hover:bg-[#eee9df]"><MoreHorizontal size={16} /></button></div></div></div>)}</div>}</Shell>;
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: () => void; label?: string }) {
  return <button data-testid={`button-toggle-${label?.toLowerCase().replaceAll(' ', '-') ?? 'setting'}`} onClick={onChange} className="flex items-center gap-2.5"><span className={`relative h-6 w-11 rounded-full p-1 transition-colors duration-200 ${checked ? 'bg-[#4f936d]' : 'bg-[#c5cec8]'}`}><span className={`block size-4 rounded-full bg-[#fbf9f3] shadow-sm transition-transform duration-200 ${checked ? 'translate-x-5' : ''}`} /></span>{label && <span className="text-xs font-bold text-[#537269]">{checked ? 'On' : 'Off'}</span>}</button>;
}

function BotSettingsPage() {
  const [settings, setSettings] = useState({ enabled: true, name: 'Saha', greeting: 'Marhaba! Welcome to Bayt Noor Studio. How can we make your day more beautiful?', tone: 'Warm & clear', language: 'English + العربية' });
  const set = (key: keyof typeof settings, value: string | boolean) => setSettings({ ...settings, [key]: value });
  return <Shell><PageHeading eyebrow="Automation" title="Your AI assistant" description="Shape how Saha speaks for your business. Calm, capable, and always clear about when to bring you in." action={<div className="flex items-center gap-3 rounded-xl border border-[#dce5d9] bg-[#e8f2e4] px-3 py-2"><span className="text-xs font-bold text-[#3a755b]">Assistant is live</span><Toggle checked={settings.enabled} onChange={() => set('enabled', !settings.enabled)} /></div>} /><div className="grid gap-5 xl:grid-cols-[1fr_360px]"><div className="space-y-5"><section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="mb-5 flex items-center gap-3"><div className="grid size-10 place-items-center rounded-xl bg-[#dcecdf] text-[#2b6a56]"><Bot size={19} /></div><div><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">Assistant identity</h2><p className="text-[11px] text-[#8b9a93]">The little details that make replies feel like you.</p></div></div><div className="grid gap-5 md:grid-cols-2"><label className="block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#889890]">Assistant name</span><input data-testid="input-bot-name" value={settings.name} onChange={e => set('name', e.target.value)} className="focus-ring w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3.5 py-3 text-sm font-bold text-[#315f54] outline-none" /></label><label className="block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#889890]">Tone</span><select data-testid="select-bot-tone" value={settings.tone} onChange={e => set('tone', e.target.value)} className="focus-ring w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3.5 py-3 text-sm font-bold text-[#315f54] outline-none"><option>Warm & clear</option><option>Polished & concise</option><option>Friendly & playful</option></select></label></div><label className="mt-5 block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#889890]">Default language</span><div className="flex gap-2">{['English + العربية', 'English only', 'العربية only'].map(lang => <button data-testid={`button-language-${lang}`} key={lang} onClick={() => set('language', lang)} className={`flex items-center gap-2 rounded-xl border px-3.5 py-2.5 text-xs font-bold transition ${settings.language === lang ? 'border-[#8dbb96] bg-[#e2f0e1] text-[#317457]' : 'border-[#e2dcd1] bg-[#f7f4eb] text-[#819189]'}`}><Languages size={14} />{lang}</button>)}</div></label></section><section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="mb-4 flex items-start justify-between"><div><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">First greeting</h2><p className="mt-1 text-[11px] text-[#8b9a93]">Sent when someone starts a conversation.</p></div><Badge tone="blue">Preview live</Badge></div><textarea data-testid="textarea-bot-greeting" value={settings.greeting} onChange={e => set('greeting', e.target.value)} rows={4} className="focus-ring w-full resize-none rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] p-3.5 text-sm leading-6 text-[#4c6c61] outline-none" /><div className="mt-3 flex items-center justify-between"><span className="text-[10px] text-[#9aa69e]">Use a greeting that sounds like your studio.</span><Button variant="secondary" onClick={() => set('greeting', 'Marhaba! Welcome to Bayt Noor Studio. How can we make your day more beautiful?')}><RotateCcw size={13} />Reset</Button></div></section></div><aside className="h-fit rounded-2xl border border-[#dce5d9] bg-[#e8f2e4] p-5"><div className="mb-4 flex items-center justify-between"><span className="text-[10px] font-bold uppercase tracking-[.15em] text-[#638875]">Conversation preview</span><span className="size-2 rounded-full bg-[#4f936d]" /></div><div className="overflow-hidden rounded-2xl border border-[#d5e4d2] bg-[#f7f4eb]"><div className="flex items-center gap-2 border-b border-[#e6e0d5] bg-[#fbf9f3] px-3 py-3"><Avatar initials="BN" tone="gold" size="sm" /><div><div className="text-xs font-bold text-[#315f54]">Bayt Noor Studio</div><div className="text-[9px] text-[#8e9d95]">Typically replies instantly</div></div></div><div className="space-y-3 p-3"><div className="flex justify-start"><div className="rounded-xl rounded-bl-sm bg-[#e8e4da] px-3 py-2 text-[11px] text-[#60766c]">Hello, I need help choosing a package.</div></div><div className="flex justify-end"><div className="max-w-[90%] rounded-xl rounded-br-sm bg-[#d5ebd7] px-3 py-2 text-[11px] leading-4 text-[#315f54]">{settings.greeting}</div></div></div><div className="border-t border-[#e6e0d5] px-3 py-2 text-[9px] text-[#9ba7a0]">Powered by SahaAI</div></div><div className="mt-5 space-y-3 border-t border-[#d2e1d0] pt-4"><div className="flex items-center justify-between text-xs"><span className="text-[#718c7e]">Replies this month</span><span className="font-mono-custom font-bold text-[#39745a]">486</span></div><div className="flex items-center justify-between text-xs"><span className="text-[#718c7e]">Human handoffs</span><span className="font-mono-custom font-bold text-[#39745a]">28</span></div></div></aside></div></Shell>;
}

function FlowsPage() {
  const [active, setActive] = useState('New enquiry');
  const [nodes, setNodes] = useState(['Welcome message', 'Understand intent', 'Share package options', 'Offer a booking']);
  const addNode = () => setNodes([...nodes, 'New action']);
  return <Shell><PageHeading eyebrow="Automation" title="Flows that feel human." description="Map the moments Saha handles beautifully, then leave space for your expertise." action={<Button onClick={addNode}><Plus size={15} />Add step</Button>} /><div className="grid gap-5 xl:grid-cols-[260px_1fr]"><aside className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-3 shadow-[var(--shadow-soft)]"><div className="mb-3 flex items-center justify-between px-2"><span className="text-[10px] font-bold uppercase tracking-[.16em] text-[#9aa59f]">Your flows</span><button data-testid="button-new-flow" className="grid size-7 place-items-center rounded-lg bg-[#e8f2e4] text-[#3a765b] hover:bg-[#d8e9d6]"><Plus size={15} /></button></div>{['New enquiry', 'Appointment booking', 'Product questions', 'Aftercare follow-up'].map((flow, i) => <button data-testid={`button-flow-${i}`} key={flow} onClick={() => setActive(flow)} className={`flex w-full items-center gap-3 rounded-xl p-3 text-left transition ${active === flow ? 'bg-[#e3f0e1] text-[#315f54]' : 'text-[#788c83] hover:bg-[#f1eee6]'}`}><span className={`grid size-7 place-items-center rounded-lg ${active === flow ? 'bg-[#cbe3cc] text-[#39745a]' : 'bg-[#f0ede4] text-[#98a49e]'}`}>{i === 0 ? <Sparkles size={14} /> : i === 1 ? <CalendarCheck2 size={14} /> : i === 2 ? <Tag size={14} /> : <RotateCcw size={14} />}</span><span className="flex-1 text-xs font-bold">{flow}</span>{i < 2 && <span className="size-1.5 rounded-full bg-[#6da883]" />}</button>)}<div className="mt-5 rounded-xl bg-[#f1eee5] p-3 text-[10px] leading-4 text-[#82928a]">Flows run on WhatsApp and Instagram. Saha pauses when you reply.</div></aside><section className="grid-paper min-h-[630px] rounded-2xl border border-[#e3ddd2] bg-[#f5f2e9] p-5 shadow-[var(--shadow-soft)] md:p-8"><div className="mb-6 flex flex-col justify-between gap-3 md:flex-row md:items-center"><div><div className="flex items-center gap-2"><h2 className="font-display text-[20px] font-extrabold tracking-[-.04em] text-[#315f54]">{active}</h2><Badge tone="green">Active</Badge></div><p className="mt-1 text-[11px] text-[#879890]">Triggered when a new conversation starts</p></div><div className="flex gap-2"><Button variant="secondary"><Eye size={14} />Test flow</Button><Button><Save size={14} />Save changes</Button></div></div><div className="mx-auto flex max-w-[620px] flex-col items-center">{nodes.map((node, i) => <div key={`${node}-${i}`} className="flex w-full flex-col items-center"><div data-testid={`card-flow-node-${i}`} className={`group relative flex w-full max-w-[430px] items-center gap-3 rounded-2xl border bg-[#fbf9f3] p-4 shadow-[0_4px_16px_rgba(42,79,66,.06)] transition hover:-translate-y-0.5 ${i === 0 ? 'border-[#9cc39f]' : 'border-[#e2dcd1]'}`}><div className={`grid size-9 place-items-center rounded-xl ${i === 0 ? 'bg-[#dcecdf] text-[#3e805f]' : i === nodes.length - 1 ? 'bg-[#f6e5c7] text-[#9b6e2e]' : 'bg-[#e8e4da] text-[#70867b]'}`}>{i === 0 ? <MessageCircle size={16} /> : i === nodes.length - 1 ? <CalendarCheck2 size={16} /> : <BotMessageSquare size={16} />}</div><div className="min-w-0 flex-1"><div className="text-xs font-extrabold text-[#315f54]">{node}</div><div className="mt-1 text-[10px] text-[#8b9b92]">{i === 0 ? 'Send a warm welcome in the contact language' : i === 1 ? 'Saha identifies what they need' : i === nodes.length - 1 ? 'Suggest available times' : 'Share relevant information'}</div></div><button data-testid={`button-edit-node-${i}`} onClick={() => setNodes(nodes.map((n, j) => j === i ? `${n} · edited` : n))} className="grid size-7 place-items-center rounded-lg text-[#9ba8a0] opacity-0 transition group-hover:opacity-100 hover:bg-[#eee9df] hover:text-[#39745a]"><Pencil size={13} /></button></div>{i < nodes.length - 1 && <div className="flex h-10 flex-col items-center"><div className="h-6 w-px bg-[#b8c9bd]" /><ChevronDown size={15} className="text-[#789486]" /></div>}</div>)}<button data-testid="button-flow-add-step" onClick={addNode} className="mt-4 flex items-center gap-2 rounded-xl border border-dashed border-[#a9c1b0] px-4 py-2.5 text-xs font-bold text-[#5c8970] transition hover:border-[#5a946d] hover:bg-[#e6f0e3]"><Plus size={14} />Add another step</button></div></section></div></Shell>;
}

function AnalyticsPage() {
  return <AnalyticsPageV2 />;
  const [period, setPeriod] = useState('Last 7 days');
  return <Shell><PageHeading eyebrow="Signals & learning" title="Analytics" description="Know what is working, where people pause, and which conversations are becoming real business." action={<div className="flex gap-2"><select data-testid="select-analytics-period" value={period} onChange={e => setPeriod(e.target.value)} className="rounded-xl border border-[#dfd9cc] bg-[#fbf9f3] px-3 py-2.5 text-xs font-bold text-[#48665b]"><option>Last 7 days</option><option>Last 30 days</option><option>This quarter</option></select><Button variant="secondary"><Download size={14} />Download</Button></div>} /><div className="grid gap-4 md:grid-cols-4"><MetricCard label="Total conversations" value="486" change="+18.4%" detail="across both channels" icon={MessageSquareText} /><MetricCard label="Resolution rate" value="74.2%" change="+6.8%" detail="without human handoff" icon={CheckCircle2} tone="blue" /><MetricCard label="Lead conversion" value="18.6%" change="+3.2%" detail="conversation to lead" icon={TrendingUp} tone="gold" /><MetricCard label="Avg. response time" value="42s" change="-18.1%" detail="faster than last period" icon={Clock3} /></div><div className="mt-5 grid gap-5 xl:grid-cols-[1.5fr_1fr]"><section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="mb-6 flex items-center justify-between"><div><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">Conversation activity</h2><p className="mt-1 text-[11px] text-[#8a9a92]">Incoming vs. resolved · {period.toLowerCase()}</p></div><div className="flex gap-3 text-[10px] font-bold text-[#819189]"><span className="flex items-center gap-1.5"><i className="size-2 rounded-full bg-[#5d9e77]" />Incoming</span><span className="flex items-center gap-1.5"><i className="size-2 rounded-full bg-[#e4bd76]" />Resolved</span></div></div><div className="flex h-[245px] items-end gap-2 border-b border-[#e8e2d7] px-2">{[44, 61, 53, 80, 68, 91, 74].map((v, i) => <div key={i} className="group flex flex-1 items-end gap-1"><div style={{ height: `${v}%` }} className="flex-1 rounded-t-md bg-[#c5e1c9] transition group-hover:bg-[#6da883]" /><div style={{ height: `${v * .72}%` }} className="flex-1 rounded-t-md bg-[#f0d39b] transition group-hover:bg-[#d7a54f]" /></div>)}</div><div className="mt-3 flex justify-between px-1 text-[10px] text-[#9ba69f]"><span>28 May</span><span>29 May</span><span>30 May</span><span>31 May</span><span>01 Jun</span><span>02 Jun</span><span>03 Jun</span></div></section><section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="mb-5 flex items-center justify-between"><div><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">Where people come from</h2><p className="mt-1 text-[11px] text-[#8a9a92]">Channel mix this period</p></div><Globe2 size={17} className="text-[#8ba397]" /></div><div className="space-y-5"><div><div className="mb-2 flex justify-between text-xs font-bold text-[#55736a]"><span className="flex items-center gap-2"><ChannelMark channel="WhatsApp" />WhatsApp</span><span>62%</span></div><div className="h-2 overflow-hidden rounded-full bg-[#edf0e9]"><div className="h-full w-[62%] rounded-full bg-[#5d9e77]" /></div></div><div><div className="mb-2 flex justify-between text-xs font-bold text-[#55736a]"><span className="flex items-center gap-2"><ChannelMark channel="Instagram" />Instagram</span><span>38%</span></div><div className="h-2 overflow-hidden rounded-full bg-[#edf0e9]"><div className="h-full w-[38%] rounded-full bg-[#d79b71]" /></div></div></div><div className="mt-7 rounded-xl bg-[#f1eee5] p-3.5"><div className="flex items-center gap-2 text-[11px] font-bold text-[#55736a]"><Sparkles size={14} className="text-[#b66c43]" />A useful signal</div><p className="mt-2 text-[11px] leading-5 text-[#83948b]">Instagram conversations convert 1.6× better when Saha shares a visual catalogue in the first reply.</p></div></section></div><section className="mt-5 rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5"><div className="mb-4 flex items-center justify-between"><div><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">Top intents</h2><p className="mt-1 text-[11px] text-[#8a9a92]">What your customers are trying to do</p></div><Link data-testid="link-analytics-inbox" href="/app/inbox" className="text-[11px] font-bold text-[#b66c43]">Review conversations <ArrowUpRight size={13} className="inline" /></Link></div><div className="grid gap-3 md:grid-cols-4">{[['Book an appointment', '34%', 'bg-[#c6e2ca]'], ['Pricing & packages', '27%', 'bg-[#f1d6aa]'], ['Product availability', '22%', 'bg-[#d8e7e8]'], ['Care instructions', '17%', 'bg-[#e4d9e8]']].map(([label, value, color]) => <div data-testid={`card-intent-${label}`} key={label} className="rounded-xl border border-[#eee9df] p-3"><div className="mb-3 flex items-center justify-between"><span className={`size-2.5 rounded-full ${color}`} /><span className="font-mono-custom text-[11px] font-bold text-[#5f796e]">{value}</span></div><div className="text-xs font-bold text-[#567268]">{label}</div></div>)}</div></section></Shell>;
}

function SettingsLayout({ title, description, children, action }: { title: string; description: string; children: React.ReactNode; action?: React.ReactNode }) {
  return <Shell><PageHeading eyebrow="Workspace settings" title={title} description={description} action={action} /><div className="max-w-4xl">{children}</div></Shell>;
}

function BusinessSettingsPage() {
  const [saved, setSaved] = useState(false);
  const [hours, setHours] = useState(true);
  return <SettingsLayout title="Business profile" description="The details Saha uses to answer with confidence and represent Bayt Noor accurately." action={<Button onClick={() => setSaved(true)}>{saved ? <Check size={15} /> : <Save size={15} />}{saved ? 'Saved' : 'Save changes'}</Button>}><div className="space-y-5"><section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="mb-5 flex items-center gap-3"><div className="grid size-10 place-items-center rounded-xl bg-[#f4e4c6] text-[#98692c]"><Store size={18} /></div><div><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">About your business</h2><p className="text-[11px] text-[#8c9b94]">Visible in your workspace and assistant replies.</p></div></div><div className="grid gap-5 md:grid-cols-2"><label><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#889890]">Business name</span><input data-testid="input-business-name" defaultValue="Bayt Noor Studio" className="focus-ring w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3.5 py-3 text-sm font-bold text-[#315f54] outline-none" /></label><label><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#889890]">Industry</span><select data-testid="select-business-industry" defaultValue="Interior styling" className="focus-ring w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3.5 py-3 text-sm font-bold text-[#315f54] outline-none"><option>Interior styling</option><option>Beauty & wellness</option><option>Retail</option><option>Hospitality</option></select></label><label className="md:col-span-2"><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#889890]">Location</span><div className="relative"><MapPin size={15} className="absolute left-3 top-3.5 text-[#9aa69e]" /><input data-testid="input-business-location" defaultValue="King Abdullah Financial District, Riyadh" className="focus-ring w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] py-3 pl-9 pr-3.5 text-sm font-bold text-[#315f54] outline-none" /></div></label></div></section><section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="mb-5 flex items-center justify-between"><div><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">Operating hours</h2><p className="mt-1 text-[11px] text-[#8c9b94]">Saha will set expectations outside these hours.</p></div><Toggle checked={hours} onChange={() => setHours(!hours)} label="Open" /></div><div className="space-y-2">{['Sunday – Thursday', 'Friday', 'Saturday'].map((day, i) => <div key={day} className="flex items-center justify-between rounded-xl bg-[#f4f1e8] px-3.5 py-3"><span className="text-xs font-bold text-[#557269]">{day}</span><div className="flex items-center gap-2"><span className="rounded-lg border border-[#dfd9cd] bg-[#fbf9f3] px-3 py-2 text-[11px] font-bold text-[#627970]">{i === 1 ? 'Closed' : '09:00 AM'}</span>{i !== 1 && <><span className="text-[10px] text-[#a0aaa4]">to</span><span className="rounded-lg border border-[#dfd9cd] bg-[#fbf9f3] px-3 py-2 text-[11px] font-bold text-[#627970]">06:00 PM</span></>}</div></div>)}</div></section>{saved && <div className="page-enter flex items-center gap-2 rounded-xl bg-[#e5f1e3] px-4 py-3 text-xs font-bold text-[#39745a]"><CheckCircle2 size={15} />Your business details are up to date.</div>}</div></SettingsLayout>;
}

function WhatsAppSettingsPage() {
  const [connected, setConnected] = useState(true);
  return <SettingsLayout title="Channels" description="Keep WhatsApp and Instagram connected so every conversation arrives in one calm place."><div className="space-y-5"><section className="rounded-2xl border border-[#b9d8bd] bg-[#e8f2e4] p-5"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-center"><div className="flex items-center gap-3"><div className="grid size-11 place-items-center rounded-xl bg-[#c8e4cb] text-[#2d7655]"><MessageCircle size={22} /></div><div><div className="flex items-center gap-2"><h2 className="font-display text-[17px] font-extrabold text-[#28574d]">WhatsApp Business</h2><Badge tone="green">{connected ? 'Connected' : 'Paused'}</Badge></div><p className="mt-1 text-[11px] text-[#648476]">Bayt Noor Studio · +966 11 245 8090</p></div></div><Button variant={connected ? 'secondary' : 'primary'} onClick={() => setConnected(!connected)}>{connected ? <Pause size={14} /> : <Play size={14} />}{connected ? 'Pause channel' : 'Reconnect channel'}</Button></div><div className="mt-5 grid gap-3 border-t border-[#d1e4d0] pt-4 md:grid-cols-3"><div><div className="text-[10px] font-bold uppercase tracking-wider text-[#759286]">Connected since</div><div className="mt-1 text-xs font-bold text-[#3d735b]">12 February 2024</div></div><div><div className="text-[10px] font-bold uppercase tracking-wider text-[#759286]">Messages this month</div><div className="mt-1 font-mono-custom text-xs font-bold text-[#3d735b]">1,248</div></div><div><div className="text-[10px] font-bold uppercase tracking-wider text-[#759286]">Health</div><div className="mt-1 flex items-center gap-1 text-xs font-bold text-[#3d735b]"><span className="size-1.5 rounded-full bg-[#4f936d]" />Excellent</div></div></div></section><section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="mb-5 flex items-center gap-3"><div className="grid size-10 place-items-center rounded-xl bg-[#f6dbe8] text-[#a14472]"><Instagram size={19} /></div><div><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">Instagram direct</h2><p className="text-[11px] text-[#8c9b94]">Bring replies from your inbox into the same view.</p></div><Badge tone="blue">Connected</Badge></div><div className="flex items-center justify-between rounded-xl border border-[#eee9df] bg-[#f5f2e9] p-3.5"><div className="flex items-center gap-3"><Avatar initials="BN" tone="clay" size="sm" /><div><div className="text-xs font-bold text-[#557269]">@baytnoor.studio</div><div className="mt-0.5 text-[10px] text-[#91a098]">Business account</div></div></div><button data-testid="button-instagram-manage" className="text-xs font-bold text-[#b66c43] hover:text-[#8f4f31]">Manage</button></div></section><div className="flex gap-3 rounded-xl border border-[#e8dfcf] bg-[#fbf5e8] p-4 text-xs text-[#806f52]"><AlertCircle size={16} className="mt-0.5 shrink-0 text-[#bc8651]" /><p><span className="font-bold">A note about handoffs.</span> When Saha pauses, new messages still arrive here. They simply wait for you to take the lead.</p></div></div></SettingsLayout>;
}

function BillingPage() {
  const [selected, setSelected] = useState('Studio');
  const plans = [{ name: 'Solo', price: '149', desc: 'For a focused inbox', features: ['1 channel', '500 conversations', 'Basic assistant'] }, { name: 'Studio', price: '349', desc: 'For teams that move fast', features: ['WhatsApp + Instagram', '2,500 conversations', 'Advanced flows', 'Analytics & lead pipeline'] }, { name: 'House', price: '699', desc: 'For growing operations', features: ['Everything in Studio', 'Unlimited team members', 'Priority support'] }];
  return <SettingsLayout title="Plan & billing" description="Simple plans for businesses building relationships at their own pace. You are currently on Studio." action={<Button variant="secondary"><Download size={14} />Download invoices</Button>}><div className="mb-5 rounded-2xl border border-[#b9d8bd] bg-[#e8f2e4] p-5"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-center"><div><div className="flex items-center gap-2"><Badge tone="green">Current plan</Badge><span className="font-display text-[18px] font-extrabold text-[#28574d]">Studio</span></div><p className="mt-2 text-xs text-[#688677]">Your next renewal is 12 June 2024 · Visa ending 4242</p></div><div className="text-left md:text-right"><div className="font-mono-custom text-[21px] font-bold text-[#28574d]">SAR 349</div><div className="text-[10px] text-[#7a9486]">per month</div></div></div></div><div className="grid gap-4 lg:grid-cols-3">{plans.map((plan, i) => <button data-testid={`button-plan-${plan.name.toLowerCase()}`} key={plan.name} onClick={() => setSelected(plan.name)} className={`relative text-left rounded-2xl border p-5 transition-all ${selected === plan.name ? 'border-[#70a77e] bg-[#eef5e9] shadow-[0_6px_22px_rgba(54,113,80,.1)]' : 'border-[#e3ddd2] bg-[#fbf9f3] hover:border-[#b5cbb8]'}`}>{i === 1 && <span className="absolute -top-3 left-5 rounded-full bg-[#cc7c4c] px-2.5 py-1 text-[9px] font-bold uppercase tracking-wider text-white">Most chosen</span>}<div className="flex items-start justify-between"><div><div className="font-display text-[17px] font-extrabold text-[#315f54]">{plan.name}</div><div className="mt-1 text-[11px] text-[#82938b]">{plan.desc}</div></div><span className={`grid size-5 place-items-center rounded-full border-2 ${selected === plan.name ? 'border-[#4f936d] bg-[#4f936d] text-white' : 'border-[#cbd5cc]'}`}>{selected === plan.name && <Check size={12} />}</span></div><div className="my-5 font-mono-custom text-[25px] font-bold tracking-[-.05em] text-[#28574d]">SAR {plan.price}<span className="font-sans text-xs font-medium tracking-normal text-[#83938b]"> / month</span></div><div className="space-y-2 border-t border-[#e6e0d5] pt-4">{plan.features.map(f => <div key={f} className="flex items-center gap-2 text-xs text-[#61796f]"><Check size={14} className="text-[#4f936d]" />{f}</div>)}</div>{selected === plan.name && <div className="mt-5 rounded-lg bg-[#d5e9d3] py-2 text-center text-[11px] font-bold text-[#39745a]">{plan.name === 'Studio' ? 'Your active plan' : 'Switch to this plan'}</div>}</button>)}</div><div className="mt-5 rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5"><div className="flex items-center justify-between"><div><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">Billing history</h2><p className="mt-1 text-[11px] text-[#8c9b94]">Your latest SahaAI invoices</p></div><CreditCard size={18} className="text-[#91a29a]" /></div><div className="mt-4 divide-y divide-[#eee9df]">{['12 May 2024', '12 Apr 2024', '12 Mar 2024'].map((date, i) => <div key={date} className="flex items-center justify-between py-3 text-xs"><span className="font-bold text-[#59756a]">SahaAI Studio · {date}</span><span className="font-mono-custom text-[#6f877d]">SAR 349.00</span><button data-testid={`button-download-invoice-${i}`} className="text-[#b66c43]"><Download size={14} /></button></div>)}</div></div></SettingsLayout>;
}

function LegacyAuthPage({ register = false }: { register?: boolean }) {
  const [, setLocation] = useLocation();
  const [showPassword, setShowPassword] = useState(false);
  return <div className="grain flex min-h-[100dvh] bg-[#f6f2e8]"><div className="hidden w-[47%] flex-col justify-between bg-[#173f36] p-10 text-[#f1eadc] lg:flex"><Brand dark /><div className="max-w-md"><div className="mb-5 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.2em] text-[#9ec4b0]"><span className="size-2 rounded-full bg-[#b8e3c2]" />A calmer way to care</div><h1 className="font-display text-[54px] font-extrabold leading-[.98] tracking-[-.07em]">Keep the thread.<br /><span className="text-[#b8e3c2]">Grow the trust.</span></h1><p className="mt-6 max-w-sm text-[15px] leading-7 text-[#b3cdbf]">SahaAI gives small Gulf businesses the space to follow every conversation from first hello to lasting relationship.</p><div className="mt-10 flex items-center gap-3 text-xs text-[#9fbcaf]"><div className="flex -space-x-2"><Avatar initials="AA" tone="clay" size="sm" /><Avatar initials="MS" tone="blue" size="sm" /><Avatar initials="OK" tone="gold" size="sm" /></div><span>Loved by 240+ thoughtful teams</span></div></div><div className="flex items-center justify-between text-[10px] text-[#789e8e]"><span>Made for businesses across the Gulf</span><span>English · العربية</span></div></div><div className="flex flex-1 flex-col px-6 py-8 md:px-16 lg:px-20"><div className="lg:hidden"><Brand /></div><div className="mx-auto flex w-full max-w-[410px] flex-1 flex-col justify-center"><div className="mb-8 mt-10 lg:mt-0"><div className="mb-3 text-[10px] font-bold uppercase tracking-[.18em] text-[#b66c43]">{register ? 'Start your workspace' : 'Welcome back'}</div><h2 className="font-display text-[32px] font-extrabold tracking-[-.06em] text-[#1b4a3f]">{register ? 'A better inbox starts here.' : 'Good to see you again.'}</h2><p className="mt-2 text-sm text-[#7e9087]">{register ? 'Set up your studio in a few minutes. No credit card needed.' : 'Sign in to pick up exactly where your customers left you.'}</p></div><form onSubmit={e => { e.preventDefault(); setLocation('/app'); }} className="space-y-4"><label className="block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#879890]">Work email</span><input data-testid="input-auth-email" required type="email" placeholder="you@yourbusiness.com" className="focus-ring w-full rounded-xl border border-[#ded8cb] bg-[#fbf9f3] px-3.5 py-3.5 text-sm text-[#315f54] outline-none placeholder:text-[#abb3ae]" /></label>{register && <label className="block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#879890]">Business name</span><input data-testid="input-auth-business" required placeholder="Your studio or business" className="focus-ring w-full rounded-xl border border-[#ded8cb] bg-[#fbf9f3] px-3.5 py-3.5 text-sm text-[#315f54] outline-none placeholder:text-[#abb3ae]" /></label>}<label className="block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#879890]">Password</span><div className="relative"><input data-testid="input-auth-password" required type={showPassword ? 'text' : 'password'} placeholder="At least 8 characters" className="focus-ring w-full rounded-xl border border-[#ded8cb] bg-[#fbf9f3] px-3.5 py-3.5 pr-12 text-sm text-[#315f54] outline-none placeholder:text-[#abb3ae]" /><button data-testid="button-toggle-password" type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-3.5 text-[#8b9c93]">{showPassword ? <Eye size={17} /> : <LockKeyhole size={16} />}</button></div></label><div className="flex items-center justify-between pt-1">{!register && <label className="flex items-center gap-2 text-[11px] font-bold text-[#7d9087]"><input data-testid="input-remember-me" type="checkbox" className="accent-[#39745a]" />Remember me</label>}{!register && <Link data-testid="link-forgot-password" href="/login" className="text-[11px] font-bold text-[#b66c43]">Forgot password?</Link>}</div><Button type="submit" className="mt-2 w-full py-3.5">{register ? 'Create workspace' : 'Sign in to SahaAI'}<ArrowRight size={15} /></Button></form><div className="my-6 flex items-center gap-3 text-[10px] text-[#abb3ae]"><span className="h-px flex-1 bg-[#e2dcd1]" />OR<span className="h-px flex-1 bg-[#e2dcd1]" /></div><button data-testid="button-google-auth" onClick={() => setLocation('/app')} className="flex w-full items-center justify-center gap-2.5 rounded-xl border border-[#ded8cb] bg-[#fbf9f3] py-3 text-xs font-bold text-[#5f786d] transition hover:bg-[#f0ede4]"><span className="grid size-5 place-items-center rounded-full bg-[#e8d8b8] text-[10px] font-extrabold text-[#7d5b29]">G</span>Continue with Google</button><div className="mt-7 text-center text-xs text-[#819189]">{register ? 'Already have a workspace?' : 'New to SahaAI?'} <Link data-testid="link-auth-switch" href={register ? '/login' : '/register'} className="font-bold text-[#b66c43] hover:text-[#8f4f31]">{register ? 'Sign in' : 'Create an account'}</Link></div></div><div className="mt-8 text-center text-[10px] text-[#a2aca6]">By continuing, you agree to SahaAI's terms and privacy policy.</div></div></div>;
}

function LegacyMarketingPage() {
  const [menu, setMenu] = useState(false);
  return <div className="grain min-h-[100dvh] overflow-hidden bg-[#f6f2e8] text-[#1b4a3f]"><header className="relative z-20 mx-auto flex max-w-7xl items-center justify-between px-5 py-5 md:px-10"><Brand /><nav className="hidden items-center gap-8 text-xs font-bold text-[#6a7f75] md:flex"><a href="#product" className="transition hover:text-[#b66c43]">Product</a><a href="#how" className="transition hover:text-[#b66c43]">How it works</a><a href="#stories" className="transition hover:text-[#b66c43]">Customer stories</a></nav><div className="hidden items-center gap-3 md:flex"><Link data-testid="link-marketing-login" href="/login" className="px-3 py-2 text-xs font-bold text-[#557269] hover:text-[#b66c43]">Sign in</Link><Link data-testid="link-marketing-start" href="/register" className="inline-flex items-center gap-2 rounded-xl bg-[#235d51] px-4 py-2.5 text-xs font-bold text-[#f8f2e7] shadow-[0_5px_14px_rgba(35,93,81,.2)] transition hover:bg-[#194c42]">Start free <ArrowRight size={14} /></Link></div><button data-testid="button-marketing-menu" onClick={() => setMenu(!menu)} className="md:hidden"><Menu size={20} /></button></header>{menu && <div className="relative z-20 mx-5 rounded-2xl border border-[#e2dcd1] bg-[#fbf9f3] p-3 shadow-lg md:hidden"><a href="#product" className="block rounded-lg px-3 py-2 text-xs font-bold">Product</a><Link data-testid="link-mobile-start" href="/register" className="block rounded-lg px-3 py-2 text-xs font-bold text-[#b66c43]">Start free</Link></div>}<main><section className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 pb-24 pt-16 md:grid-cols-[1.05fr_.95fr] md:px-10 md:pb-32 md:pt-24"><div className="absolute -left-24 top-20 size-72 rounded-full bg-[#e8d8b8]/35 blur-3xl" /><div className="page-enter relative"><div className="mb-6 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.2em] text-[#b66c43]"><span className="size-2 rounded-full bg-[#d49a66]" />The conversation cockpit for small business</div><h1 className="max-w-[650px] font-display text-[54px] font-extrabold leading-[.98] tracking-[-.075em] md:text-[78px]">Every hello<br /><span className="text-[#b66c43]">holds a future.</span></h1><p className="mt-7 max-w-[490px] text-[16px] leading-7 text-[#71857b] md:text-[18px]">SahaAI brings your WhatsApp and Instagram conversations into one warm, intelligent workspace — so you can follow up with the context that makes people feel remembered.</p><div className="mt-9 flex flex-wrap items-center gap-3"><Link data-testid="link-hero-start" href="/register" className="inline-flex items-center gap-2 rounded-xl bg-[#235d51] px-5 py-3.5 text-sm font-bold text-[#f8f2e7] shadow-[0_7px_18px_rgba(35,93,81,.2)] transition hover:-translate-y-0.5 hover:bg-[#194c42]">Start your free workspace <ArrowRight size={16} /></Link><a href="#how" className="inline-flex items-center gap-2 rounded-xl px-4 py-3.5 text-sm font-bold text-[#57736a] hover:bg-[#eee9de]">See how it works <ChevronRight size={16} /></a></div><div className="mt-10 flex items-center gap-4 text-[11px] text-[#899991]"><div className="flex -space-x-2"><Avatar initials="AA" tone="clay" size="sm" /><Avatar initials="MS" tone="blue" size="sm" /><Avatar initials="BN" tone="gold" size="sm" /></div><span><strong className="text-[#527167]">240+ businesses</strong> keeping the thread</span></div></div><div className="page-enter stagger-2 relative"><div className="absolute -right-10 -top-10 size-36 rounded-full bg-[#d5e8d4]/70 blur-2xl" /><div className="relative rounded-[28px] border border-[#d9d4c7] bg-[#fbf9f3] p-3 shadow-[0_25px_70px_rgba(43,79,67,.13)] md:rotate-[2deg]"><div className="rounded-[20px] bg-[#173f36] p-4 text-[#eff0e5]"><div className="mb-5 flex items-center justify-between"><div className="flex items-center gap-2"><div className="grid size-8 place-items-center rounded-lg bg-[#b8e3c2] text-[#173f36]"><MessageCircle size={16} /></div><div><div className="text-xs font-bold">sahaai</div><div className="text-[9px] text-[#92b4a4]">Bayt Noor Studio</div></div></div><div className="flex items-center gap-1.5 text-[9px] text-[#aed2ba]"><span className="size-1.5 rounded-full bg-[#b8e3c2]" />Live now</div></div><div className="mb-3 flex items-center justify-between"><span className="text-[10px] font-bold uppercase tracking-wider text-[#86aa99]">Today at a glance</span><span className="rounded-md bg-[#28584b] px-2 py-1 text-[9px] text-[#acd1b8]">04 Jun 2024</span></div><div className="grid grid-cols-3 gap-2">{[['128', 'conversations'], ['23', 'new leads'], ['12', 'bookings']].map(([num, text]) => <div key={text} className="rounded-xl bg-[#214c42] p-3"><div className="font-mono-custom text-[19px] font-bold text-[#e8d8b8]">{num}</div><div className="mt-1 text-[9px] text-[#98bbab]">{text}</div></div>)}</div><div className="mt-4 rounded-xl bg-[#f4f1e8] p-3 text-[#315f54]"><div className="mb-3 flex items-center justify-between"><span className="text-[10px] font-bold">Needs your voice</span><span className="rounded-full bg-[#f3dfd8] px-2 py-1 text-[9px] font-bold text-[#aa5a44]">3 waiting</span></div>{conversationsSeed.slice(0, 2).map(c => <div key={c.id} className="flex items-center gap-2.5 border-t border-[#e6e0d5] py-2.5"><Avatar initials={c.avatar} tone="clay" size="sm" /><div className="min-w-0 flex-1"><div className="text-[10px] font-bold">{c.contactName}</div><div className="truncate text-[9px] text-[#8a9b92]">{c.lastMessage}</div></div><ChevronRight size={13} className="text-[#9ba8a0]" /></div>)}</div></div></div><div className="absolute -bottom-7 -left-7 flex items-center gap-3 rounded-2xl border border-[#dce6d8] bg-[#eaf3e6] px-4 py-3 shadow-[0_10px_28px_rgba(42,83,63,.1)]"><div className="grid size-8 place-items-center rounded-full bg-[#c6e2ca] text-[#3d805d]"><CheckCircle2 size={16} /></div><div><div className="text-[10px] font-bold text-[#39745a]">Saha resolved it</div><div className="text-[9px] text-[#759386]">without losing the lead</div></div></div></div></section><section id="product" className="border-y border-[#e2dcd1] bg-[#eee9dd] px-5 py-20 md:px-10 md:py-28"><div className="mx-auto max-w-7xl"><div className="grid gap-10 md:grid-cols-[.8fr_1.2fr]"><div><div className="mb-3 text-[10px] font-bold uppercase tracking-[.2em] text-[#b66c43]">One clear view</div><h2 className="font-display text-[37px] font-extrabold leading-tight tracking-[-.06em] text-[#28574d] md:text-[49px]">Less hunting.<br />More <span className="text-[#b66c43]">being there.</span></h2></div><div className="grid gap-4 md:grid-cols-2"><div className="rounded-2xl border border-[#ded8cb] bg-[#f8f5ed] p-5"><div className="mb-10 grid size-10 place-items-center rounded-xl bg-[#dcecdf] text-[#39745a]"><Inbox size={19} /></div><h3 className="font-display text-[17px] font-extrabold text-[#315f54]">A shared inbox with memory</h3><p className="mt-2 text-xs leading-5 text-[#7d9087]">WhatsApp and Instagram, together. See what was said, who needs a reply, and what matters next.</p></div><div className="rounded-2xl border border-[#ded8cb] bg-[#f8f5ed] p-5"><div className="mb-10 grid size-10 place-items-center rounded-xl bg-[#f5e3bd] text-[#94672d]"><Bot size={19} /></div><h3 className="font-display text-[17px] font-extrabold text-[#315f54]">An assistant with good sense</h3><p className="mt-2 text-xs leading-5 text-[#7d9087]">Saha answers the easy things, speaks your language, and hands over the moments that need you.</p></div><div className="rounded-2xl border border-[#ded8cb] bg-[#f8f5ed] p-5 md:col-span-2"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><div className="mb-4 grid size-10 place-items-center rounded-xl bg-[#e6dbea] text-[#765888]"><TrendingUp size={19} /></div><h3 className="font-display text-[17px] font-extrabold text-[#315f54]">Follow the feeling through to revenue</h3><p className="mt-2 max-w-lg text-xs leading-5 text-[#7d9087]">From a “how much?” to a real booking. Leads, appointments, and patterns stay connected to the original conversation.</p></div><div className="flex items-end gap-1.5"><div className="h-10 w-5 rounded-t bg-[#d5e8d4]" /><div className="h-16 w-5 rounded-t bg-[#b8dcbf]" /><div className="h-24 w-5 rounded-t bg-[#7eaf8b]" /><div className="h-32 w-5 rounded-t bg-[#39745a]" /></div></div></div></div></div></div></section><section id="how" className="mx-auto max-w-7xl px-5 py-20 md:px-10 md:py-28"><div className="mb-12 max-w-xl"><div className="mb-3 text-[10px] font-bold uppercase tracking-[.2em] text-[#b66c43]">A quieter operating rhythm</div><h2 className="font-display text-[38px] font-extrabold leading-tight tracking-[-.06em] text-[#28574d]">Your business has a voice.<br /><span className="text-[#b66c43]">Saha helps it travel.</span></h2></div><div className="grid gap-8 md:grid-cols-3">{[['01', 'Connect your channels', 'Bring your WhatsApp Business and Instagram conversations into one shared space.'], ['02', 'Teach Saha your way', 'Set your tone, hours, services, and the boundaries that keep every answer honest.'], ['03', 'Step in with context', 'When the moment is yours, you arrive with the whole thread — not just the last message.']].map(([num, title, text], i) => <div data-testid={`card-step-${i}`} key={num} className="border-t-2 border-[#d8d2c5] pt-5"><div className="mb-12 font-mono-custom text-sm font-bold text-[#b66c43]">{num}</div><h3 className="font-display text-[20px] font-extrabold text-[#315f54]">{title}</h3><p className="mt-3 max-w-xs text-sm leading-6 text-[#7c9086]">{text}</p></div>)}</div></section><section id="stories" className="bg-[#173f36] px-5 py-20 text-[#f1eadc] md:px-10 md:py-28"><div className="mx-auto grid max-w-7xl gap-12 md:grid-cols-[.9fr_1.1fr] md:items-center"><div><div className="mb-4 text-[10px] font-bold uppercase tracking-[.2em] text-[#9dc1ad]">The Bayt Noor note</div><blockquote className="font-display text-[31px] font-extrabold leading-[1.1] tracking-[-.05em] md:text-[43px]">“It feels like Saha understands that a customer is never just a ticket.”</blockquote><div className="mt-7 flex items-center gap-3"><Avatar initials="BN" tone="gold" /><div><div className="text-xs font-bold">Basma Noor</div><div className="mt-1 text-[10px] text-[#94b4a5]">Founder, Bayt Noor Studio · Riyadh</div></div></div></div><div className="rounded-3xl border border-[#356357] bg-[#214c42] p-6 md:p-8"><div className="mb-8 flex items-center justify-between"><div className="flex items-center gap-2 text-xs font-bold"><span className="grid size-8 place-items-center rounded-lg bg-[#b8e3c2] text-[#173f36]"><MessageCircle size={16} /></span>sahaai</div><Badge tone="green">In their words</Badge></div><div className="grid gap-6 sm:grid-cols-3"><div><div className="font-mono-custom text-[27px] font-bold text-[#e8d8b8]">42s</div><div className="mt-1 text-[10px] text-[#9ab9aa]">average first reply</div></div><div><div className="font-mono-custom text-[27px] font-bold text-[#e8d8b8]">74.2%</div><div className="mt-1 text-[10px] text-[#9ab9aa]">resolved by Saha</div></div><div><div className="font-mono-custom text-[27px] font-bold text-[#e8d8b8]">18.6%</div><div className="mt-1 text-[10px] text-[#9ab9aa]">lead conversion</div></div></div><div className="mt-9 border-t border-[#356357] pt-5 text-xs leading-6 text-[#a9c7b8]">“We stopped opening conversations with anxiety. Now we open them knowing the story.”</div></div></div></section><section className="px-5 py-20 text-center md:px-10 md:py-28"><div className="mx-auto max-w-2xl"><div className="mb-4 text-[10px] font-bold uppercase tracking-[.2em] text-[#b66c43]">Begin with one conversation</div><h2 className="font-display text-[42px] font-extrabold leading-none tracking-[-.07em] text-[#28574d] md:text-[61px]">Make room for<br /><span className="text-[#b66c43]">the good work.</span></h2><p className="mx-auto mt-6 max-w-md text-sm leading-6 text-[#7b8f85]">Your first 14 days are on us. Bring your channels, invite your team, and let the busywork become background.</p><Link data-testid="link-footer-start" href="/register" className="mt-8 inline-flex items-center gap-2 rounded-xl bg-[#235d51] px-5 py-3.5 text-sm font-bold text-[#f8f2e7] shadow-[0_7px_18px_rgba(35,93,81,.2)] transition hover:-translate-y-0.5 hover:bg-[#194c42]">Start your free workspace <ArrowRight size={16} /></Link></div></section></main><footer className="border-t border-[#e2dcd1] px-5 py-7 md:px-10"><div className="mx-auto flex max-w-7xl flex-col justify-between gap-4 text-[10px] text-[#93a098] md:flex-row md:items-center"><Brand /><div className="flex gap-5"><span>English · العربية</span><span>Privacy</span><span>Terms</span><span>© 2024 SahaAI</span></div></div></footer></div>;
}

function LanguageRuntime({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    if (typeof window === 'undefined') return 'ar';
    return window.localStorage.getItem('fansconnect-language') === 'en' ? 'en' : 'ar';
  });
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    window.localStorage.setItem('fansconnect-language', language);
  }, [language]);
  const t = useCallback((text: string) => language === 'ar' ? (ar[text] || text) : text, [language]);
  return <LanguageContext.Provider value={{ language, t }}><button aria-label="Switch application language" data-testid="button-language-toggle" onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')} className="language-toggle fixed bottom-5 z-50 inline-flex items-center gap-2 rounded-xl border border-[#d8d1c4] bg-[#fbf9f3] px-3 py-2 text-[11px] font-bold text-[#315f54] shadow-lg transition hover:-translate-y-0.5"><Languages size={14} />{language === 'en' ? 'العربية' : 'English'}</button>{children}</LanguageContext.Provider>;
}

function AuthRuntime({ children }: { children: React.ReactNode }) {
  const [loading, setLoading] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);
  const [onboardingCompleted, setOnboardingCompleted] = useState(false);
  const [workspace, setWorkspace] = useState<WorkspaceContextData | null>(null);
  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const session = await apiRequest<{ authenticated: boolean; onboardingCompleted?: boolean }>('/auth/session');
      if (!session.authenticated) {
        setAuthenticated(false);
        setWorkspace(null);
        setOnboardingCompleted(false);
        return;
      }
      const context = await workspaceApi<WorkspaceContextData>('');
      setAuthenticated(true);
      setWorkspace(context);
      setOnboardingCompleted(Boolean(session.onboardingCompleted));
    } catch {
      setAuthenticated(false);
      setWorkspace(null);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    void refresh();
    const expire = () => {
      setAuthenticated(false);
      setWorkspace(null);
      setLoading(false);
    };
    window.addEventListener('fansconnect:session-expired', expire);
    return () => window.removeEventListener('fansconnect:session-expired', expire);
  }, [refresh]);
  const signOut = useCallback(async () => {
    try { await apiRequest('/auth/logout', { method: 'POST' }); } finally {
      setAuthenticated(false);
      setWorkspace(null);
      setOnboardingCompleted(false);
    }
  }, []);
  return <AuthContext.Provider value={{ loading, authenticated, onboardingCompleted, workspace, refresh, signOut }}>{children}</AuthContext.Provider>;
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const auth = useAuth();
  const { t } = useLanguage();
  const [, setLocation] = useLocation();
  useEffect(() => {
    if (!auth.loading && !auth.authenticated) setLocation('/login?expired=1');
  }, [auth.authenticated, auth.loading, setLocation]);
  if (auth.loading) return <div className="grid min-h-[100dvh] place-items-center bg-[#f6f2e8] text-sm font-bold text-[#557269]">{t('Checking channels…')}</div>;
  if (!auth.authenticated) return null;
  return <>{children}</>;
}

function PublicHeader() {
  return <header className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 md:px-10"><Brand /><nav className="hidden items-center gap-7 text-xs font-bold text-[#6a7f75] md:flex"><Link href="/features" className="hover:text-[#b66c43]">Features</Link><Link href="/pricing" className="hover:text-[#b66c43]">Pricing</Link><Link href="/faq" className="hover:text-[#b66c43]">FAQ</Link><Link href="/contact" className="hover:text-[#b66c43]">Contact</Link></nav><div className="flex items-center gap-2"><Link href="/login" className="rounded-xl px-3 py-2 text-xs font-bold text-[#557269] hover:text-[#b66c43]">Sign in</Link><Link href="/register" className="inline-flex items-center gap-2 rounded-xl bg-[#235d51] px-4 py-2.5 text-xs font-bold text-[#f8f2e7] shadow-[0_5px_14px_rgba(35,93,81,.2)]">Start free <ArrowRight size={14} /></Link></div></header>;
}

function PublicMarketingPage() {
  return <div className="grain min-h-[100dvh] overflow-hidden bg-[#f6f2e8] text-[#1b4a3f]"><PublicHeader /><main><section className="mx-auto grid max-w-7xl items-center gap-12 px-5 pb-24 pt-14 md:grid-cols-[1.05fr_.95fr] md:px-10 md:pb-32 md:pt-24"><div className="page-enter"><div className="mb-6 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.2em] text-[#b66c43]"><span className="size-2 rounded-full bg-[#d49a66]" />The growth workspace for modern businesses</div><h1 className="max-w-[650px] font-display text-[54px] font-extrabold leading-[.98] tracking-[-.075em] md:text-[78px]">Turn every message<br /><span className="text-[#b66c43]">into momentum.</span></h1><p className="mt-7 max-w-[510px] text-[16px] leading-7 text-[#71857b] md:text-[18px]">FansConnect brings WhatsApp and Instagram into one intelligent workspace for conversations, CRM, automation, appointments, and growth.</p><div className="mt-9 flex flex-wrap items-center gap-3"><Link href="/register" className="inline-flex items-center gap-2 rounded-xl bg-[#235d51] px-5 py-3.5 text-sm font-bold text-[#f8f2e7] shadow-[0_7px_18px_rgba(35,93,81,.2)]">Start your free workspace <ArrowRight size={16} /></Link><Link href="/features" className="inline-flex items-center gap-2 rounded-xl px-4 py-3.5 text-sm font-bold text-[#57736a] hover:bg-[#eee9de]">Explore features <ChevronRight size={16} /></Link></div><div className="mt-10 flex items-center gap-3 text-[11px] text-[#899991]"><Badge tone="green">Built for UAE teams</Badge><span>English and Arabic ready</span></div></div><div className="page-enter stagger-2 relative"><div className="absolute -right-10 -top-10 size-36 rounded-full bg-[#d5e8d4]/70 blur-2xl" /><div className="relative rounded-[28px] border border-[#d9d4c7] bg-[#fbf9f3] p-3 shadow-[0_25px_70px_rgba(43,79,67,.13)] md:rotate-[2deg]"><div className="rounded-[20px] bg-[#173f36] p-4 text-[#eff0e5]"><div className="mb-5 flex items-center justify-between"><div className="flex items-center gap-2"><div className="grid size-8 place-items-center rounded-lg bg-[#b8e3c2] text-[#173f36]"><MessageCircle size={16} /></div><div><div className="text-xs font-bold">FansConnect</div><div className="text-[9px] text-[#92b4a4]">Workspace overview</div></div></div><div className="flex items-center gap-1.5 text-[9px] text-[#aed2ba]"><span className="size-1.5 rounded-full bg-[#b8e3c2]" />Connected</div></div><div className="mb-3 text-[10px] font-bold uppercase tracking-wider text-[#86aa99]">Today at a glance</div><div className="grid grid-cols-3 gap-2">{[['128', 'conversations'], ['23', 'new leads'], ['12', 'bookings']].map(([num, text]) => <div key={text} className="rounded-xl bg-[#214c42] p-3"><div className="font-mono-custom text-[19px] font-bold text-[#e8d8b8]">{num}</div><div className="mt-1 text-[9px] text-[#98bbab]">{text}</div></div>)}</div><div className="mt-4 rounded-xl bg-[#f4f1e8] p-3 text-[#315f54]"><div className="mb-3 flex items-center justify-between"><span className="text-[10px] font-bold">Needs your voice</span><span className="rounded-full bg-[#f3dfd8] px-2 py-1 text-[9px] font-bold text-[#aa5a44]">3 waiting</span></div>{conversationsSeed.slice(0, 2).map(c => <div key={c.id} className="flex items-center gap-2.5 border-t border-[#e6e0d5] py-2.5"><Avatar initials={c.avatar} tone="clay" size="sm" /><div className="min-w-0 flex-1"><div className="text-[10px] font-bold">{c.contactName}</div><div className="truncate text-[9px] text-[#8a9b92]">{c.lastMessage}</div></div><ChevronRight size={13} className="text-[#9ba8a0]" /></div>)}</div></div></div></div></section><section className="border-y border-[#e2dcd1] bg-[#eee9dd] px-5 py-20 md:px-10 md:py-24"><div className="mx-auto grid max-w-7xl gap-5 md:grid-cols-3"><FeatureTile icon={Inbox} title="Unified conversations" text="WhatsApp and Instagram messages, shared with the context your team needs." /><FeatureTile icon={Bot} title="AI that knows the boundaries" text="Train helpful answers, define handoffs, and keep every reply on-brand." /><FeatureTile icon={TrendingUp} title="From chat to revenue" text="Connect leads, appointments, orders, campaigns, and analytics in one place." /></div></section><section className="mx-auto max-w-7xl px-5 py-20 text-center md:px-10 md:py-28"><h2 className="font-display text-[42px] font-extrabold leading-none tracking-[-.07em] text-[#28574d] md:text-[61px]">Give every conversation<br /><span className="text-[#b66c43]">a next step.</span></h2><p className="mx-auto mt-6 max-w-lg text-sm leading-6 text-[#7b8f85]">Start with a 14-day trial, connect your channels, and let your team focus on the relationships that matter.</p><Link href="/register" className="mt-8 inline-flex items-center gap-2 rounded-xl bg-[#235d51] px-5 py-3.5 text-sm font-bold text-[#f8f2e7]">Create your workspace <ArrowRight size={16} /></Link></section></main><footer className="border-t border-[#e2dcd1] px-5 py-7 md:px-10"><div className="mx-auto flex max-w-7xl flex-col justify-between gap-4 text-[10px] text-[#93a098] md:flex-row md:items-center"><Brand /><div className="flex gap-5"><span>English · العربية</span><span>Privacy</span><span>Terms</span><span>© 2026 FansConnect</span></div></div></footer></div>;
}

function FeatureTile({ icon: Icon, title, text }: { icon: React.ElementType; title: string; text: string }) {
  return <div className="rounded-2xl border border-[#ded8cb] bg-[#f8f5ed] p-5 text-left"><div className="mb-10 grid size-10 place-items-center rounded-xl bg-[#dcecdf] text-[#39745a]"><Icon size={19} /></div><h3 className="font-display text-[17px] font-extrabold text-[#315f54]">{title}</h3><p className="mt-2 text-xs leading-5 text-[#7d9087]">{text}</p></div>;
}

function LegacyPublicInfoPage({ type }: { type: 'features' | 'pricing' | 'faq' | 'contact' }) {
  /* const content = {
    features: { eyebrow: 'Product', title: 'One workspace for the whole customer journey.', text: 'Connect channels, manage relationships, automate helpful replies, and measure growth without losing the human thread.' },
    pricing: { eyebrow: 'Pricing', title: 'Plans in AED, built to grow with you.', text: 'Choose a monthly workspace plan. Every plan includes the core inbox, contacts, and bilingual foundations.' },
    faq: { eyebrow: 'Help centre', title: 'Answers before you get started.', text: 'FansConnect is designed for teams that want a clear, practical way to manage customer conversations.' },
    contact: { eyebrow: 'Contact', title: 'Let’s make your inbox calmer.', text: 'Tell us what your team is building and we’ll help you choose the right workspace setup.' },
  }[type];
  return <div className="grain min-h-[100dvh] bg-[#f6f2e8] text-[#1b4a3f]"><PublicHeader /><main className="mx-auto max-w-7xl px-5 pb-24 pt-14 md:px-10 md:pt-24"><div className="max-w-2xl"><div className="mb-4 text-[10px] font-bold uppercase tracking-[.2em] text-[#b66c43]">{content.eyebrow}</div><h1 className="font-display text-[46px] font-extrabold leading-none tracking-[-.07em] text-[#28574d] md:text-[70px]">{content.title}</h1><p className="mt-6 text-base leading-7 text-[#71857b]">{content.text}</p></div>{type === 'pricing' && <div className="mt-12 grid gap-4 lg:grid-cols-3">{[['Starter', 149, 'For solo operators', ['1 channel', '500 conversations', 'Core assistant']], ['Growth', 349, 'For growing teams', ['WhatsApp + Instagram', '2,500 conversations', 'Flows and analytics']], ['Scale', 699, 'For multi-person teams', ['Everything in Growth', 'Unlimited team members', 'Priority support']].map(([name, price, desc, features]) => <div key={String(name)} className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-6 shadow-[var(--shadow-soft)]"><Badge tone={name === 'Growth' ? 'green' : 'blue'}>{name === 'Growth' ? 'Most popular' : 'Monthly plan'}</Badge><h2 className="mt-4 font-display text-2xl font-extrabold text-[#315f54]">{name}</h2><p className="mt-1 text-xs text-[#82938b]">{desc}</p><div className="my-6 font-mono-custom text-3xl font-bold text-[#28574d]">{formatAED(Number(price))}<span className="font-sans text-xs font-medium text-[#83938b]"> / month</span></div><div className="space-y-3 border-t border-[#e6e0d5] pt-4">{(features as string[]).map(feature => <div key={feature} className="flex items-center gap-2 text-xs text-[#61796f]"><Check size={14} className="text-[#4f936d]" />{feature}</div>)}</div><Link href="/register" className="mt-6 inline-flex w-full justify-center rounded-xl bg-[#235d51] px-4 py-3 text-xs font-bold text-white">Start free</Link></div>)}</div>}{type === 'features' && <div className="mt-12 grid gap-4 md:grid-cols-2 xl:grid-cols-4"><FeatureTile icon={Inbox} title="Unified inbox" text="Keep WhatsApp and Instagram conversations together." /><FeatureTile icon={Users} title="CRM context" text="Contacts, leads, appointments, orders, and catalog." /><FeatureTile icon={Bot} title="AI assistant" text="FAQ, auto-replies, training, and safe handoffs." /><FeatureTile icon={BarChart3} title="Growth analytics" text="Campaign and conversation insights for your team." /></div>}{type === 'faq' && <div className="mt-12 max-w-3xl space-y-3">{[['Which channels can I connect?', 'FansConnect is designed around WhatsApp Business and Instagram Direct, with both represented in the shared inbox.'], ['Can I use Arabic?', 'Yes. The application supports English and Arabic with a persisted language preference and right-to-left layout mode.'], ['How does billing work?', 'Plans are billed monthly in AED. Ziina is the planned UAE payment method for workspace billing.'], ['Can I invite a team?', 'Yes. Workspace plans include team collaboration, with limits shown in your selected plan.']].map(([question, answer]) => <details key={question} className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5"><summary className="cursor-pointer text-sm font-extrabold text-[#315f54]">{question}</summary><p className="mt-3 text-sm leading-6 text-[#7b8f85]">{answer}</p></details>)}</div>}{type === 'contact' && <form className="mt-12 max-w-xl space-y-4 rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-6 shadow-[var(--shadow-soft)]" onSubmit={e => e.preventDefault()}><label className="block text-xs font-bold text-[#557269]">Work email<input required type="email" className="focus-ring mt-2 w-full rounded-xl border border-[#ded8cb] bg-[#f7f4eb] px-3.5 py-3 text-sm outline-none" placeholder="you@yourbusiness.com" /></label><label className="block text-xs font-bold text-[#557269]">How can we help?<textarea required className="focus-ring mt-2 min-h-32 w-full rounded-xl border border-[#ded8cb] bg-[#f7f4eb] px-3.5 py-3 text-sm outline-none" placeholder="Tell us about your team and channels." /></label><Button type="submit">Send enquiry <ArrowRight size={15} /></Button></form>}</main></div>;
  */
  return <div />;
}

function PublicInfoPage({ type }: { type: 'features' | 'pricing' | 'faq' | 'contact' }) {
  const content = {
    features: { eyebrow: 'Product', title: 'One workspace for the whole customer journey.', text: 'Connect channels, manage relationships, automate helpful replies, and measure growth without losing the human thread.' },
    pricing: { eyebrow: 'Pricing', title: 'Plans in AED, built to grow with you.', text: 'Choose a monthly workspace plan with clear limits and no hidden currency changes.' },
    faq: { eyebrow: 'Help centre', title: 'Answers before you get started.', text: 'FansConnect is designed for teams that want a clear, practical way to manage customer conversations.' },
    contact: { eyebrow: 'Contact', title: 'Let’s make your inbox calmer.', text: 'Tell us what your team is building and we’ll help you choose the right workspace setup.' },
  }[type];
  const cards = type === 'pricing'
    ? [['Starter', 'AED 149 / month', 'For a focused inbox'], ['Growth', 'AED 349 / month', 'For growing teams'], ['Scale', 'AED 699 / month', 'For multi-person teams']]
    : type === 'features'
      ? [['Unified inbox', 'WhatsApp and Instagram in one shared view.', 'Explore workspace'], ['CRM and commerce', 'Contacts, leads, appointments, orders, and catalog.', 'Explore workspace'], ['AI assistant', 'FAQ, auto-replies, training, and safe handoffs.', 'Explore workspace'], ['Analytics', 'Campaign and conversation insights for your team.', 'Explore workspace']]
      : type === 'faq'
        ? [['Which channels can I connect?', 'WhatsApp Business and Instagram Direct.', 'Read answer'], ['Can I use Arabic?', 'Yes. FansConnect supports English and Arabic with RTL layout.', 'Read answer'], ['How does billing work?', 'Plans are billed monthly in AED, with Ziina planned for UAE billing.', 'Read answer'], ['Can I invite a team?', 'Yes. Team collaboration is included within plan limits.', 'Read answer']]
        : [['Talk to us', 'Tell us what your team is building and we will help with setup.', 'Contact support'], ['Getting started', 'Create a workspace, connect a channel, and invite your team.', 'Start free']];
  return <div className="grain min-h-[100dvh] bg-[#f6f2e8] text-[#1b4a3f]"><PublicHeader /><main className="mx-auto max-w-7xl px-5 pb-24 pt-14 md:px-10 md:pt-24"><div className="max-w-2xl"><div className="mb-4 text-[10px] font-bold uppercase tracking-[.2em] text-[#b66c43]">{content.eyebrow}</div><h1 className="font-display text-[46px] font-extrabold leading-none tracking-[-.07em] text-[#28574d] md:text-[70px]">{content.title}</h1><p className="mt-6 text-base leading-7 text-[#71857b]">{content.text}</p></div><div className="mt-12 grid gap-4 md:grid-cols-2">{cards.map(([heading, detail, label]) => <article key={heading} className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-6 shadow-[var(--shadow-soft)]"><h2 className="font-display text-xl font-extrabold text-[#315f54]">{heading}</h2><p className="mt-3 text-sm leading-6 text-[#82938b]">{detail}</p><Link href={type === 'contact' ? '/contact' : '/register'} className="mt-5 inline-flex items-center gap-2 text-xs font-bold text-[#b66c43]">{label} <ArrowRight size={13} /></Link></article>)}</div></main></div>;
}

function LegacyAuthPageV2({ register = false }: { register?: boolean }) {
  const [, setLocation] = useLocation();
  const [showPassword, setShowPassword] = useState(false);
  return <div className="grain flex min-h-[100dvh] bg-[#f6f2e8]"><div className="hidden w-[47%] flex-col justify-between bg-[#173f36] p-10 text-[#f1eadc] lg:flex"><Brand dark /><div className="max-w-md"><div className="mb-5 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.2em] text-[#9ec4b0]"><span className="size-2 rounded-full bg-[#b8e3c2]" />A calmer way to grow</div><h1 className="font-display text-[54px] font-extrabold leading-[.98] tracking-[-.07em]">Keep the thread.<br /><span className="text-[#b8e3c2]">Grow the trust.</span></h1><p className="mt-6 max-w-sm text-[15px] leading-7 text-[#b3cdbf]">FansConnect gives modern teams one place to follow every conversation from first hello to lasting relationship.</p></div><div className="text-[10px] text-[#789e8e]">Built for businesses across the UAE</div></div><div className="flex flex-1 flex-col px-6 py-8 md:px-16 lg:px-20"><div className="lg:hidden"><Brand /></div><div className="mx-auto flex w-full max-w-[410px] flex-1 flex-col justify-center"><div className="mb-8 mt-10 lg:mt-0"><div className="mb-3 text-[10px] font-bold uppercase tracking-[.18em] text-[#b66c43]">{register ? 'Start your workspace' : 'Welcome back'}</div><h2 className="font-display text-[32px] font-extrabold tracking-[-.06em] text-[#1b4a3f]">{register ? 'A better inbox starts here.' : 'Good to see you again.'}</h2><p className="mt-2 text-sm text-[#7e9087]">{register ? 'Set up your workspace in a few minutes. No credit card needed.' : 'Sign in to pick up exactly where your customers left you.'}</p></div><form onSubmit={e => { e.preventDefault(); setLocation(register ? '/onboarding' : '/app'); }} className="space-y-4"><label className="block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#879890]">Work email</span><input required type="email" placeholder="you@yourbusiness.com" className="focus-ring w-full rounded-xl border border-[#ded8cb] bg-[#fbf9f3] px-3.5 py-3.5 text-sm outline-none" /></label>{register && <label className="block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#879890]">Business name</span><input required placeholder="Your business" className="focus-ring w-full rounded-xl border border-[#ded8cb] bg-[#fbf9f3] px-3.5 py-3.5 text-sm outline-none" /></label>}<label className="block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#879890]">Password</span><div className="relative"><input required type={showPassword ? 'text' : 'password'} placeholder="At least 8 characters" className="focus-ring w-full rounded-xl border border-[#ded8cb] bg-[#fbf9f3] px-3.5 py-3.5 pr-12 text-sm outline-none" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-3.5 text-[#8b9c93]">{showPassword ? <Eye size={17} /> : <LockKeyhole size={16} />}</button></div></label>{!register && <Link href="/forgot-password" className="block text-right text-[11px] font-bold text-[#b66c43]">Forgot password?</Link>}<Button type="submit" className="w-full py-3.5">{register ? 'Create workspace' : 'Sign in to FansConnect'}<ArrowRight size={15} /></Button></form><div className="mt-7 text-center text-xs text-[#819189]">{register ? 'Already have a workspace?' : 'New to FansConnect?'} <Link href={register ? '/login' : '/register'} className="font-bold text-[#b66c43]">{register ? 'Sign in' : 'Create an account'}</Link></div></div><div className="mt-8 text-center text-[10px] text-[#a2aca6]">By continuing, you agree to FansConnect’s terms and privacy policy.</div></div></div>;
}

function AuthPageV2({ mode: requestedMode = 'login', register = false }: { mode?: 'login' | 'register' | 'forgot' | 'reset' | 'verify'; register?: boolean }) {
  const mode = register ? 'register' : requestedMode;
  const { t } = useLanguage();
  const auth = useAuth();
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [actionLink, setActionLink] = useState('');
  const token = new URLSearchParams(window.location.search).get('token') || '';
  const expired = new URLSearchParams(window.location.search).get('expired') === '1';
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true); setError(''); setMessage('');
    try {
      if (mode === 'register') {
        const result = await apiRequest<{ onboardingCompleted: boolean }>('/auth/register', { method: 'POST', body: JSON.stringify({ email, password, businessName }) });
        await auth.refresh();
        setLocation('/verify-email');
      } else if (mode === 'login') {
        const result = await apiRequest<{ onboardingCompleted: boolean; requiresEmailVerification: boolean }>('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
        await auth.refresh();
        setLocation(result.requiresEmailVerification ? '/verify-email' : result.onboardingCompleted ? '/app' : '/onboarding');
      } else if (mode === 'forgot') {
        const result = await apiRequest<{ message: string }>('/auth/forgot-password', { method: 'POST', body: JSON.stringify({ email }) });
        setMessage(result.message);
      } else if (mode === 'reset') {
        const result = await apiRequest<{ message: string }>('/auth/reset-password', { method: 'POST', body: JSON.stringify({ token, password }) });
        setMessage(result.message);
        window.setTimeout(() => setLocation('/login'), 900);
      } else if (token) {
        await apiRequest('/auth/verify-email', { method: 'POST', body: JSON.stringify({ token }) });
        await auth.refresh();
        setMessage(t('Email verified'));
        window.setTimeout(() => setLocation(auth.onboardingCompleted ? '/app' : '/onboarding'), 700);
      } else {
        try {
          const result = await apiRequest<{ message: string }>('/auth/verify-email/dev', { method: 'POST' });
          setMessage(result.message);
          await auth.refresh();
          window.setTimeout(() => setLocation('/onboarding'), 700);
        } catch (reason) {
          if (!(reason instanceof Error) || (reason as Error & { status?: number }).status !== 404) throw reason;
          const result = await apiRequest<{ message: string }>('/auth/resend-verification', { method: 'POST' });
          setMessage(result.message);
        }
      }
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : t('Could not connect to the server.'));
    } finally { setBusy(false); }
  };
  const title = mode === 'register' ? 'A better inbox starts here.' : mode === 'forgot' ? 'Reset your password' : mode === 'reset' ? 'Reset your password' : mode === 'verify' ? 'Verify your email' : 'Good to see you again.';
  return <div className="grain flex min-h-[100dvh] bg-[#f6f2e8]"><aside className="hidden w-[44%] flex-col justify-between bg-[#173f36] p-10 text-[#f1eadc] lg:flex"><Brand dark /><div><h1 className="font-display text-5xl font-extrabold leading-tight">{t('Keep the thread.')}<br /><span className="text-[#b8e3c2]">{t('Grow the trust.')}</span></h1><p className="mt-6 max-w-md leading-7 text-[#b3cdbf]">FansConnect</p></div><div className="text-xs text-[#789e8e]">UAE · العربية · English</div></aside><main className="flex flex-1 flex-col px-6 py-8 md:px-16"><div className="lg:hidden"><Brand /></div><div className="mx-auto flex w-full max-w-[410px] flex-1 flex-col justify-center"><div className="mb-8"><div className="mb-3 text-[10px] font-bold uppercase tracking-[.18em] text-[#b66c43]">{t(mode === 'register' ? 'Start your workspace' : mode === 'login' ? 'Welcome back' : title)}</div><h2 className="font-display text-[32px] font-extrabold text-[#1b4a3f]">{t(title)}</h2></div>{expired && <div className="mb-4 rounded-xl bg-[#fff0eb] p-3 text-xs font-bold text-[#9c5144]">{t('Your session has expired. Please sign in again.')}</div>}{error && <div role="alert" className="mb-4 rounded-xl bg-[#fff0eb] p-3 text-xs font-bold text-[#9c5144]">{t(error)}</div>}{message && <div className="mb-4 rounded-xl bg-[#e5f1e3] p-3 text-xs font-bold text-[#39745a]">{t(message)}{actionLink && <Link href={actionLink} className="ms-2 underline">{t(mode === 'forgot' ? 'Reset password' : 'Verify email')}</Link>}</div>}<form onSubmit={submit} className="space-y-4">{(mode === 'login' || mode === 'register' || mode === 'forgot') && <label className="block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#879890]">{t('Work email')}</span><input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} className="focus-ring w-full rounded-xl border border-[#ded8cb] bg-[#fbf9f3] px-3.5 py-3.5 text-sm outline-none" /></label>}{mode === 'register' && <label className="block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#879890]">{t('Business name (optional)')}</span><input value={businessName} onChange={(event) => setBusinessName(event.target.value)} className="focus-ring w-full rounded-xl border border-[#ded8cb] bg-[#fbf9f3] px-3.5 py-3.5 text-sm outline-none" /></label>}{(mode === 'login' || mode === 'register' || mode === 'reset') && <label className="block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[#879890]">{t(mode === 'reset' ? 'New password' : 'Password')}</span><div className="relative"><input required minLength={8} type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} className="focus-ring w-full rounded-xl border border-[#ded8cb] bg-[#fbf9f3] px-3.5 py-3.5 text-sm outline-none" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="field-icon absolute top-3.5 text-[#8b9c93]">{showPassword ? <Eye size={17} /> : <LockKeyhole size={16} />}</button></div></label>}{mode === 'login' && <Link href="/forgot-password" className="block text-end text-[11px] font-bold text-[#b66c43]">{t('Forgot password?')}</Link>}<Button type="submit" disabled={busy} className="w-full py-3.5">{busy ? t('Checking…') : t(mode === 'register' ? 'Create workspace' : mode === 'login' ? 'Sign in to FansConnect' : mode === 'forgot' ? 'Send reset link' : mode === 'reset' ? 'Reset password' : 'Verify email')}<ArrowRight size={15} /></Button></form>{(mode === 'login' || mode === 'register') && <div className="mt-7 text-center text-xs text-[#819189]">{t(mode === 'register' ? 'Already have a workspace?' : 'New to FansConnect?')} <Link href={mode === 'register' ? '/login' : '/register'} className="font-bold text-[#b66c43]">{t(mode === 'register' ? 'Sign in' : 'Create an account')}</Link></div>}</div></main></div>;
}

function WorkspaceModulePage({ title, eyebrow, description, icon: Icon, items, action = 'Add item' }: { title: string; eyebrow: string; description: string; icon: React.ElementType; items: { name: string; detail: string; status?: string }[]; action?: string }) {
  const [showForm, setShowForm] = useState(false);
  return <Shell><PageHeading eyebrow={eyebrow} title={title} description={description} action={<Button onClick={() => setShowForm(!showForm)}><Plus size={15} />{action}</Button>} />{showForm && <div className="page-enter mb-5 flex flex-wrap gap-3 rounded-2xl border border-[#dce5d9] bg-[#e8f2e4] p-4"><input autoFocus placeholder={`Name this ${eyebrow.toLowerCase()}`} className="focus-ring min-w-[220px] flex-1 rounded-xl border border-[#d4e2d2] bg-[#fbf9f3] px-3 py-2.5 text-xs outline-none" /><Button onClick={() => setShowForm(false)}>Save</Button></div>}<div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{items.map(item => <article key={item.name} className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)] transition hover:-translate-y-0.5"><div className="flex items-start justify-between gap-3"><div className="grid size-10 place-items-center rounded-xl bg-[#e8f2e4] text-[#39745a]"><Icon size={18} /></div>{item.status && <Badge tone={item.status === 'Connected' || item.status === 'Active' ? 'green' : 'gold'}>{item.status}</Badge>}</div><h2 className="mt-5 font-display text-[17px] font-extrabold text-[#315f54]">{item.name}</h2><p className="mt-2 text-xs leading-5 text-[#82938b]">{item.detail}</p><button className="mt-5 text-xs font-bold text-[#b66c43]">Manage <ArrowUpRight size={13} className="inline" /></button></article>)}</div></Shell>;
}

function AIAssistantPageV2() {
  const [enabled, setEnabled] = useState(false);
  return <SettingsLayout title="AI assistant" description="Create helpful, bounded assistance for your team. The assistant stays off until you connect a channel and publish your settings." action={<Button onClick={() => setEnabled(!enabled)}>{enabled ? 'Save and publish' : 'Save draft'} <Save size={14} /></Button>}><div className="space-y-5"><section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="flex items-center justify-between"><div className="flex items-center gap-3"><div className="grid size-11 place-items-center rounded-xl bg-[#e8f2e4] text-[#39745a]"><Bot size={21} /></div><div><h2 className="font-display text-[17px] font-extrabold text-[#315f54]">Assistant status</h2><p className="mt-1 text-[11px] text-[#82938b]">Enable only after reviewing your training and handoff rules.</p></div></div><Toggle checked={enabled} onChange={() => setEnabled(!enabled)} label={enabled ? 'On' : 'Off'} /></div></section><section className="grid gap-5 md:grid-cols-2"><label className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5"><span className="text-[11px] font-bold uppercase tracking-wider text-[#889890]">Assistant name</span><input defaultValue="FansConnect Assistant" className="focus-ring mt-3 w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3.5 py-3 text-sm font-bold outline-none" /></label><label className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5"><span className="text-[11px] font-bold uppercase tracking-wider text-[#889890]">Default language</span><select defaultValue="English + Arabic" className="focus-ring mt-3 w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3.5 py-3 text-sm font-bold outline-none"><option>English + Arabic</option><option>English</option><option>Arabic</option></select></label></section><section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">Handoff rules</h2><div className="mt-4 space-y-3">{['Ask for a human when a customer requests a team member.', 'Never invent availability, pricing, or order status.', 'Escalate complaints and sensitive conversations.'].map(rule => <label key={rule} className="flex items-center gap-3 rounded-xl bg-[#f4f1e8] p-3 text-xs font-bold text-[#557269]"><input type="checkbox" defaultChecked className="accent-[#39745a]" />{rule}</label>)}</div></section></div></SettingsLayout>;
}

function LegacyChannelsPageV2() {
  return <SettingsLayout title="Channels" description="Connect WhatsApp Business and Instagram to bring customer conversations into one shared inbox."><div className="grid gap-5 md:grid-cols-2"><div className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="flex items-center gap-3"><div className="grid size-11 place-items-center rounded-xl bg-[#d8f0dc] text-[#287550]"><MessageCircle size={22} /></div><div><h2 className="font-display text-[17px] font-extrabold text-[#315f54]">WhatsApp Business</h2><p className="mt-1 text-[11px] text-[#82938b]">Not connected</p></div></div><p className="mt-6 text-xs leading-5 text-[#71857b]">Connect your business number to receive messages, send approved templates, and keep your team in sync.</p><Button className="mt-5">Connect WhatsApp <Link2 size={14} /></Button></div><div className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="flex items-center gap-3"><div className="grid size-11 place-items-center rounded-xl bg-[#f6dbe8] text-[#a14472]"><Instagram size={22} /></div><div><h2 className="font-display text-[17px] font-extrabold text-[#315f54]">Instagram Direct</h2><p className="mt-1 text-[11px] text-[#82938b]">Not connected</p></div></div><p className="mt-6 text-xs leading-5 text-[#71857b]">Connect a professional account to manage direct messages alongside WhatsApp.</p><Button className="mt-5">Connect Instagram <Link2 size={14} /></Button></div></div></SettingsLayout>;
}

function LegacyBusinessProfilePageV2() {
  const [saved, setSaved] = useState(false);
  return <SettingsLayout title="Business profile" description="Keep the details your team and assistant use to represent your business accurate." action={<Button onClick={() => setSaved(true)}>{saved ? 'Saved' : 'Save changes'} <Save size={14} /></Button>}><div className="space-y-5 rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="grid gap-5 md:grid-cols-2"><label><span className="text-[11px] font-bold uppercase tracking-wider text-[#889890]">Business name</span><input defaultValue="Your business" className="focus-ring mt-2 w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3.5 py-3 text-sm font-bold outline-none" /></label><label><span className="text-[11px] font-bold uppercase tracking-wider text-[#889890]">Industry</span><select defaultValue="Services" className="focus-ring mt-2 w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3.5 py-3 text-sm font-bold outline-none"><option>Services</option><option>Retail</option><option>Beauty and wellness</option><option>Hospitality</option></select></label><label><span className="text-[11px] font-bold uppercase tracking-wider text-[#889890]">Country</span><select defaultValue="United Arab Emirates" className="focus-ring mt-2 w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3.5 py-3 text-sm font-bold outline-none"><option>United Arab Emirates</option></select></label><label><span className="text-[11px] font-bold uppercase tracking-wider text-[#889890]">Timezone</span><select defaultValue="Asia/Dubai" className="focus-ring mt-2 w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3.5 py-3 text-sm font-bold outline-none"><option>Asia/Dubai (GMT+4)</option></select></label></div>{saved && <div className="flex items-center gap-2 rounded-xl bg-[#e5f1e3] px-4 py-3 text-xs font-bold text-[#39745a]"><CheckCircle2 size={15} />Your profile is up to date.</div>}</div></SettingsLayout>;
}

function BillingPageV2() {
  const [selected, setSelected] = useState('Growth');
  const [plans, setPlans] = useState<{ name: string; amount: number; description: string; features: readonly string[] }[]>([]);
  const [planError, setPlanError] = useState(false);
  useEffect(() => {
    fetch('/api/plans').then(response => response.ok ? response.json() : Promise.reject(new Error('plans unavailable'))).then(data => setPlans(data.plans.map((plan: { name: string; amount: number; description: string; features: readonly string[] }) => plan))).catch(() => setPlanError(true));
  }, []);
  return <SettingsLayout title="Plan & billing" description="Transparent monthly plans in AED. Ziina will be available for UAE workspace billing." action={<Button variant="secondary"><Download size={14} />Download invoices</Button>}><div className="mb-5 rounded-2xl border border-[#e8dfcf] bg-[#fbf5e8] p-5"><div className="flex items-start gap-3 text-xs text-[#806f52]"><CreditCard size={17} className="mt-0.5 text-[#bc8651]" /><p><span className="font-bold">Billing is ready for setup.</span> Connect Ziina when you are ready to activate a paid plan. No payment method is stored in this preview.</p></div></div>{planError && <div className="mb-5 rounded-xl border border-[#e8c9c0] bg-[#fff0eb] px-4 py-3 text-xs font-bold text-[#9c5144]">Plans could not be loaded from the workspace service.</div>}{!planError && plans.length === 0 && <div className="rounded-2xl border border-dashed border-[#d7dfd5] bg-[#f3f7ee] p-8 text-center text-xs font-bold text-[#6e8579]">Loading AED plans…</div>}<div className="grid gap-4 lg:grid-cols-3">{plans.map(plan => <button key={plan.name} onClick={() => setSelected(plan.name)} className={`relative rounded-2xl border p-5 text-left transition ${selected === plan.name ? 'border-[#70a77e] bg-[#eef5e9] shadow-[0_6px_22px_rgba(54,113,80,.1)]' : 'border-[#e3ddd2] bg-[#fbf9f3]'}`}>{plan.name === 'Growth' && <span className="absolute -top-3 left-5 rounded-full bg-[#cc7c4c] px-2.5 py-1 text-[9px] font-bold uppercase tracking-wider text-white">Most popular</span>}<div className="flex items-start justify-between"><div><div className="font-display text-[17px] font-extrabold text-[#315f54]">{plan.name}</div><div className="mt-1 text-[11px] text-[#82938b]">{plan.description}</div></div><span className={`grid size-5 place-items-center rounded-full border-2 ${selected === plan.name ? 'border-[#4f936d] bg-[#4f936d] text-white' : 'border-[#cbd5cc]'}`}>{selected === plan.name && <Check size={12} />}</span></div><div className="my-5 font-mono-custom text-[25px] font-bold text-[#28574d]">{formatAED(plan.amount)}<span className="font-sans text-xs font-medium text-[#83938b]"> / month</span></div><div className="space-y-2 border-t border-[#e6e0d5] pt-4">{plan.features.map(f => <div key={f} className="flex items-center gap-2 text-xs text-[#61796f]"><Check size={14} className="text-[#4f936d]" />{f}</div>)}</div><div className="mt-5 rounded-lg bg-[#d5e9d3] py-2 text-center text-[11px] font-bold text-[#39745a]">{selected === plan.name ? 'Selected plan' : 'Choose plan'}</div></button>)}</div></SettingsLayout>;
}

function SettingsPageV2() {
  return <SettingsLayout title="Settings" description="Manage workspace preferences, language, notifications, and access."><div className="space-y-4">{[['Language and direction', 'English and Arabic are supported with automatic RTL layout.'], ['Notifications', 'Choose which workspace events should alert your team.'], ['Team access', 'Invite teammates and manage workspace roles.'], ['Security', 'Review sessions and keep account recovery details current.']].map(([name, detail]) => <div key={name} className="flex items-center justify-between rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">{name}</h2><p className="mt-1 text-xs text-[#82938b]">{detail}</p></div><button className="text-xs font-bold text-[#b66c43]">Manage <ArrowUpRight size={13} className="inline" /></button></div>)}</div></SettingsLayout>;
}

function LegacyOnboardingPage() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  return <div className="grain min-h-[100dvh] bg-[#f6f2e8] px-5 py-8"><div className="mx-auto max-w-2xl"><Brand /><div className="mt-16 rounded-3xl border border-[#e3ddd2] bg-[#fbf9f3] p-6 shadow-[var(--shadow-soft)] md:p-10"><div className="mb-8 flex items-center justify-between"><div><div className="text-[10px] font-bold uppercase tracking-[.2em] text-[#b66c43]">Workspace setup</div><h1 className="mt-2 font-display text-3xl font-extrabold text-[#28574d]">{step === 1 ? 'Tell us about your business.' : step === 2 ? 'Choose your channels.' : 'Your workspace is ready.'}</h1></div><span className="text-xs font-bold text-[#8a9a92]">Step {step} of 3</span></div>{step === 1 && <div className="space-y-4"><input placeholder="Business name" className="focus-ring w-full rounded-xl border border-[#ded8cb] bg-[#f7f4eb] px-3.5 py-3.5 text-sm outline-none" /><select defaultValue="Services" className="focus-ring w-full rounded-xl border border-[#ded8cb] bg-[#f7f4eb] px-3.5 py-3.5 text-sm outline-none"><option>Services</option><option>Retail</option><option>Beauty and wellness</option></select></div>}{step === 2 && <div className="grid gap-3 md:grid-cols-2"><button className="rounded-2xl border border-[#b9d8bd] bg-[#e8f2e4] p-5 text-left"><MessageCircle size={20} className="text-[#287550]" /><div className="mt-4 text-sm font-bold text-[#315f54]">WhatsApp Business</div><div className="mt-1 text-xs text-[#82938b]">Connect later from Channels</div></button><button className="rounded-2xl border border-[#e3ddd2] bg-[#f7f4eb] p-5 text-left"><Instagram size={20} className="text-[#a14472]" /><div className="mt-4 text-sm font-bold text-[#315f54]">Instagram Direct</div><div className="mt-1 text-xs text-[#82938b]">Connect later from Channels</div></button></div>}{step === 3 && <div className="rounded-2xl bg-[#e8f2e4] p-5 text-sm leading-6 text-[#557269]"><CheckCircle2 className="mb-3 text-[#39745a]" />Your workspace has been created. Connect a channel when you are ready to start receiving conversations.</div>}<div className="mt-8 flex justify-end"><Button onClick={() => step < 3 ? setStep(step + 1) : setLocation('/app')}>{step < 3 ? 'Continue' : 'Open workspace'} <ArrowRight size={15} /></Button></div></div></div></div>;
}

function BusinessProfilePageV2() {
  const { t } = useLanguage();
  const auth = useAuth();
  const [businessName, setBusinessName] = useState(auth.workspace?.profile?.businessName || auth.workspace?.workspace.name || '');
  const [activityType, setActivityType] = useState(auth.workspace?.profile?.activityType || '');
  const [country, setCountry] = useState(auth.workspace?.profile?.country || 'United Arab Emirates');
  const [state, setState] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const save = async () => {
    setState('saving');
    try {
      await workspaceApi('/profile', { method: 'PUT', body: JSON.stringify({ businessName, activityType, country }) });
      await auth.refresh();
      setState('saved');
    } catch { setState('error'); }
  };
  return <SettingsLayout title="Business profile" description="Keep your real business details available to your team and assistant." action={<Button onClick={() => void save()} disabled={state === 'saving'}><Save size={15} />{t(state === 'saved' ? 'Saved' : 'Save changes')}</Button>}><div className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5">{state === 'error' && <div className="mb-4 rounded-xl bg-[#fff0eb] p-3 text-xs font-bold text-[#9c5144]">{t('Could not connect to the server.')}</div>}<div className="grid gap-5 md:grid-cols-2"><label><span className="mb-2 block text-[11px] font-bold uppercase text-[#889890]">{t('Business name')}</span><input value={businessName} onChange={(event) => setBusinessName(event.target.value)} className="focus-ring w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3.5 py-3 text-sm font-bold outline-none" /></label><label><span className="mb-2 block text-[11px] font-bold uppercase text-[#889890]">{t('Industry')}</span><input value={activityType} onChange={(event) => setActivityType(event.target.value)} className="focus-ring w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3.5 py-3 text-sm font-bold outline-none" /></label><label><span className="mb-2 block text-[11px] font-bold uppercase text-[#889890]">{t('Country')}</span><input value={country} onChange={(event) => setCountry(event.target.value)} className="focus-ring w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3.5 py-3 text-sm font-bold outline-none" /></label></div>{state === 'saved' && <div className="mt-5 flex items-center gap-2 rounded-xl bg-[#e5f1e3] px-4 py-3 text-xs font-bold text-[#39745a]"><CheckCircle2 size={15} />{t('Your profile is up to date.')}</div>}</div></SettingsLayout>;
}

function OnboardingPage() {
  const { t } = useLanguage();
  const auth = useAuth();
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [businessName, setBusinessName] = useState(auth.workspace?.workspace.name || '');
  const [activityType, setActivityType] = useState('');
  const [busy, setBusy] = useState(false);
  const next = async () => {
    setBusy(true);
    try {
      if (step === 1) await workspaceApi('/profile', { method: 'PUT', body: JSON.stringify({ businessName, activityType, country: 'United Arab Emirates' }) });
      if (step < 3) setStep(step + 1);
      else {
        await workspaceApi('/onboarding/complete', { method: 'POST' });
        await auth.refresh();
        setLocation('/app');
      }
    } finally { setBusy(false); }
  };
  const title = step === 1 ? 'Tell us about your business.' : step === 2 ? 'Choose your channels.' : 'Your workspace is ready.';
  return <div className="grain min-h-[100dvh] bg-[#f6f2e8] px-5 py-8"><div className="mx-auto max-w-2xl"><Brand /><div className="mt-12 rounded-3xl border border-[#e3ddd2] bg-[#fbf9f3] p-6 md:p-10"><div className="mb-8 flex items-start justify-between gap-4"><div><div className="text-[10px] font-bold uppercase tracking-[.2em] text-[#b66c43]">{t('Workspace setup')}</div><h1 className="mt-2 font-display text-3xl font-extrabold text-[#28574d]">{t(title)}</h1></div><span className="whitespace-nowrap text-xs font-bold text-[#8a9a92]">{t('Step')} {step} {t('of')} 3</span></div>{step === 1 && <div className="space-y-4"><input required value={businessName} onChange={(event) => setBusinessName(event.target.value)} placeholder={t('Business name')} className="focus-ring w-full rounded-xl border border-[#ded8cb] bg-[#f7f4eb] px-3.5 py-3.5 text-sm outline-none" /><input value={activityType} onChange={(event) => setActivityType(event.target.value)} placeholder={t('Industry')} className="focus-ring w-full rounded-xl border border-[#ded8cb] bg-[#f7f4eb] px-3.5 py-3.5 text-sm outline-none" /></div>}{step === 2 && <div className="grid gap-3 md:grid-cols-2"><div className="rounded-2xl border border-[#b9d8bd] bg-[#e8f2e4] p-5"><MessageCircle size={20} className="text-[#287550]" /><div className="mt-4 text-sm font-bold text-[#315f54]">WhatsApp Business</div><div className="mt-1 text-xs text-[#82938b]">{t('Connect later from Channels')}</div></div><div className="rounded-2xl border border-[#e3ddd2] bg-[#f7f4eb] p-5"><Instagram size={20} className="text-[#a14472]" /><div className="mt-4 text-sm font-bold text-[#315f54]">Instagram</div><div className="mt-1 text-xs text-[#82938b]">{t('Connect later from Channels')}</div></div></div>}{step === 3 && <div className="rounded-2xl bg-[#e8f2e4] p-5 text-sm leading-6 text-[#557269]"><CheckCircle2 className="mb-3 text-[#39745a]" />{t('Your workspace has been created. Connect a channel when you are ready to start receiving conversations.')}</div>}<div className="mt-8 flex justify-end"><Button onClick={() => void next()} disabled={busy || (step === 1 && !businessName.trim())}>{t(step < 3 ? 'Continue' : 'Open workspace')} <ArrowRight size={15} /></Button></div></div></div></div>;
}

function WorkspaceHomePage() {
  const { t } = useLanguage();
  const context = useAuth().workspace;
  const counts = context?.counts;
  return <Shell><PageHeading eyebrow="Workspace overview" title="Good morning." description="Real activity from your workspace appears here." /><div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4"><MetricCard label={t('Conversations')} value={String(counts?.conversations || 0)} change="" detail={t('Connect a channel to begin')} icon={MessageSquareText} /><MetricCard label={t('New leads')} value={String(counts?.leads || 0)} change="" detail={t('Connect a channel to begin')} icon={TrendingUp} tone="gold" /><MetricCard label={t('Appointments booked')} value={String(counts?.appointments || 0)} change="" detail={t('Connect a channel to begin')} icon={CalendarCheck2} tone="blue" /><MetricCard label={t('Orders')} value={String(counts?.orders || 0)} change="" detail={t('Connect a channel to begin')} icon={FileText} /></div><div className="mt-6 grid gap-5 xl:grid-cols-[1.4fr_1fr]"><section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5"><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">{t('Your next conversations')}</h2><div className="mt-5 rounded-xl border border-dashed border-[#cfdccf] bg-[#f3f7ee] p-8 text-center"><MessageCircle className="mx-auto text-[#6da883]" size={22} /><p className="mt-3 text-xs font-bold text-[#557269]">{t('Your shared inbox is waiting for a channel')}</p><Link href="/app/channels" className="mt-3 inline-flex items-center gap-1 text-[11px] font-bold text-[#b66c43]">{t('Connect a channel')} <ArrowRight size={13} /></Link></div></section><section className="rounded-2xl border border-[#dce5d9] bg-[#e8f2e4] p-5"><div className="text-[10px] font-bold uppercase text-[#628570]">{t('Assistant health')}</div><h2 className="mt-3 font-display text-[20px] font-extrabold text-[#28574d]">{t(context?.assistant?.status || 'PAUSED')}</h2><p className="mt-3 text-xs text-[#658477]">{t('Ready to be trained.')}</p></section></div></Shell>;
}

function EmptyWorkspacePage({ title, eyebrow, description, countKey, icon: Icon }: { title: string; eyebrow: string; description: string; countKey?: keyof WorkspaceContextData['counts']; icon: React.ElementType }) {
  const { t } = useLanguage();
  const context = useAuth().workspace;
  const count = countKey ? context?.counts[countKey] || 0 : 0;
  return <Shell><PageHeading eyebrow={eyebrow} title={title} description={description} /><div className="rounded-2xl border border-dashed border-[#d7dfd5] bg-[#f3f7ee] p-10 text-center"><Icon size={28} className="mx-auto text-[#7da189]" /><div className="mt-4 font-display text-2xl font-extrabold text-[#315f54]">{count}</div><h2 className="mt-2 font-display text-lg font-extrabold text-[#315f54]">{t('No items yet')}</h2><p className="mt-2 text-xs text-[#71857b]">{t('Real workspace data will appear here after you add it.')}</p></div></Shell>;
}

function LiveAssistantPage() {
  const { t } = useLanguage();
  const auth = useAuth();
  const [setup, setSetup] = useState<WorkspaceSetup | null>(null);
  const [state, setState] = useState<'loading' | 'ready' | 'error' | 'saving'>('loading');
  const [notice, setNotice] = useState('');
  const [form, setForm] = useState({
    personality: 'PROFESSIONAL',
    language: 'ar' as 'ar' | 'en',
    dialect: 'MODERN_STANDARD_ARABIC',
    responseStyle: 'SHORT',
    welcomeMessage: '',
    outOfScopeResponse: '',
    humanHandoffMessage: '',
    aiFailureMessage: '',
    businessInstructions: '',
  });
  const load = useCallback(async () => {
    setState('loading');
    try {
      const result = await apiRequest<WorkspaceSetup>('/workspace/setup');
      setSetup(result);
      if (result.assistant) setForm({
        personality: result.assistant.personality,
        language: result.assistant.language,
        dialect: result.assistant.dialect,
        responseStyle: result.assistant.responseStyle,
        welcomeMessage: result.assistant.welcomeMessage,
        outOfScopeResponse: result.assistant.outOfScopeResponse,
        humanHandoffMessage: result.assistant.humanHandoffMessage,
        aiFailureMessage: result.assistant.aiFailureMessage,
        businessInstructions: result.assistant.businessInstructions,
      });
      setState('ready');
    } catch {
      setState('error');
    }
  }, []);
  useEffect(() => { void load(); }, [load]);
  const save = async () => {
    setState('saving');
    setNotice('');
    try {
      await apiRequest('/workspace/assistant', { method: 'PATCH', body: JSON.stringify(form) });
      await Promise.all([load(), auth.refresh()]);
      setNotice('Assistant settings saved.');
    } catch (reason) {
      setNotice(reason instanceof Error ? reason.message : 'Unable to save assistant settings.');
      setState('ready');
    }
  };
  const activate = async () => {
    setState('saving');
    setNotice('');
    try {
      await apiRequest('/workspace/activate', { method: 'POST' });
      await Promise.all([load(), auth.refresh()]);
      setNotice('Assistant activated. Incoming WhatsApp messages can now receive approved automatic replies.');
    } catch (reason) {
      setNotice(reason instanceof Error ? reason.message : 'The assistant could not be activated.');
      setState('ready');
    }
  };
  const pause = async () => {
    setState('saving');
    try {
      await apiRequest('/workspace/pause', { method: 'POST' });
      await Promise.all([load(), auth.refresh()]);
      setNotice('Assistant paused. Incoming messages will still be stored, but no automatic replies will be sent.');
    } catch (reason) {
      setNotice(reason instanceof Error ? reason.message : 'The assistant could not be paused.');
      setState('ready');
    }
  };
  if (state === 'loading') return <Shell><div className="rounded-2xl border border-dashed p-10 text-center text-xs font-bold text-[#6e8579]">{t('Loading workspace settings…')}</div></Shell>;
  if (state === 'error' || !setup) return <Shell><div className="rounded-2xl border border-[#e9c5be] bg-[#fdf3f0] p-8 text-center"><AlertCircle className="mx-auto text-[#a25243]" /><p className="mt-3 text-xs font-bold text-[#a25243]">{t('Could not connect to the server.')}</p><Button className="mt-4" onClick={() => void load()}>{t('Retry')}</Button></div></Shell>;
  const active = setup.assistant?.status === 'ACTIVE';
  const whatsappConnected = setup.channels.some((item) => item.type === 'WHATSAPP' && item.status === 'CONNECTED');
  const hasReplies = setup.faq.some((item) => item.enabled) || setup.autoReplies.some((item) => item.enabled);
  const readiness = [
    { label: 'Business profile', ready: Boolean(setup.profile?.businessName && setup.profile.activityType) },
    { label: 'Verified WhatsApp', ready: whatsappConnected },
    { label: 'Enabled FAQ or auto-reply', ready: hasReplies },
  ];
  const field = (key: keyof typeof form, placeholder: string, multiline = false) => multiline
    ? <textarea value={form[key]} onChange={(event) => setForm((value) => ({ ...value, [key]: event.target.value }))} placeholder={placeholder} className="mt-2 min-h-24 w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3 py-3 text-xs" />
    : <input value={form[key]} onChange={(event) => setForm((value) => ({ ...value, [key]: event.target.value }))} placeholder={placeholder} className="mt-2 w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3 py-3 text-xs" />;
  return <Shell><PageHeading eyebrow="Automation" title="AI assistant" description="Configure the assistant, save its boundaries, then activate it only when the verified WhatsApp channel and approved replies are ready." action={<div className="flex gap-2"><Button variant="secondary" onClick={() => void save()} disabled={state === 'saving'}><Save size={14} />Save settings</Button>{active ? <Button variant="danger" onClick={() => void pause()} disabled={state === 'saving'}><Pause size={14} />Pause assistant</Button> : <Button onClick={() => void activate()} disabled={state === 'saving' || !readiness.every((item) => item.ready)}><Play size={14} />Activate assistant</Button>}</div>} />
    {notice && <div role="status" className="mb-5 rounded-xl border border-[#d9e6d6] bg-[#e8f2e4] px-4 py-3 text-xs font-bold text-[#39745a]">{t(notice)}</div>}
    <div className="grid gap-5 xl:grid-cols-[.8fr_1.2fr]">
      <section className="rounded-2xl border border-[#dce5d9] bg-[#e8f2e4] p-5"><div className="flex items-center gap-3"><div className="grid size-11 place-items-center rounded-xl bg-[#cae3ca] text-[#2d7054]"><Bot size={21} /></div><div><div className="text-[10px] font-bold uppercase tracking-wider text-[#628570]">Assistant status</div><div className="mt-1 font-display text-2xl font-extrabold text-[#28574d]">{active ? 'ACTIVE' : 'PAUSED'}</div></div></div><p className="mt-4 text-xs leading-5 text-[#658477]">{active ? 'The bot is listening for incoming WhatsApp messages and will only use enabled FAQ and auto-reply content.' : 'The bot is paused. Messages are stored in the inbox, but automatic responses are disabled.'}</p><div className="mt-5 border-t border-[#d1e2d0] pt-4"><div className="text-[10px] font-bold uppercase tracking-wider text-[#628570]">Activation checklist</div><div className="mt-3 space-y-2">{readiness.map((item) => <div key={item.label} className="flex items-center gap-2 text-xs font-bold text-[#557269]">{item.ready ? <CheckCircle2 size={15} className="text-[#39745a]" /> : <AlertCircle size={15} className="text-[#b66c43]" />}{item.label}</div>)}</div></div></section>
      <section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5"><div className="grid gap-4 md:grid-cols-2"><label className="text-[11px] font-bold uppercase tracking-wider text-[#889890]">Personality{field('personality', 'Professional')}</label><label className="text-[11px] font-bold uppercase tracking-wider text-[#889890]">Language<select value={form.language} onChange={(event) => setForm((value) => ({ ...value, language: event.target.value as 'ar' | 'en' }))} className="mt-2 w-full rounded-xl border border-[#e2dcd1] bg-[#f7f4eb] px-3 py-3 text-xs"><option value="ar">Arabic</option><option value="en">English</option></select></label><label className="text-[11px] font-bold uppercase tracking-wider text-[#889890] md:col-span-2">Welcome message{field('welcomeMessage', 'Optional greeting sent in approved flows.', true)}</label><label className="text-[11px] font-bold uppercase tracking-wider text-[#889890]">Out-of-scope response{field('outOfScopeResponse', 'Tell customers what the assistant cannot answer.', true)}</label><label className="text-[11px] font-bold uppercase tracking-wider text-[#889890]">Human handoff message{field('humanHandoffMessage', 'Tell customers when a team member will help.', true)}</label><label className="text-[11px] font-bold uppercase tracking-wider text-[#889890] md:col-span-2">Business instructions{field('businessInstructions', 'Boundaries, tone, and information the assistant must follow.', true)}</label></div></section>
    </div>
  </Shell>;
}

function AdminPage({ section = 'Overview' }: { section?: string }) {
  return <Shell><PageHeading eyebrow="Super admin" title={section} description="Platform-level controls for workspaces, users, billing, and operational settings." action={<Button><Download size={14} />Export</Button>} /><div className="grid gap-4 md:grid-cols-4"><MetricCard label="Workspaces" value="—" change="—" detail="Connect production data" icon={BriefcaseBusiness} /><MetricCard label="Active channels" value="—" change="—" detail="Connect production data" icon={Wifi} tone="blue" /><MetricCard label="Monthly revenue" value="—" change="—" detail="Connect billing data" icon={WalletCards} tone="gold" /><MetricCard label="Open incidents" value="—" change="—" detail="No feed connected" icon={AlertCircle} /></div><div className="mt-5 rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="flex items-center gap-3"><div className="grid size-10 place-items-center rounded-xl bg-[#f4e4c6] text-[#98692c]"><Settings2 size={18} /></div><div><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">Production data connection required</h2><p className="mt-1 text-xs leading-5 text-[#82938b]">This admin surface is ready for the Express, Prisma, PostgreSQL, WhatsApp, and Ziina services from the source architecture. It does not claim live operational data until those services are connected.</p></div></div></div></Shell>;
}

function LegacyWorkspaceHomePage() {
  return <Shell><PageHeading eyebrow="Workspace overview" title="Good morning." description="See the conversations, follow-ups, leads, and appointments that need attention next." action={<Button><Sparkles size={15} />Open daily brief</Button>} /><div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4"><MetricCard label="Conversations" value="—" change="—" detail="Connect a channel to begin" icon={MessageSquareText} /><MetricCard label="Resolved by assistant" value="—" change="—" detail="Available after setup" icon={CheckCircle2} tone="blue" /><MetricCard label="New leads" value="—" change="—" detail="Available after setup" icon={TrendingUp} tone="gold" /><MetricCard label="Appointments booked" value="—" change="—" detail="Available after setup" icon={CalendarCheck2} /></div><div className="mt-6 grid gap-5 xl:grid-cols-[1.4fr_1fr]"><section className="rounded-2xl border border-[#e3ddd2] bg-[#fbf9f3] p-5 shadow-[var(--shadow-soft)]"><div className="mb-5 flex items-center justify-between"><div><h2 className="font-display text-[16px] font-extrabold text-[#315f54]">Your next conversations</h2><p className="mt-1 text-[11px] text-[#8a9a92]">Connect WhatsApp or Instagram to see live activity here.</p></div><Inbox size={18} className="text-[#8ba397]" /></div><div className="rounded-xl border border-dashed border-[#cfdccf] bg-[#f3f7ee] p-8 text-center"><MessageCircle className="mx-auto text-[#6da883]" size={22} /><p className="mt-3 text-xs font-bold text-[#557269]">Your shared inbox is waiting for a channel</p><Link href="/app/channels" className="mt-3 inline-flex items-center gap-1 text-[11px] font-bold text-[#b66c43]">Connect a channel <ArrowRight size={13} /></Link></div></section><section className="rounded-2xl border border-[#dce5d9] bg-[#e8f2e4] p-5"><div className="mb-4 flex items-center gap-2"><span className="grid size-8 place-items-center rounded-lg bg-[#cae3ca] text-[#2d7054]"><Bot size={15} /></span><span className="text-[10px] font-bold uppercase tracking-[.14em] text-[#628570]">Assistant health</span></div><h2 className="font-display text-[20px] font-extrabold tracking-[-.04em] text-[#28574d]">Ready to be trained.</h2><p className="mt-3 text-xs leading-5 text-[#658477]">Add approved FAQs, tone guidance, and handoff rules before turning on automated replies.</p><Link href="/app/training" className="mt-5 inline-flex items-center gap-1 text-[11px] font-bold text-[#2d7054]">Open training <ArrowUpRight size={13} /></Link></section></div></Shell>;
}

function ContactsPageV2() {
  return <WorkspaceModulePage eyebrow="People & relationships" title="Contacts" description="Organise the people and businesses your team is building relationships with." icon={Users} action="Add contact" items={[{ name: 'Contact directory', detail: 'Contacts from connected channels will appear here with conversation context.', status: 'Ready' }, { name: 'Segments', detail: 'Create reusable groups for leads, customers, and campaign audiences.', status: 'Ready' }, { name: 'Import contacts', detail: 'Bring an existing contact list into your workspace securely.', status: 'Ready' }]} />;
}

function AnalyticsPageV2() {
  return <Shell><PageHeading eyebrow="Signals & learning" title="Analytics" description="Understand what is working across conversations, channels, leads, and campaigns." action={<Button variant="secondary"><Download size={14} />Download</Button>} /><div className="grid gap-4 md:grid-cols-4"><MetricCard label="Total conversations" value="—" change="—" detail="Connect a channel" icon={MessageSquareText} /><MetricCard label="Resolution rate" value="—" change="—" detail="Available after setup" icon={CheckCircle2} tone="blue" /><MetricCard label="Lead conversion" value="—" change="—" detail="Available after setup" icon={TrendingUp} tone="gold" /><MetricCard label="Avg. response time" value="—" change="—" detail="Available after setup" icon={Clock3} /></div><div className="mt-5 grid gap-5 md:grid-cols-2"><WorkspaceModulePage eyebrow="Analytics" title="Conversation activity" description="Incoming, resolved, and handed-off conversation trends." icon={BarChart3} items={[{ name: 'Channel mix', detail: 'WhatsApp and Instagram comparisons will appear after connection.', status: 'Ready' }, { name: 'Top intents', detail: 'See what customers are trying to do in each conversation.', status: 'Ready' }]} /><WorkspaceModulePage eyebrow="Analytics" title="Growth signals" description="Track campaigns, lead stages, and attributed appointments." icon={TrendingUp} items={[{ name: 'Lead funnel', detail: 'Measure movement from first message to qualified lead.', status: 'Ready' }, { name: 'Campaign performance', detail: 'Compare reach, replies, and outcomes across campaigns.', status: 'Ready' }]} /></div></Shell>;
}

function LegacyRouter() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Switch><Route path="/" component={PublicMarketingPage} /><Route path="/features" component={() => <PublicInfoPage type="features" />} /><Route path="/pricing" component={() => <PublicInfoPage type="pricing" />} /><Route path="/faq" component={() => <PublicInfoPage type="faq" />} /><Route path="/contact" component={() => <PublicInfoPage type="contact" />} /><Route path="/login" component={() => <AuthPageV2 />} /><Route path="/register" component={() => <AuthPageV2 register />} /><Route path="/forgot-password" component={() => <AuthPageV2 />} /><Route path="/reset-password" component={() => <AuthPageV2 />} /><Route path="/verify-email" component={() => <AuthPageV2 />} /><Route path="/onboarding" component={OnboardingPage} /><Route path="/app" component={Overview} /><Route path="/app/inbox" component={InboxPage} /><Route path="/app/contacts" component={ContactsPage} /><Route path="/app/leads" component={LeadsPage} /><Route path="/app/appointments" component={AppointmentsPage} /><Route path="/app/ai-assistant" component={AIAssistantPageV2} /><Route path="/app/flows" component={FlowsPage} /><Route path="/app/analytics" component={AnalyticsPage} /><Route path="/app/campaigns" component={() => <WorkspaceModulePage eyebrow="Campaigns" title="Campaigns" description="Plan, send, and measure customer campaigns across your connected channels." icon={Send} action="Create campaign" items={[{ name: 'Campaign workspace', detail: 'Campaign drafts and delivery metrics will appear here once a channel is connected.', status: 'Draft' }, { name: 'Audience segments', detail: 'Build reusable audiences from contacts, leads, and conversation activity.', status: 'Ready' }, { name: 'Templates', detail: 'Manage message templates and keep outbound communication consistent.', status: 'Ready' }]} />} /><Route path="/app/training" component={() => <WorkspaceModulePage eyebrow="AI training" title="Training" description="Give the assistant approved knowledge, FAQs, and tone guidance before you publish." icon={BookOpen} action="Add source" items={[{ name: 'FAQ library', detail: 'Add approved answers for common customer questions.', status: 'Ready' }, { name: 'Knowledge sources', detail: 'Organise service details, policies, and product information.', status: 'Ready' }, { name: 'Reply examples', detail: 'Teach the tone and language your team wants to use.', status: 'Ready' }]} />} /><Route path="/app/business-profile" component={BusinessProfilePageV2} /><Route path="/app/channels" component={ChannelsPageV2} /><Route path="/app/orders" component={() => <WorkspaceModulePage eyebrow="Commerce" title="Orders" description="Keep order requests, status updates, and customer conversations connected." icon={FileText} action="Add order" items={[{ name: 'Order workspace', detail: 'Orders will appear here when your catalogue and connected channels are active.', status: 'Ready' }, { name: 'Statuses', detail: 'Configure the order states your team uses from enquiry to fulfilment.', status: 'Ready' }, { name: 'Customer updates', detail: 'Prepare clear updates for order confirmations and delivery moments.', status: 'Ready' }]} />} /><Route path="/app/catalog" component={() => <WorkspaceModulePage eyebrow="Commerce" title="Catalog" description="Create a simple catalogue your team and assistant can use in conversations." icon={Store} action="Add item" items={[{ name: 'Products and services', detail: 'Add names, prices in AED, availability, and helpful descriptions.', status: 'Ready' }, { name: 'Collections', detail: 'Organise your offering so customers can browse what fits them.', status: 'Ready' }, { name: 'Availability rules', detail: 'Keep the assistant from promising what your team cannot fulfil.', status: 'Ready' }]} />} /><Route path="/app/settings" component={SettingsPageV2} /><Route path="/app/billing" component={BillingPageV2} /><Route path="/app/bot-settings" component={AIAssistantPageV2} /><Route path="/app/business-settings" component={BusinessProfilePageV2} /><Route path="/app/whatsapp-settings" component={ChannelsPageV2} /><Route path="/admin" component={() => <AdminPage />} /><Route path="/admin/users" component={() => <AdminPage section="Users" />} /><Route path="/admin/workspaces" component={() => <AdminPage section="Workspaces" />} /><Route path="/admin/billing" component={() => <AdminPage section="Billing" />} /><Route path="/admin/settings" component={() => <AdminPage section="Settings" />} /><Route component={NotFound} /></Switch></ErrorBoundary>;
}

function Router() {
  const [location] = useLocation();
  const protect = (node: React.ReactNode) => <ProtectedRoute>{node}</ProtectedRoute>;
  return <ErrorBoundary resetKey={location}><Switch>
    <Route path="/" component={PublicMarketingPage} />
    <Route path="/features" component={() => <PublicInfoPage type="features" />} />
    <Route path="/pricing" component={() => <PublicInfoPage type="pricing" />} />
    <Route path="/faq" component={() => <PublicInfoPage type="faq" />} />
    <Route path="/contact" component={() => <PublicInfoPage type="contact" />} />
    <Route path="/login" component={() => <AuthPageV2 mode="login" />} />
    <Route path="/register" component={() => <AuthPageV2 mode="register" />} />
    <Route path="/forgot-password" component={() => <AuthPageV2 mode="forgot" />} />
    <Route path="/reset-password" component={() => <AuthPageV2 mode="reset" />} />
    <Route path="/verify-email" component={() => <AuthPageV2 mode="verify" />} />
    <Route path="/onboarding" component={() => protect(<OnboardingPage />)} />
    <Route path="/app" component={() => protect(<WorkspaceHomePage />)} />
    <Route path="/app/inbox" component={() => protect(<InboxPage />)} />
    <Route path="/app/contacts" component={() => protect(<EmptyWorkspacePage eyebrow="Workspace" title="Contacts" description="Real contacts from your workspace." countKey="contacts" icon={Users} />)} />
    <Route path="/app/leads" component={() => protect(<EmptyWorkspacePage eyebrow="Workspace" title="Leads" description="Real leads from your workspace." countKey="leads" icon={TrendingUp} />)} />
    <Route path="/app/appointments" component={() => protect(<EmptyWorkspacePage eyebrow="Workspace" title="Appointments" description="Real appointments from your workspace." countKey="appointments" icon={CalendarDays} />)} />
    <Route path="/app/ai-assistant" component={() => protect(<LiveAssistantPage />)} />
    <Route path="/app/faq" component={() => protect(<TrainingPage />)} />
    <Route path="/app/training" component={() => protect(<TrainingPage />)} />
    <Route path="/app/flows" component={() => protect(<EmptyWorkspacePage eyebrow="Automation" title="Flows" description="Published automation flows from your workspace." icon={Workflow} />)} />
    <Route path="/app/analytics" component={() => protect(<EmptyWorkspacePage eyebrow="Automation" title="Analytics" description="Analytics appear after real workspace activity." countKey="conversations" icon={BarChart3} />)} />
    <Route path="/app/campaigns" component={() => protect(<EmptyWorkspacePage eyebrow="Automation" title="Campaigns" description="Real campaigns from your workspace." icon={Send} />)} />
    <Route path="/app/business-profile" component={() => protect(<BusinessProfilePageV2 />)} />
    <Route path="/app/channels" component={() => protect(<ChannelsPageV2 />)} />
    <Route path="/app/orders" component={() => protect(<EmptyWorkspacePage eyebrow="Workspace settings" title="Orders" description="Real orders from your workspace." countKey="orders" icon={FileText} />)} />
    <Route path="/app/catalog" component={() => protect(<EmptyWorkspacePage eyebrow="Workspace settings" title="Catalog" description="Real catalog items from your workspace." icon={Store} />)} />
    <Route path="/app/settings" component={() => protect(<SettingsPageV2 />)} />
    <Route path="/app/billing" component={() => protect(<BillingPageV2 />)} />
    <Route component={NotFound} />
  </Switch></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><LanguageRuntime><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><AuthRuntime><Router /></AuthRuntime></WouterRouter></LanguageRuntime><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;