// test/channels.test.ts
import assert from "node:assert/strict";
import { createHmac as createHmac2 } from "node:crypto";
import { request as httpRequest } from "node:http";
import { after, before, beforeEach, describe, it } from "node:test";
import express from "express";

// src/routes/channels.ts
import { createHmac, timingSafeEqual, randomUUID } from "node:crypto";
import { Router } from "express";
var router = Router();
var channelsByWorkspace = /* @__PURE__ */ new Map();
var conversationsByWorkspace = /* @__PURE__ */ new Map();
var CUSTOMER_CONNECTION_ERROR = "Unable to connect this channel right now. Please try again later.";
var channelLabels = {
  whatsapp: "WhatsApp Business",
  instagram: "Instagram Direct"
};
function normalizeChannel(value) {
  if (value === "whatsapp" || value === "whatsapp-business") return "whatsapp";
  if (value === "instagram" || value === "instagram-direct") return "instagram";
  return null;
}
function workspaceIdFromRequest(req) {
  const pathWorkspaceId = req.params.workspaceId;
  return typeof pathWorkspaceId === "string" && pathWorkspaceId || req.header("x-workspace-id") || "current";
}
function canManageWorkspace(req) {
  const role = req.header("x-workspace-role");
  return !role || role === "owner";
}
function workspaceChannels(workspaceId) {
  let channels = channelsByWorkspace.get(workspaceId);
  if (!channels) {
    channels = /* @__PURE__ */ new Map([
      ["whatsapp", { channel: "whatsapp", status: "disconnected" }],
      ["instagram", { channel: "instagram", status: "disconnected" }]
    ]);
    channelsByWorkspace.set(workspaceId, channels);
  }
  return channels;
}
function healthFor(record) {
  if (record.status === "connected") {
    return {
      state: "healthy",
      verified: true,
      message: "Provider credentials verified and webhooks are ready.",
      action: null
    };
  }
  if (record.status === "failed") {
    return {
      state: "failed",
      verified: false,
      message: record.failureReason || CUSTOMER_CONNECTION_ERROR,
      action: "Try connecting again later."
    };
  }
  if (record.status === "connecting") {
    return {
      state: "connecting",
      verified: false,
      message: "Waiting for provider authorization to finish.",
      action: "Complete authorization in the provider window."
    };
  }
  if (record.status === "disconnected") {
    return {
      state: "disconnected",
      verified: false,
      message: "This channel is disconnected.",
      action: "Connect the provider to receive and send messages."
    };
  }
  return {
    state: "disconnected",
    verified: false,
    message: "Connect this channel to start receiving customer messages.",
    action: null
  };
}
function serializeChannel(record) {
  return {
    channel: record.channel,
    name: channelLabels[record.channel],
    status: record.status,
    verified: record.status === "connected",
    providerAccountId: record.providerAccountId || null,
    displayName: record.displayName || null,
    connectedAt: record.connectedAt || null,
    lastVerifiedAt: record.lastVerifiedAt || null,
    failureReason: record.failureReason || null,
    failureCode: record.failureCode || null,
    health: healthFor(record)
  };
}
function providerConfig() {
  return {
    appId: process.env.META_APP_ID,
    appSecret: process.env.META_APP_SECRET,
    redirectUri: process.env.META_REDIRECT_URI,
    graphUrl: (process.env.META_GRAPH_URL || "https://graph.facebook.com/v21.0").replace(
      /\/$/,
      ""
    )
  };
}
function setupResponse(channel) {
  const config = providerConfig();
  const result = {
    channel: serializeChannel(channel),
    connectUrl: null,
    message: CUSTOMER_CONNECTION_ERROR
  };
  if (config.appId && config.appSecret && config.redirectUri) {
    const state = randomUUID();
    channel.status = "connecting";
    channel.oauthState = state;
    channel.failureReason = void 0;
    const scopes = channel.channel === "whatsapp" ? "business_management,whatsapp_business_management,whatsapp_business_messaging" : "business_management,instagram_basic,instagram_manage_messages,pages_manage_metadata";
    const params = new URLSearchParams({
      client_id: config.appId,
      redirect_uri: config.redirectUri,
      state,
      response_type: "code",
      scope: scopes
    });
    result.connectUrl = `https://www.facebook.com/v21.0/dialog/oauth?${params.toString()}`;
    result.channel = serializeChannel(channel);
    result.message = "Continue authorization in the provider window.";
  }
  return result;
}
async function graphGet(graphUrl, path, accessToken) {
  const url = new URL(`${graphUrl}/${path.replace(/^\//, "")}`);
  url.searchParams.set("access_token", accessToken);
  const response = await fetch(url);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.error) {
    const error = payload.error;
    throw new Error(error?.message || `Meta verification returned ${response.status}.`);
  }
  return payload;
}
async function verifyMetaConnection(channel, accessToken, providerAccountId) {
  const config = providerConfig();
  if (!config.appId || !config.appSecret || !config.redirectUri) {
    throw new Error(
      "Meta provider is not configured. Add META_APP_ID, META_APP_SECRET, and META_REDIRECT_URI."
    );
  }
  const account = await graphGet(config.graphUrl, "me?fields=id,name", accessToken);
  let id = providerAccountId || (typeof account.id === "string" ? account.id : void 0);
  let displayName = typeof account.name === "string" ? account.name : void 0;
  if (channel === "whatsapp") {
    const phoneNumberId = process.env.META_WHATSAPP_PHONE_NUMBER_ID;
    if (!phoneNumberId) throw new Error("Meta did not return a WhatsApp account.");
    const phone = await graphGet(
      config.graphUrl,
      `${phoneNumberId}?fields=id,display_phone_number,verified_name`,
      accessToken
    );
    id = typeof phone.id === "string" ? phone.id : phoneNumberId;
    displayName = typeof phone.verified_name === "string" && phone.verified_name || typeof phone.display_phone_number === "string" && phone.display_phone_number || displayName;
  } else {
    const instagram = await graphGet(
      config.graphUrl,
      `${id || "me"}?fields=id,name,instagram_business_account`,
      accessToken
    );
    const businessAccount = instagram.instagram_business_account;
    id = businessAccount?.id || id;
    displayName = typeof instagram.name === "string" ? instagram.name : displayName;
  }
  if (!id) throw new Error("Meta verification did not return a provider account.");
  return { id, displayName };
}
async function exchangeCode(code) {
  const config = providerConfig();
  if (!config.appId || !config.appSecret || !config.redirectUri) {
    throw new Error(
      "Meta provider is not configured. Add META_APP_ID, META_APP_SECRET, and META_REDIRECT_URI."
    );
  }
  const url = new URL(`${config.graphUrl}/oauth/access_token`);
  url.searchParams.set("client_id", config.appId);
  url.searchParams.set("client_secret", config.appSecret);
  url.searchParams.set("redirect_uri", config.redirectUri);
  url.searchParams.set("code", code);
  const response = await fetch(url);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || !payload.access_token) {
    throw new Error(payload.error?.message || "Meta authorization code could not be exchanged.");
  }
  return payload.access_token;
}
async function connectChannel(record, code, providerAccountId, state) {
  if (!code) return setupResponse(record);
  if (!record.oauthState || state !== record.oauthState) {
    throw new Error("Invalid provider authorization state.");
  }
  const accessToken = await exchangeCode(code);
  const verified = await verifyMetaConnection(record.channel, accessToken, providerAccountId);
  record.accessToken = accessToken;
  record.providerAccountId = verified.id;
  record.displayName = verified.displayName;
  record.status = "connected";
  record.connectedAt = (/* @__PURE__ */ new Date()).toISOString();
  record.lastVerifiedAt = record.connectedAt;
  record.failureReason = void 0;
  record.failureCode = void 0;
  record.oauthState = void 0;
  return {
    channel: serializeChannel(record),
    connectUrl: null,
    message: "Provider credentials verified. The channel is ready for webhooks and messages."
  };
}
function channelOr404(workspaceId, channelValue) {
  const channel = normalizeChannel(channelValue);
  if (!channel) return null;
  return workspaceChannels(workspaceId).get(channel) || null;
}
function verifiedChannel(workspaceId, channelValue) {
  const channel = channelOr404(workspaceId, channelValue);
  if (!channel || channel.status !== "connected" || !channel.accessToken) return null;
  return channel;
}
function conversationList(workspaceId) {
  let list = conversationsByWorkspace.get(workspaceId);
  if (!list) {
    list = [];
    conversationsByWorkspace.set(workspaceId, list);
  }
  return list;
}
function findInboundMessage(conversations, channel, providerMessageId) {
  if (!providerMessageId) return null;
  for (const conversation of conversations) {
    if (conversation.channel !== channel) continue;
    const message = conversation.messages.find(
      (item) => item.from === "customer" && item.providerMessageId === providerMessageId
    );
    if (message) return { conversation, message };
  }
  return null;
}
function providerAccountIdsFromPayload(payload) {
  const ids = /* @__PURE__ */ new Set();
  if (typeof payload.object === "string" && Array.isArray(payload.entry)) {
    for (const entry of payload.entry) {
      if (typeof entry.id === "string") ids.add(entry.id);
      for (const change of entry.changes || []) {
        const value = change.value || {};
        const metadata = value.metadata;
        if (typeof metadata?.phone_number_id === "string") ids.add(metadata.phone_number_id);
      }
    }
  }
  return [...ids];
}
function workspaceForProviderPayload(channelValue, payload) {
  const channel = normalizeChannel(channelValue);
  if (!channel) return null;
  const ids = providerAccountIdsFromPayload(payload);
  for (const [workspaceId, channels] of channelsByWorkspace) {
    const record = channels.get(channel);
    if (record?.status === "connected" && record.providerAccountId && ids.includes(record.providerAccountId)) {
      return workspaceId;
    }
  }
  return null;
}
async function sendProviderMessage(record, conversation, text) {
  if (!record.accessToken || !record.providerAccountId) {
    throw new Error("The channel is not verified for outbound messages.");
  }
  const config = providerConfig();
  const recipient = conversation.contactAddress;
  const url = record.channel === "whatsapp" ? `${config.graphUrl}/${process.env.META_WHATSAPP_PHONE_NUMBER_ID || record.providerAccountId}/messages` : `${config.graphUrl}/${record.providerAccountId}/messages`;
  const body = record.channel === "whatsapp" ? { messaging_product: "whatsapp", to: recipient, type: "text", text: { body: text } } : { recipient: { id: recipient }, message: { text } };
  const response = await fetch(url, {
    method: "POST",
    headers: {
      authorization: `Bearer ${record.accessToken}`,
      "content-type": "application/json"
    },
    body: JSON.stringify(body)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.error) {
    const error = payload.error;
    throw Object.assign(
      new Error(error?.message || `Provider rejected the message (${response.status}).`),
      { code: error?.code ? String(error.code) : "provider_rejected" }
    );
  }
  return payload.messages?.[0]?.id || payload.message_id || randomUUID();
}
function assertWebhookSignature(req) {
  const secret = process.env.META_APP_SECRET;
  if (!secret) return true;
  const signature2 = req.header("x-hub-signature-256") || req.header("x-webhook-signature");
  const rawBody = req.rawBody;
  if (!signature2 || !rawBody) return false;
  const expected = `sha256=${createHmac("sha256", secret).update(rawBody).digest("hex")}`;
  const provided = Buffer.from(signature2);
  const expectedBuffer = Buffer.from(expected);
  return provided.length === expectedBuffer.length && timingSafeEqual(provided, expectedBuffer);
}
function eventChannel(workspaceId, value) {
  return normalizeChannel(value) || null;
}
function normalizeProviderPayload(channelValue, payload) {
  if (Array.isArray(payload.events)) {
    return payload.events;
  }
  const channel = normalizeChannel(channelValue);
  const entries = Array.isArray(payload.entry) ? payload.entry : [];
  if (!channel || entries.length === 0) return [payload];
  const events = [];
  for (const entry of entries) {
    if (channel === "whatsapp") {
      const changes = Array.isArray(entry.changes) ? entry.changes : [];
      for (const change of changes) {
        const value = change.value || {};
        const contacts = Array.isArray(value.contacts) ? value.contacts : [];
        const profile = contacts[0] || {};
        const profileData = profile.profile || {};
        const messages = Array.isArray(value.messages) ? value.messages : [];
        for (const message of messages) {
          const textData = message.text || message.button || {};
          const seconds = Number(message.timestamp);
          events.push({
            event: "message.received",
            providerMessageId: message.id,
            providerConversationId: value.metadata?.phone_number_id,
            from: message.from,
            contactName: profileData.name || profile.wa_id || message.from,
            text: textData.body || textData.text,
            timestamp: Number.isFinite(seconds) ? new Date(seconds * 1e3).toISOString() : void 0
          });
        }
        const statuses = Array.isArray(value.statuses) ? value.statuses : [];
        for (const status of statuses) {
          const statusName = status.status === "delivered" || status.status === "read" ? `message.${status.status}` : "message.failed";
          events.push({
            event: statusName,
            providerMessageId: status.id,
            error: status.errors?.[0]?.title
          });
        }
      }
    } else {
      const messages = Array.isArray(entry.messaging) ? entry.messaging : [];
      for (const messaging of messages) {
        const message = messaging.message || {};
        if (message.is_echo) continue;
        const seconds = Number(messaging.timestamp);
        events.push({
          event: "message.received",
          providerMessageId: message.mid,
          providerConversationId: messaging.recipient?.id,
          from: messaging.sender?.id,
          contactName: messaging.sender?.id,
          text: message.text,
          timestamp: Number.isFinite(seconds) ? new Date(seconds).toISOString() : void 0
        });
      }
    }
  }
  return events;
}
function ingestEvent(workspaceId, channelValue, event) {
  const channel = eventChannel(workspaceId, channelValue);
  if (!channel) throw new Error("Unsupported channel.");
  const channelRecord = verifiedChannel(workspaceId, channel);
  if (!channelRecord) throw new Error(`${channelLabels[channel]} is not verified.`);
  const eventType = typeof event.event === "string" ? event.event : "message.received";
  const providerMessageId = typeof event.providerMessageId === "string" ? event.providerMessageId : void 0;
  const conversations = conversationList(workspaceId);
  if (eventType === "message.received") {
    const existing = findInboundMessage(conversations, channel, providerMessageId);
    if (existing) return existing.conversation;
    const contactAddress = typeof event.from === "string" ? event.from : typeof event.senderId === "string" ? event.senderId : "";
    const text = typeof event.text === "string" ? event.text.trim() : "";
    if (!contactAddress || !text) throw new Error("Inbound message requires from and text.");
    const now = typeof event.timestamp === "string" ? event.timestamp : (/* @__PURE__ */ new Date()).toISOString();
    let conversation = conversations.find(
      (item) => item.channel === channel && item.contactAddress === contactAddress && item.status !== "resolved"
    );
    if (!conversation) {
      conversation = {
        id: randomUUID(),
        channel,
        providerConversationId: typeof event.providerConversationId === "string" ? event.providerConversationId : void 0,
        contactName: typeof event.contactName === "string" && event.contactName ? event.contactName : contactAddress,
        contactAddress,
        status: "open",
        handoff: "assistant",
        updatedAt: now,
        messages: []
      };
      conversations.unshift(conversation);
    }
    conversation.messages.push({
      id: randomUUID(),
      providerMessageId,
      from: "customer",
      text,
      timestamp: now
    });
    conversation.updatedAt = now;
    return conversation;
  }
  const deliveryStatus = eventType.endsWith("delivered") ? "delivered" : eventType.endsWith("read") ? "read" : "failed";
  const message = conversations.flatMap((conversation) => conversation.messages).find((item) => item.providerMessageId === providerMessageId);
  if (message) {
    message.deliveryStatus = deliveryStatus;
    if (deliveryStatus === "failed" && typeof event.error === "string") {
      message.failureReason = event.error;
    }
  }
  if (deliveryStatus === "failed") {
    channelRecord.status = "failed";
    channelRecord.failureReason = typeof event.error === "string" ? event.error : "The provider reported a delivery failure.";
    channelRecord.failureCode = "provider_delivery_failed";
  }
  return null;
}
async function handleWebhook(req, workspaceId, channelValue) {
  if (!assertWebhookSignature(req)) {
    return { status: 401, body: { error: "invalid_webhook_signature" } };
  }
  const payload = req.body;
  const payloadWorkspace = workspaceForProviderPayload(channelValue, payload);
  const providerAccountIds = providerAccountIdsFromPayload(payload);
  if (providerAccountIds.length > 0 && (!payloadWorkspace || payloadWorkspace !== workspaceId)) {
    return {
      status: 409,
      body: {
        error: "workspace_channel_mismatch",
        message: "The webhook payload does not belong to this workspace."
      }
    };
  }
  const events = normalizeProviderPayload(channelValue, payload);
  let accepted = 0;
  try {
    for (const event of events) {
      ingestEvent(workspaceId, channelValue, event);
      accepted += 1;
    }
  } catch (error) {
    return {
      status: 409,
      body: {
        error: "channel_not_ready",
        message: error instanceof Error ? error.message : "Channel is not ready."
      }
    };
  }
  return { status: 202, body: { accepted } };
}
router.get("/workspaces/:workspaceId/channels", (req, res) => {
  const channels = [...workspaceChannels(workspaceIdFromRequest(req)).values()].map(serializeChannel);
  res.json({ channels });
});
router.post("/workspaces/:workspaceId/channels/:channel/connect", async (req, res) => {
  const workspaceId = workspaceIdFromRequest(req);
  if (!canManageWorkspace(req)) return res.status(403).json({ error: "workspace_owner_required" });
  const channel = channelOr404(workspaceId, req.params.channel);
  if (!channel) return res.status(404).json({ error: "unsupported_channel" });
  try {
    return res.json(
      await connectChannel(
        channel,
        typeof req.body?.code === "string" ? req.body.code : void 0,
        typeof req.body?.providerAccountId === "string" ? req.body.providerAccountId : void 0,
        typeof req.body?.state === "string" ? req.body.state : void 0
      )
    );
  } catch (error) {
    req.log?.error({ err: error, workspaceId, channel: channel.channel }, "Channel connection failed");
    channel.status = "failed";
    channel.failureReason = CUSTOMER_CONNECTION_ERROR;
    channel.failureCode = "provider_verification_failed";
    return res.status(502).json({
      error: channel.failureCode,
      message: channel.failureReason,
      channel: serializeChannel(channel)
    });
  }
});
router.get("/workspaces/:workspaceId/channels/:channel/callback", async (req, res) => {
  const workspaceId = workspaceIdFromRequest(req);
  const channel = channelOr404(workspaceId, req.params.channel);
  const code = typeof req.query.code === "string" ? req.query.code : void 0;
  const state = typeof req.query.state === "string" ? req.query.state : void 0;
  if (!channel) return res.status(404).json({ error: "unsupported_channel" });
  if (!code) return res.status(400).json({ error: "provider_code_required" });
  try {
    return res.json(await connectChannel(channel, code, void 0, state));
  } catch (error) {
    req.log?.error({ err: error, workspaceId, channel: channel.channel }, "Channel callback failed");
    channel.status = "failed";
    channel.failureReason = CUSTOMER_CONNECTION_ERROR;
    channel.failureCode = "provider_verification_failed";
    return res.status(502).json({
      error: channel.failureCode,
      message: channel.failureReason,
      channel: serializeChannel(channel)
    });
  }
});
router.get("/oauth/meta/callback", async (req, res) => {
  const code = typeof req.query.code === "string" ? req.query.code : void 0;
  const state = typeof req.query.state === "string" ? req.query.state : void 0;
  if (!code || !state) return res.status(400).json({ error: "provider_code_and_state_required" });
  for (const channels of channelsByWorkspace.values()) {
    const channel = [...channels.values()].find((item) => item.oauthState === state);
    if (!channel) continue;
    try {
      return res.json(await connectChannel(channel, code, void 0, state));
    } catch (error) {
      req.log?.error({ err: error, channel: channel.channel }, "Meta callback failed");
      channel.status = "failed";
      channel.failureReason = CUSTOMER_CONNECTION_ERROR;
      channel.failureCode = "provider_verification_failed";
      return res.status(502).json({
        error: channel.failureCode,
        message: channel.failureReason,
        channel: serializeChannel(channel)
      });
    }
  }
  return res.status(400).json({ error: "invalid_provider_state" });
});
router.delete("/workspaces/:workspaceId/channels/:channel", (req, res) => {
  const workspaceId = workspaceIdFromRequest(req);
  if (!canManageWorkspace(req)) return res.status(403).json({ error: "workspace_owner_required" });
  const channel = channelOr404(workspaceId, req.params.channel);
  if (!channel) return res.status(404).json({ error: "unsupported_channel" });
  channel.status = "disconnected";
  channel.providerAccountId = void 0;
  channel.displayName = void 0;
  channel.accessToken = void 0;
  channel.connectedAt = void 0;
  channel.lastVerifiedAt = void 0;
  channel.oauthState = void 0;
  channel.failureReason = void 0;
  channel.failureCode = void 0;
  return res.status(204).send();
});
router.get("/workspaces/:workspaceId/conversations", (req, res) => {
  const workspaceId = workspaceIdFromRequest(req);
  const channel = typeof req.query.channel === "string" ? normalizeChannel(req.query.channel) : null;
  const conversations = conversationList(workspaceId).filter((item) => !channel || item.channel === channel).map((item) => ({ ...item, messages: item.messages.map((message) => ({ ...message })) }));
  res.json({ conversations });
});
router.post("/workspaces/:workspaceId/conversations/:conversationId/replies", async (req, res) => {
  const workspaceId = workspaceIdFromRequest(req);
  const text = typeof req.body?.text === "string" ? req.body.text.trim() : "";
  if (!text) return res.status(400).json({ error: "message_text_required" });
  const conversation = conversationList(workspaceId).find(
    (item) => item.id === req.params.conversationId
  );
  if (!conversation) return res.status(404).json({ error: "conversation_not_found" });
  const channel = verifiedChannel(workspaceId, conversation.channel);
  if (!channel) {
    return res.status(409).json({
      error: "channel_not_ready",
      message: `${channelLabels[conversation.channel]} must be verified before replying.`
    });
  }
  try {
    const providerMessageId = await sendProviderMessage(channel, conversation, text);
    const message = {
      id: randomUUID(),
      providerMessageId,
      from: "team",
      text,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      deliveryStatus: "sent"
    };
    conversation.messages.push(message);
    conversation.updatedAt = message.timestamp;
    conversation.handoff = "team";
    return res.status(201).json({ message, conversation });
  } catch (error) {
    req.log?.error({ err: error, workspaceId, conversationId: conversation.id }, "Provider reply failed");
    channel.status = "failed";
    channel.failureReason = "The message could not be sent right now.";
    channel.failureCode = "provider_send_failed";
    return res.status(502).json({
      error: "provider_send_failed",
      message: "The message could not be sent right now. Please try again later.",
      action: "Try again later."
    });
  }
});
router.post("/workspaces/:workspaceId/conversations/:conversationId/handoff", async (req, res) => {
  const workspaceId = workspaceIdFromRequest(req);
  const conversation = conversationList(workspaceId).find(
    (item) => item.id === req.params.conversationId
  );
  if (!conversation) return res.status(404).json({ error: "conversation_not_found" });
  if (!verifiedChannel(workspaceId, conversation.channel)) {
    return res.status(409).json({
      error: "channel_not_ready",
      message: `${channelLabels[conversation.channel]} must be verified before handoff.`
    });
  }
  const text = typeof req.body?.text === "string" ? req.body.text.trim() : "";
  if (text) {
    const channel = verifiedChannel(workspaceId, conversation.channel);
    try {
      const providerMessageId = await sendProviderMessage(channel, conversation, text);
      const message = {
        id: randomUUID(),
        providerMessageId,
        from: "assistant",
        text,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        deliveryStatus: "sent"
      };
      conversation.messages.push(message);
      conversation.updatedAt = message.timestamp;
    } catch (error) {
      req.log?.error({ err: error, workspaceId, conversationId: conversation.id }, "Provider handoff failed");
      channel.status = "failed";
      channel.failureReason = "The handoff could not be completed right now.";
      channel.failureCode = "provider_send_failed";
      return res.status(502).json({
        error: "provider_send_failed",
        message: "The handoff could not be completed right now. Please try again later.",
        action: "Try again later."
      });
    }
  }
  conversation.handoff = "team";
  conversation.status = "open";
  return res.json({ conversation });
});
router.get("/webhooks/:channel", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];
  if (mode === "subscribe" && typeof token === "string" && token === process.env.META_WEBHOOK_VERIFY_TOKEN && typeof challenge === "string") {
    return res.status(200).send(challenge);
  }
  return res.status(403).send("Webhook verification failed.");
});
router.post("/workspaces/:workspaceId/webhooks/:channel", async (req, res) => {
  const result = await handleWebhook(req, workspaceIdFromRequest(req), req.params.channel);
  res.status(result.status).json(result.body);
});
router.post("/webhooks/:channel", async (req, res) => {
  const workspaceId = workspaceForProviderPayload(req.params.channel, req.body) || "current";
  const result = await handleWebhook(req, workspaceId, req.params.channel);
  res.status(result.status).json(result.body);
});
var channels_default = router;

// test/channels.test.ts
var originalEnv = /* @__PURE__ */ new Map();
var metaEnvKeys = [
  "META_APP_ID",
  "META_APP_SECRET",
  "META_REDIRECT_URI",
  "META_GRAPH_URL",
  "META_WEBHOOK_VERIFY_TOKEN",
  "META_WHATSAPP_PHONE_NUMBER_ID"
];
var server;
var baseUrl;
var app = express();
app.use(
  express.json({
    verify: (req, _res, buffer) => {
      req.rawBody = Buffer.from(buffer);
    }
  })
);
app.use("/api", channels_default);
function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" }
  });
}
function request(path, options = {}) {
  const body = options.body === void 0 ? "" : typeof options.body === "string" ? options.body : JSON.stringify(options.body);
  const url = new URL(path, baseUrl);
  return new Promise((resolve, reject) => {
    const requestOptions = {
      method: options.method || "GET",
      hostname: url.hostname,
      port: Number(url.port),
      path: `${url.pathname}${url.search}`,
      headers: {
        ...body ? { "content-type": "application/json", "content-length": Buffer.byteLength(body) } : {},
        ...options.headers || {}
      }
    };
    const outgoing = httpRequest(requestOptions, (response) => {
      const chunks = [];
      response.on("data", (chunk) => chunks.push(chunk));
      response.on("end", () => {
        const responseBody = Buffer.concat(chunks).toString("utf8");
        let json = {};
        try {
          json = JSON.parse(responseBody);
        } catch {
        }
        resolve({ status: response.statusCode || 0, body: responseBody, json });
      });
    });
    outgoing.on("error", reject);
    if (body) outgoing.write(body);
    outgoing.end();
  });
}
function signature(body) {
  return `sha256=${createHmac2("sha256", process.env.META_APP_SECRET || "").update(body).digest("hex")}`;
}
function signedWebhook(path, payload, extraHeaders = {}) {
  const body = JSON.stringify(payload);
  return request(path, {
    method: "POST",
    body,
    headers: { "x-hub-signature-256": signature(body), ...extraHeaders }
  });
}
async function beginConnect(workspaceId, channel) {
  const response = await request(`/api/workspaces/${workspaceId}/channels/${channel}/connect`, {
    method: "POST",
    body: {}
  });
  assert.equal(response.status, 200);
  assert.equal(response.json.channel && response.json.channel.status, "connecting");
  const connectUrl = new URL(String(response.json.connectUrl));
  return connectUrl.searchParams.get("state");
}
async function connectChannel2(workspaceId, channel, providerAccountId) {
  if (channel === "whatsapp") {
    process.env.META_WHATSAPP_PHONE_NUMBER_ID = providerAccountId;
  }
  const state = await beginConnect(workspaceId, channel);
  globalThis.fetch = async (input) => {
    const url = new URL(String(input));
    if (url.pathname.endsWith("/oauth/access_token")) {
      return jsonResponse({ access_token: `access-token-${workspaceId}` });
    }
    if (url.pathname.endsWith("/me")) {
      return jsonResponse({
        id: `page-${workspaceId}`,
        name: `${channel} ${workspaceId}`
      });
    }
    if (channel === "whatsapp" && url.pathname.endsWith(`/${providerAccountId}`)) {
      return jsonResponse({
        id: providerAccountId,
        verified_name: `WhatsApp ${workspaceId}`
      });
    }
    if (channel === "instagram" && url.pathname.endsWith(`/page-${workspaceId}`)) {
      return jsonResponse({
        id: `page-${workspaceId}`,
        name: `Instagram ${workspaceId}`,
        instagram_business_account: { id: providerAccountId }
      });
    }
    throw new Error(`Unexpected Meta request: ${url}`);
  };
  const response = await request(`/api/workspaces/${workspaceId}/channels/${channel}/connect`, {
    method: "POST",
    body: { code: `code-${workspaceId}`, state }
  });
  assert.equal(response.status, 200);
  assert.equal(response.json.channel && response.json.channel.status, "connected");
  return response;
}
function whatsappPayload(providerAccountId, from, messageId, text = "Hello from WhatsApp") {
  return {
    object: "whatsapp_business_account",
    entry: [
      {
        id: `business-${providerAccountId}`,
        changes: [
          {
            field: "messages",
            value: {
              metadata: { phone_number_id: providerAccountId },
              contacts: [{ wa_id: from, profile: { name: "WhatsApp customer" } }],
              messages: [
                {
                  id: messageId,
                  from,
                  timestamp: "1710000000",
                  type: "text",
                  text: { body: text }
                }
              ]
            }
          }
        ]
      }
    ]
  };
}
function instagramPayload(providerAccountId, senderId, messageId) {
  return {
    object: "instagram",
    entry: [
      {
        id: providerAccountId,
        messaging: [
          {
            sender: { id: senderId },
            recipient: { id: providerAccountId },
            timestamp: 171e10,
            message: { mid: messageId, text: "Hello from Instagram" }
          }
        ]
      }
    ]
  };
}
before(async () => {
  for (const key of metaEnvKeys) originalEnv.set(key, process.env[key]);
  process.env.META_APP_ID = "test-meta-app";
  process.env.META_APP_SECRET = "test-meta-secret";
  process.env.META_REDIRECT_URI = "https://example.test/api/oauth/meta/callback";
  process.env.META_GRAPH_URL = "https://meta.test/v21.0";
  process.env.META_WEBHOOK_VERIFY_TOKEN = "test-webhook-token";
  server = app.listen(0);
  await new Promise((resolve) => server.once("listening", resolve));
  const address = server.address();
  assert(address && typeof address !== "string");
  baseUrl = `http://127.0.0.1:${address.port}`;
});
beforeEach(() => {
  process.env.META_WHATSAPP_PHONE_NUMBER_ID = "test-phone";
});
after(async () => {
  for (const key of metaEnvKeys) {
    const value = originalEnv.get(key);
    if (value === void 0) delete process.env[key];
    else process.env[key] = value;
  }
  await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
});
describe("Meta channel connection safety", () => {
  it("completes OAuth through the callback and consumes the authorization state", async () => {
    const state = await beginConnect("oauth-success", "whatsapp");
    process.env.META_WHATSAPP_PHONE_NUMBER_ID = "oauth-phone";
    globalThis.fetch = async (input) => {
      const url = new URL(String(input));
      if (url.pathname.endsWith("/oauth/access_token")) return jsonResponse({ access_token: "oauth-token" });
      if (url.pathname.endsWith("/me")) return jsonResponse({ id: "oauth-page", name: "OAuth business" });
      if (url.pathname.endsWith("/oauth-phone")) return jsonResponse({ id: "oauth-phone", verified_name: "Verified line" });
      throw new Error(`Unexpected Meta request: ${url}`);
    };
    const callback = await request(`/api/oauth/meta/callback?code=oauth-code&state=${encodeURIComponent(state)}`);
    assert.equal(callback.status, 200);
    assert.equal(callback.json.channel.status, "connected");
    assert.equal(callback.json.channel.providerAccountId, "oauth-phone");
    const replay = await request(`/api/oauth/meta/callback?code=oauth-code&state=${encodeURIComponent(state)}`);
    assert.equal(replay.status, 400);
    assert.equal(replay.json.error, "invalid_provider_state");
  });
  it("rejects an invalid OAuth state and records the failed connection", async () => {
    const state = await beginConnect("oauth-invalid-state", "whatsapp");
    const response = await request("/api/workspaces/oauth-invalid-state/channels/whatsapp/connect", {
      method: "POST",
      body: { code: "code", state: `${state}-wrong` }
    });
    assert.equal(response.status, 502);
    assert.equal(response.json.error, "provider_verification_failed");
    assert.equal(
      response.json.message,
      "Unable to connect this channel right now. Please try again later."
    );
    assert.equal(response.json.channel.status, "failed");
  });
  it("surfaces provider verification failures as failed channel health", async () => {
    const state = await beginConnect("oauth-provider-failure", "instagram");
    globalThis.fetch = async (input) => {
      const url = new URL(String(input));
      if (url.pathname.endsWith("/oauth/access_token")) return jsonResponse({ access_token: "bad-token" });
      return jsonResponse({ error: { message: "Token was rejected by Meta" } }, 401);
    };
    const response = await request("/api/workspaces/oauth-provider-failure/channels/instagram/connect", {
      method: "POST",
      body: { code: "code", state }
    });
    assert.equal(response.status, 502);
    assert.equal(response.json.error, "provider_verification_failed");
    assert.equal(response.json.channel.status, "failed");
    assert.equal(
      response.json.channel.failureReason,
      "Unable to connect this channel right now. Please try again later."
    );
  });
  it("allows only an owner to disconnect a channel and clears its credentials", async () => {
    await connectChannel2("disconnect", "whatsapp", "disconnect-phone");
    const forbidden = await request("/api/workspaces/disconnect/channels/whatsapp", {
      method: "DELETE",
      headers: { "x-workspace-role": "member" }
    });
    assert.equal(forbidden.status, 403);
    assert.equal(forbidden.json.error, "workspace_owner_required");
    const disconnected = await request("/api/workspaces/disconnect/channels/whatsapp", {
      method: "DELETE",
      headers: { "x-workspace-role": "owner" }
    });
    assert.equal(disconnected.status, 204);
    const channels = await request("/api/workspaces/disconnect/channels");
    const whatsapp = channels.json.channels.find((item) => item.channel === "whatsapp");
    assert.equal(whatsapp.status, "disconnected");
    assert.equal(whatsapp.verified, false);
  });
});
describe("Meta webhook ingestion", () => {
  it("maps a native WhatsApp payload into a workspace conversation and message", async () => {
    await connectChannel2("whatsapp-inbound", "whatsapp", "whatsapp-phone");
    const response = await signedWebhook(
      "/api/webhooks/whatsapp",
      whatsappPayload("whatsapp-phone", "971500000001", "wamid-whatsapp")
    );
    assert.equal(response.status, 202);
    assert.equal(response.json.accepted, 1);
    const conversations = await request("/api/workspaces/whatsapp-inbound/conversations?channel=whatsapp");
    const conversation = conversations.json.conversations[0];
    assert.equal(conversation.contactName, "WhatsApp customer");
    assert.equal(conversation.contactAddress, "971500000001");
    assert.equal(conversation.messages[0].providerMessageId, "wamid-whatsapp");
    assert.equal(conversation.messages[0].text, "Hello from WhatsApp");
  });
  it("acknowledges retried WhatsApp and Instagram messages without duplicating them", async () => {
    const cases = [
      {
        workspaceId: "whatsapp-retry",
        channel: "whatsapp",
        providerAccountId: "whatsapp-retry-phone",
        payload: whatsappPayload("whatsapp-retry-phone", "971500000004", "wamid-retry")
      },
      {
        workspaceId: "instagram-retry",
        channel: "instagram",
        providerAccountId: "instagram-retry-business",
        payload: instagramPayload("instagram-retry-business", "instagram-retry-user", "ig-retry")
      }
    ];
    for (const testCase of cases) {
      await connectChannel2(testCase.workspaceId, testCase.channel, testCase.providerAccountId);
      const firstDelivery = await signedWebhook(
        `/api/webhooks/${testCase.channel}`,
        testCase.payload
      );
      const retryDelivery = await signedWebhook(
        `/api/webhooks/${testCase.channel}`,
        testCase.payload
      );
      assert.equal(firstDelivery.status, 202);
      assert.equal(retryDelivery.status, 202);
      assert.equal(firstDelivery.json.accepted, 1);
      assert.equal(retryDelivery.json.accepted, 1);
      const conversations = await request(
        `/api/workspaces/${testCase.workspaceId}/conversations?channel=${testCase.channel}`
      );
      const workspaceConversations = conversations.json.conversations;
      assert.equal(workspaceConversations.length, 1);
      assert.equal(workspaceConversations[0].messages.length, 1);
    }
  });
  it("maps a native Instagram payload into a workspace conversation and message", async () => {
    await connectChannel2("instagram-inbound", "instagram", "instagram-business");
    const response = await signedWebhook(
      "/api/webhooks/instagram",
      instagramPayload("instagram-business", "instagram-user", "ig-mid")
    );
    assert.equal(response.status, 202);
    assert.equal(response.json.accepted, 1);
    const conversations = await request("/api/workspaces/instagram-inbound/conversations?channel=instagram");
    const conversation = conversations.json.conversations[0];
    assert.equal(conversation.contactAddress, "instagram-user");
    assert.equal(conversation.messages[0].providerMessageId, "ig-mid");
    assert.equal(conversation.messages[0].text, "Hello from Instagram");
  });
  it("downgrades channel health on delivery failure and blocks later outbound sends", async () => {
    await connectChannel2("delivery-failure", "whatsapp", "delivery-phone");
    const inbound = await signedWebhook(
      "/api/webhooks/whatsapp",
      whatsappPayload("delivery-phone", "971500000002", "wamid-inbound")
    );
    assert.equal(inbound.status, 202);
    const conversations = await request("/api/workspaces/delivery-failure/conversations");
    const conversationId = String(conversations.json.conversations[0].id);
    globalThis.fetch = async () => jsonResponse({ messages: [{ id: "wamid-outbound" }] });
    const reply = await request(`/api/workspaces/delivery-failure/conversations/${conversationId}/replies`, {
      method: "POST",
      body: { text: "A team reply" }
    });
    assert.equal(reply.status, 201);
    const failurePayload = {
      object: "whatsapp_business_account",
      entry: [
        {
          id: "business-delivery-phone",
          changes: [
            {
              value: {
                metadata: { phone_number_id: "delivery-phone" },
                statuses: [
                  {
                    id: "wamid-outbound",
                    status: "failed",
                    errors: [{ title: "Recipient blocked messages" }]
                  }
                ]
              }
            }
          ]
        }
      ]
    };
    const failure = await signedWebhook("/api/webhooks/whatsapp", failurePayload);
    assert.equal(failure.status, 202);
    assert.equal(failure.json.accepted, 1);
    const channels = await request("/api/workspaces/delivery-failure/channels");
    const channel = channels.json.channels.find((item) => item.channel === "whatsapp");
    assert.equal(channel.status, "failed");
    assert.equal(channel.failureCode, "provider_delivery_failed");
    assert.equal(channel.failureReason, "Recipient blocked messages");
    const blocked = await request(`/api/workspaces/delivery-failure/conversations/${conversationId}/replies`, {
      method: "POST",
      body: { text: "This must not be sent" }
    });
    assert.equal(blocked.status, 409);
    assert.equal(blocked.json.error, "channel_not_ready");
  });
  it("requires webhook verification, rejects bad signatures, and isolates workspaces", async () => {
    const verified = await request(
      "/api/webhooks/whatsapp?hub.mode=subscribe&hub.verify_token=test-webhook-token&hub.challenge=challenge-123"
    );
    assert.equal(verified.status, 200);
    assert.equal(verified.body, "challenge-123");
    const unverified = await request(
      "/api/webhooks/whatsapp?hub.mode=subscribe&hub.verify_token=wrong&hub.challenge=challenge-123"
    );
    assert.equal(unverified.status, 403);
    await connectChannel2("isolation-a", "whatsapp", "isolation-phone-a");
    await connectChannel2("isolation-b", "whatsapp", "isolation-phone-b");
    const payload = whatsappPayload("isolation-phone-a", "971500000003", "wamid-isolated");
    const body = JSON.stringify(payload);
    const badSignature = await request("/api/webhooks/whatsapp", {
      method: "POST",
      body,
      headers: { "x-hub-signature-256": "sha256=invalid" }
    });
    assert.equal(badSignature.status, 401);
    assert.equal(badSignature.json.error, "invalid_webhook_signature");
    const accepted = await signedWebhook(
      "/api/webhooks/whatsapp",
      payload,
      { "x-workspace-id": "isolation-b" }
    );
    assert.equal(accepted.status, 202);
    const workspaceA = await request("/api/workspaces/isolation-a/conversations");
    const workspaceB = await request("/api/workspaces/isolation-b/conversations");
    assert.equal(workspaceA.json.conversations.length, 1);
    assert.equal(workspaceB.json.conversations.length, 0);
    const crossWorkspace = await signedWebhook(
      "/api/workspaces/isolation-b/webhooks/whatsapp",
      payload
    );
    assert.equal(crossWorkspace.status, 409);
    assert.equal(crossWorkspace.json.error, "workspace_channel_mismatch");
    const afterCrossWorkspace = await request("/api/workspaces/isolation-b/conversations");
    assert.equal(afterCrossWorkspace.json.conversations.length, 0);
  });
});
//# sourceMappingURL=channels.test.mjs.map
